/**
 * zipReader.js
 * ---------------------------------------------------------------------------
 * Lector mínimo de archivos ZIP, escrito sin dependencias externas.
 *
 * Por qué existe: un .xlsx ES un ZIP que contiene XML por dentro. La forma
 * habitual de leerlo en el navegador es con una librería como SheetJS, pero
 * este módulo la evita por completo usando dos APIs nativas del navegador:
 *   - DecompressionStream('deflate-raw') para descomprimir (soportado desde
 *     Chrome ~95+).
 *   - DOMParser para leer el XML resultante (lo usa xlsxImporter.js).
 *
 * Solo implementa lo necesario para leer entradas por nombre desde el
 * directorio central del ZIP; no escribe ni modifica archivos ZIP.
 *
 * Referencia del formato: https://en.wikipedia.org/wiki/ZIP_(file_format)
 * ---------------------------------------------------------------------------
 */

const EOCD_SIGNATURE = 0x06054b50;
const CENTRAL_DIR_SIGNATURE = 0x02014b50;
const LOCAL_FILE_SIGNATURE = 0x04034b50;
const MAX_EOCD_COMMENT_SIZE = 65535;

/**
 * @typedef {Object} ZipEntry
 * @property {number} compressionMethod  0 = sin comprimir, 8 = deflate
 * @property {number} compressedSize
 * @property {number} uncompressedSize
 * @property {number} localHeaderOffset
 */

/**
 * @typedef {Object} ZipFile
 * @property {Uint8Array} bytes
 * @property {DataView} view
 * @property {Object<string, ZipEntry>} entries
 */

/**
 * Lee el directorio central de un ZIP en memoria (no descomprime nada aún).
 * @param {ArrayBuffer} arrayBuffer
 * @returns {ZipFile}
 */
export function openZip(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  const view = new DataView(arrayBuffer);

  const eocdOffset = findEndOfCentralDirectory(view, bytes.length);
  if (eocdOffset === -1) {
    throw new Error('El archivo no parece ser un .xlsx válido (no se encontró el índice ZIP).');
  }

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const centralDirOffset = view.getUint32(eocdOffset + 16, true);

  const entries = {};
  let offset = centralDirOffset;

  for (let i = 0; i < totalEntries; i += 1) {
    const signature = view.getUint32(offset, true);
    if (signature !== CENTRAL_DIR_SIGNATURE) {
      throw new Error('Índice ZIP corrupto o formato no soportado.');
    }
    const compressionMethod = view.getUint16(offset + 10, true);
    const compressedSize = view.getUint32(offset + 20, true);
    const uncompressedSize = view.getUint32(offset + 24, true);
    const fileNameLength = view.getUint16(offset + 28, true);
    const extraFieldLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localHeaderOffset = view.getUint32(offset + 42, true);

    const nameBytes = bytes.subarray(offset + 46, offset + 46 + fileNameLength);
    const fileName = new TextDecoder('utf-8').decode(nameBytes);

    entries[fileName] = { compressionMethod, compressedSize, uncompressedSize, localHeaderOffset };
    offset += 46 + fileNameLength + extraFieldLength + commentLength;
  }

  return { bytes, view, entries };
}

/**
 * Busca la firma "End Of Central Directory" desde el final del archivo hacia
 * atrás (puede haber un comentario de longitud variable después del EOCD).
 */
function findEndOfCentralDirectory(view, totalLength) {
  const searchStart = Math.max(0, totalLength - 22 - MAX_EOCD_COMMENT_SIZE);
  for (let i = totalLength - 22; i >= searchStart; i -= 1) {
    if (view.getUint32(i, true) === EOCD_SIGNATURE) return i;
  }
  return -1;
}

/**
 * Extrae y descomprime (si aplica) el contenido de una entrada del ZIP.
 * @param {ZipFile} zip
 * @param {string} fileName - ruta exacta dentro del ZIP, ej. "xl/worksheets/sheet1.xml"
 * @returns {Promise<Uint8Array|null>} null si la entrada no existe
 */
export async function extractEntry(zip, fileName) {
  const entry = zip.entries[fileName];
  if (!entry) return null;

  const { view, bytes } = zip;
  const off = entry.localHeaderOffset;

  if (view.getUint32(off, true) !== LOCAL_FILE_SIGNATURE) {
    throw new Error(`Encabezado local ZIP inválido para "${fileName}".`);
  }

  const nameLength = view.getUint16(off + 26, true);
  const extraLength = view.getUint16(off + 28, true);
  const dataStart = off + 30 + nameLength + extraLength;
  const compressedBytes = bytes.slice(dataStart, dataStart + entry.compressedSize);

  if (entry.compressionMethod === 0) {
    return compressedBytes; // almacenado sin comprimir
  }
  if (entry.compressionMethod === 8) {
    return inflateRaw(compressedBytes);
  }
  throw new Error(
    `Método de compresión ZIP no soportado (${entry.compressionMethod}) para "${fileName}". ` +
      'WaMaster Asthi solo soporta archivos .xlsx generados por Excel/Google Sheets estándar.'
  );
}

/**
 * Descomprime datos en formato "deflate-raw" usando la API nativa del
 * navegador (Compression Streams API). Requiere Chrome 95+.
 * @param {Uint8Array} compressedBytes
 * @returns {Promise<Uint8Array>}
 */
async function inflateRaw(compressedBytes) {
  if (typeof DecompressionStream === 'undefined') {
    throw new Error(
      'Tu versión de Chrome no soporta DecompressionStream. Actualiza Chrome para importar archivos .xlsx.'
    );
  }
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Blob([compressedBytes]).stream().pipeThrough(ds);
  const arrayBuffer = await new Response(stream).arrayBuffer();
  return new Uint8Array(arrayBuffer);
}

/** Devuelve la lista de nombres de entrada disponibles en el ZIP. */
export function listEntryNames(zip) {
  return Object.keys(zip.entries);
}
