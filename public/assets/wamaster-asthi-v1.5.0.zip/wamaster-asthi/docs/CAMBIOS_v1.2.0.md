# Auditoría de cambios — WaMaster Asthi v1.1 → v1.2.0

Este documento describe, punto por punto, cada cambio solicitado para v1.2.0, cómo se implementó, y la lista completa de archivos nuevos/modificados. Es el registro de referencia para revisar exactamente qué cambió respecto a la versión anterior.

## 1. Resumen de lo solicitado y su estado

| # | Requisito | Estado | Dónde |
|---|---|---|---|
| 1 | Mostrar "WaMaster Asthi v1.2.0" en la interfaz | Hecho | `manifest.json` (version), `sidebar.html` (badge de versión en el header) |
| 2 | Mejorar interfaz por secciones, mantener navy/dorado | Hecho | `sidebar.html`, `sidebar.css` reescritos |
| 3 | Tabla de contactos: teléfono, nombre, estado, X para eliminar | Hecho | `sidebar.html`/`sidebar.js`, sección Contactos |
| 4 | Buscador y contadores de contactos | Hecho | `contactSearch`, `renderCounters()` en `sidebar.js` |
| 5 | Detectar columnas del Excel y mostrarlas como botones insertables | Hecho | `renderVariableButtons()` en `sidebar.js` |
| 6 | Saludos aleatorios editables, activar/desactivar | Hecho | `src/modules/greetings.js`, sección Saludos en `sidebar.html` |
| 7 | Botón "Nueva campaña" que limpia todo | Hecho | `CampaignEngine.reset()`, `onNewCampaign()` en `sidebar.js` |
| 8 | Historial de campañas con descarga de fallidos/enviados/reporte | Hecho | `src/modules/campaignHistory.js`, `src/modules/exportUtils.js`, sección Historial |
| 9 | Corregir duplicado de mensaje al adjuntar imagen/PDF | Hecho | `src/content/whatsappSelectors.js`, `src/content/content.js` (ver sección 3 abajo) |
| 10 | Sistema de licencias: activación, estado visible, planes, validación sin claves quemadas | Hecho (frontend completo; backend documentado, no desplegado) | `src/modules/licensing.js`, `src/modules/deviceId.js`, sección Licencia |
| 11 | País/código de teléfono predeterminado, obligatorio en activación, evitar duplicar código | Hecho | `src/modules/countryCodes.js`, `contactManager.js` (`normalizePhoneWithCountry`), campo de país en la pantalla de Licencia |
| 12 | Tabla de contactos: mostrar número original y número final normalizado | Hecho | Columnas "Teléfono original" / "Teléfono final" en `sidebar.html` |
| 13 | Validar y marcar números inválidos; permitir descargar los inválidos | Hecho | `contactManager.js` (`telefonoValido`, `estado: 'invalido'`), botón "Descargar inválidos" |
| 14 | Selector de emojis en el editor de mensajes, compatible con variables/preview/envío | Hecho | `EMOJI_LIST` + `emojiPicker` en `sidebar.js`/`sidebar.html`/`sidebar.css` |
| 15 | No romper funciones existentes | Verificado | Suite de pruebas automatizadas (82 casos, `npm test`), ver sección 4 |

## 2. Decisiones de diseño relevantes

### 2.1 Normalización de teléfono con país predeterminado

El país se captura como campo obligatorio en la pantalla de activación de licencia (una sola vez, reutilizable) y se guarda en `StorageKeys.DEFAULT_COUNTRY`. Al importar un Excel, `contactManager.buildContactsFromRows(rows, dialCode)` aplica esta regla por cada número (ver `normalizePhoneWithCountry` en `src/modules/contactManager.js`):

1. Si el número ya empieza exactamente con el código de país seleccionado, se deja igual (no se duplica).
2. Si el número tiene más de 10 dígitos, se asume que ya trae algún código de país (aunque no coincida con el seleccionado) y tampoco se le antepone nada — anteponer en ese caso generaría un número inválido con doble prefijo.
3. En cualquier otro caso (número corto, sin prefijo reconocible), se antepone el código de país.

Esta es una heurística explícita y documentada, no una detección perfecta: números locales inusualmente largos en algunos países podrían no seguir la regla 2 correctamente. Se decidió así por ser predecible y fácil de auditar, en vez de una tabla de longitudes por país (mucho más compleja y frágil). El campo `telefonoOriginal` siempre conserva el valor tal cual venía del Excel, así que el usuario puede verificar y corregir manualmente si hace falta.

Cada contacto ahora guarda tres datos relacionados con el teléfono: `telefonoOriginal` (crudo del Excel), `telefono` (normalizado, el que se usa para enviar) y `telefonoValido` (resultado de `isValidPhone()` sobre el normalizado). Un contacto con `telefonoValido: false` obtiene `estado: 'invalido'`, se excluye automáticamente del envío en `campaignEngine.start()`/`_runLoop()`, y aparece marcado en la tabla con la posibilidad de descargarse por separado.

### 2.2 Selector de emojis

Se optó por una paleta fija de ~50 emojis comunes en botones (sin depender de la Unicode Emoji Keyboard del sistema operativo ni de ninguna librería externa) que se insertan en la posición actual del cursor del `<textarea>` del mensaje, igual que los botones de variable. Al reutilizar la misma función `insertAtCursor()`, el emoji queda embebido como texto plano dentro de la plantilla: se previsualiza igual que cualquier otro carácter, se renderiza igual con `renderTemplate()` (no es una variable, así que no interactúa con `{nombre}`, `{saludo}`, etc.), y se envía igual que el resto del texto porque `content.js` no distingue emojis del resto del mensaje — todo va como una sola cadena de texto al compositor de WhatsApp Web. No requirió cambios en `content.js` ni en `campaignEngine.js`.

### 2.3 Corrección del mensaje duplicado con adjuntos

**Causa raíz identificada:** al enviar con adjunto, el código de v1.1 buscaba la "caja de pie de foto" y el "botón enviar" del modal de adjuntos con selectores CSS genéricos aplicados sobre `document` completo. El cuadro de texto principal de la conversación (`composeBox`) sigue existiendo en el DOM detrás del modal de adjuntos (WhatsApp Web no lo destruye, solo lo tapa visualmente), y en ciertos casos un selector genérico podía coincidir primero con ese cuadro de fondo en vez de con el pie de foto real del modal — el texto terminaba escrito en dos lugares, y WhatsApp enviaba ambos: el mensaje de texto suelto y la imagen con su pie de foto.

**Corrección aplicada** (`src/content/whatsappSelectors.js` + `src/content/content.js`):

1. Se agregó `CANDIDATES.dialogContainer` (selectores del contenedor del modal de adjuntos) y `queryAnyWithin(container, selectors)`, que busca **solo dentro** de ese contenedor.
2. `sendWithAttachment()` ahora localiza el modal (`dialog`) primero, y busca la caja de pie de foto y el botón de enviar del adjunto usando `queryAnyWithin(dialog, ...)` — nunca en `document` completo.
3. Se agregó una limpieza defensiva: antes de abrir el flujo de adjuntos, se vacía el `composeBox` principal por si quedó texto de un intento anterior.
4. Se agregó una guardia de "un solo disparo" por `requestId` (`processedJobIds`) en `content.js`, para que el mismo trabajo pendiente nunca se procese dos veces aunque `init()` se dispare más de una vez para la misma navegación.
5. En `campaignEngine._sendToContact()`, la URL de navegación solo incluye el parámetro `text` cuando **no** hay adjunto (`buildChatUrl(contact.telefono, this.attachment ? undefined : text)`), para no precargar texto en el compositor principal cuando de todas formas se va a escribir en el pie de foto del modal.

**Limitación honesta:** esta corrección se basa en selectores CSS de la interfaz pública de WhatsApp Web, que no es una API estable; no fue posible probarla contra WhatsApp Web en vivo dentro de este entorno de desarrollo (sin acceso a un navegador real con sesión de WhatsApp). El fix está razonado, acotado, y cubierto por el caso de prueba manual B4.5 actualizado en `docs/PLAN_PRUEBAS.md` — se recomienda validarlo en un entorno real antes de una campaña masiva.

### 2.4 Licencias sin claves quemadas en el frontend

Ver `docs/LICENCIAS.md` (sección actualizada) y `docs/LICENSE_BACKEND.md` para el detalle completo. En resumen: `licensing.js` nunca decide localmente si una clave es válida a partir de un secreto embebido; siempre delega en un backend HTTPS configurable (`StorageKeys.LICENSE_API_BASE`). Como el backend real no es parte de esta entrega (WaMaster Asthi es la extensión de cliente), se incluye un interruptor explícito y visible en la UI ("Modo de prueba local") para poder usar la extensión completa mientras se despliega un backend — no es una clave quemada, es una bandera de configuración local que cualquier build de producción puede simplemente no exponer en la interfaz.

## 3. Compatibilidad multiplataforma (Windows/macOS)

Se revisó el código para confirmar que no depende de nada específico del sistema operativo: no hay rutas de archivo nativas, no se invoca ningún proceso del sistema, no hay scripts de shell empaquetados en la extensión, y todas las rutas dentro de `manifest.json` usan `/` (formato requerido por Chrome, no es una ruta de SO). Todo el código usa exclusivamente APIs web estándar (`fetch`, `DecompressionStream`, `DOMParser`, `Blob`, `crypto.randomUUID`) y `chrome.*`, que se comportan igual en Chrome para Windows, macOS y Linux. No se requirió ningún cambio de código para esto — se dejó documentado en el README bajo "Instalación".

## 4. Verificación antes de esta entrega

- `npm test` — 82 pruebas automatizadas, 82 exitosas, 0 fallidas (incluye toda la lógica nueva de v1.2.0: normalización de teléfono con país, licencias con modo de prueba local y con backend simulado vía mocks de `fetch`, historial de campañas, exportación CSV, saludos aleatorios, y el flujo completo de `campaignEngine` de principio a fin con contactos inválidos mezclados).
- `unzip -t` sobre el paquete final antes de entregarlo, para confirmar integridad del `.zip`.
- Verificación de que `manifest.json` apunta a archivos que realmente existen (íconos, side panel, content scripts, background).

No se corrigió en este pase la condición de carrera documentada en `docs/AUDITORIA.md` (hallazgo A1, pausa/reanudación con clics muy rápidos): no formaba parte de lo solicitado para v1.2.0 y se prefirió no mezclar un cambio no pedido en una entrega ya extensa. Sigue documentada como pendiente de prioridad alta para una futura versión.

## 5. Lista completa de archivos nuevos y modificados

### Nuevos

- `src/modules/countryCodes.js`
- `src/modules/greetings.js`
- `src/modules/campaignHistory.js`
- `src/modules/exportUtils.js`
- `src/modules/licensing.js`
- `src/modules/deviceId.js`
- `docs/CAMBIOS_v1.2.0.md` (este archivo)
- `docs/LICENSE_BACKEND.md`
- `tests/greetings.test.js`
- `tests/campaignHistory.test.js`
- `tests/exportUtils.test.js`
- `tests/licensing.test.js`
- `tests/countryCodes.test.js`
- `tests/deviceId.test.js`
- `tests/campaignEngine.test.js`
- `tests/background.test.js`

### Modificados

- `manifest.json` — versión `1.2.0`, `content_security_policy.connect-src` ampliado para permitir llamadas HTTPS al backend de licencias.
- `src/utils/storage.js` — nuevas `StorageKeys`: `GREETINGS_LIST`, `GREETINGS_ENABLED`, `CAMPAIGN_HISTORY`, `LICENSE`, `LICENSE_API_BASE`, `LICENSE_DEV_BYPASS`, `INSTALLATION_ID`, `DEFAULT_COUNTRY`.
- `src/modules/contactManager.js` — nuevos campos `telefonoOriginal`/`telefonoValido`, nuevo estado `'invalido'`, funciones `normalizePhoneWithCountry()`, `removeContactByPhone()`, `filterContacts()`.
- `src/modules/campaignEngine.js` — guardia de licencia en `start()`, inyección de saludo aleatorio por contacto, registro en historial al completar/detener, exclusión de contactos inválidos del envío, nuevo método `reset()`.
- `src/content/whatsappSelectors.js` — `dialogContainer` + `queryAnyWithin()` (corrección de mensaje duplicado).
- `src/content/content.js` — flujo de adjuntos reescrito para usar `queryAnyWithin()`, limpieza defensiva del compose box, guardia de un solo disparo por `requestId`.
- `src/sidebar/sidebar.html`, `src/sidebar/sidebar.css`, `src/sidebar/sidebar.js` — reescritos por completo (ver sección 1 de este documento).
- `README.md`, `docs/LICENCIAS.md`, `docs/PLAN_PRUEBAS.md` — actualizados para v1.2.0.
- `package.json` — versión `1.2.0`.

### Sin cambios de lógica (solo comentarios o ningún cambio)

- `src/utils/whatsappUrl.js`, `src/utils/messaging.js`, `src/utils/logger.js`, `src/modules/zipReader.js`, `src/modules/xlsxImporter.js`, `src/background/background.js` — idénticos a v1.1.
- `src/modules/messageTemplate.js` — sin cambios de lógica; solo el comentario superior se actualizó para mencionar `{saludo}`.
