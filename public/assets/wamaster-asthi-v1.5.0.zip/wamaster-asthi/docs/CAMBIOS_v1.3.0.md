# Resumen de cambios — v1.2.2 → v1.3.0

## Qué se pidió

> Quiero mejorar esta extensión: que permita volver a enviar mensajes nuevamente, que permita adjuntar imágenes o archivos, y que el tema de la licencia se coloque en otra pestaña del mismo WaMaster.

Al aclarar el alcance se confirmó:

1. **Reenvío**: ambas cosas — relanzar la campaña completa a la misma base ya cargada, **y** reintentar solo los contactos que quedaron marcados como fallidos.
2. **Adjuntos**: múltiples archivos por campaña (no un adjunto distinto por contacto, no más tipos de archivo — los tipos ya soportados, imagen y PDF, se mantienen).
3. **Licencia**: pasa de ser una sección más en la columna única a ser su propia pestaña, separada de "Campaña".

## Qué había antes

- Una vez que una campaña terminaba (o se detenía), la única forma de volver a enviar era pulsar "Nueva campaña" y reimportar el Excel desde cero — no había manera de reintentar solo los fallidos ni de simplemente repetir el envío completo a la misma lista.
- Solo se podía adjuntar **un** archivo por campaña (`attachment`, singular). Para mandar dos imágenes había que hacerlo en dos campañas separadas.
- La sección "Licencia" vivía en la misma columna con scroll que Contactos, Mensaje, Adjuntos, Ritmo, Campaña, Registro e Historial — mezclada con el flujo operativo del día a día.

## Cambios implementados

### 1. Reenvío — `src/modules/campaignEngine.js`

- **`restartCampaign()`**: reinicia `currentIndex` a 0 y vuelve a llamar a `start()` sobre la misma lista de contactos ya cargada (sin reimportar Excel, sin borrar mensaje ni adjuntos). Reinicia el registro y el historial como una corrida nueva.
- **`retryFailed()`**: lee el Registro actual, arma la lista de contactos cuyo último resultado fue "Fallido", y corre el envío **solo** sobre esa lista. Los contactos que ya recibieron el mensaje no se tocan; el resultado del reintento actualiza la misma entrada del Registro (no la duplica). Si no hay ningún fallido, no hace nada y muestra un aviso.
- Internamente se agregó el concepto de **modo de campaña** (`CampaignMode`: `'main'` | `'retry'`), que determina sobre qué lista opera el bucle de envío (`_runLoop()`) y cómo se registra el historial al terminar (`_recordHistory()` distingue "Completada"/"Detenida" de "Reintento completado"/"Reintento detenido").
- Se conservó el comportamiento existente de pausar/reanudar/detener sin cambios, para ambos modos.
- Un cuidado explícito: en modo **main**, la lista de contactos válidos se sigue recalculando en cada corrida (incluida cada reanudación), para reflejar ediciones hechas mientras la campaña estaba pausada — como ya funcionaba antes de esta versión. En modo **retry**, la lista queda fija desde el momento en que se pulsa "Reintentar fallidos", para no reintentar accidentalmente al contacto equivocado.

### 2. Adjuntos múltiples — `campaignEngine.js` + `src/content/content.js`

- `attachment` (un objeto) se reemplazó por `attachments` (un array). `configure({ attachments })` acepta cero, uno o varios archivos.
- En `content.js`, todos los archivos de un mismo envío se agrupan en un solo `DataTransfer` y se asignan juntos al `<input>` de WhatsApp Web — como si el usuario los hubiera elegido todos a la vez en el explorador de archivos.
- WhatsApp Web distingue dos flujos de adjunto ("Fotos y videos" con miniatura, o "Documento") y no permite mezclarlos en un mismo envío: si **todos** los archivos son imágenes, se usa el flujo de fotos; si hay al menos un archivo que no lo es (PDF, Word, etc.), **todos** se envían por el flujo de documento (las imágenes se ven como archivo adjunto en vez de miniatura en ese caso — limitación de la propia interfaz de WhatsApp Web, no de la extensión).
- Compatibilidad hacia atrás: si el estado persistido de una versión anterior a v1.3.0 tenía un `attachment` singular guardado, `loadPersistedState()` lo migra automáticamente a un array de un elemento.

### 3. Licencia en pestaña separada — `sidebar.html` / `sidebar.css` / `sidebar.js`

- Nueva barra de pestañas debajo del encabezado: **Campaña** (activa por defecto) y **Licencia**.
- La sección "Licencia" (activación, estado, plan, vencimiento, país, desactivar) se movió a su propia pestaña sin cambiar ningún identificador interno ni lógica de `licensing.js`.
- Si se intenta iniciar o reenviar una campaña y la licencia no está activa, la UI cambia automáticamente a la pestaña de Licencia para que el usuario vea el motivo.

### 4. UI de contactos/campaña — `sidebar.html` / `sidebar.js`

- Sección "Adjunto" (singular) pasó a "Adjuntos": el selector de archivo ahora acepta selección múltiple (`multiple`) y se puede abrir varias veces para ir agregando archivos; cada archivo aparece en una lista con su nombre y un botón para quitarlo individualmente, además de un botón para quitarlos todos.
- Nuevos botones en la sección Campaña: **"Reenviar campaña completa"** (llama a `restartCampaign()`, pide confirmación porque reenvía a todos) y **"Reintentar fallidos (N)"** (llama a `retryFailed()`, el contador N se actualiza en vivo según el Registro). Ambos se deshabilitan mientras hay una campaña corriendo; "Reintentar fallidos" además se deshabilita si no hay ningún fallido.
- El estado mostrado ("Estado: enviando...", "Estado: pausada", etc.) ahora distingue una corrida de reintento ("Estado: reintentando fallidos...") de una corrida normal.
- El Historial ahora también muestra "Reintento completado" / "Reintento detenido" para las entradas generadas por `retryFailed()`.

## Qué NO cambió

- El motor de variables/alias (`messageTemplate.js`), la detección de país por teléfono, la validación y descarga de contactos inválidos, el selector de emojis, los saludos aleatorios, la exportación de historial (CSV/JSON) y el backend de licencias (`wamaster-asthi-web`) — sin cambios.
- Ningún dato guardado de campañas anteriores se pierde: el estado persistido de versiones previas se migra automáticamente al cargar el panel (ver compatibilidad de adjuntos arriba).
- Los tipos de archivo soportados en adjuntos siguen siendo imagen y PDF, sin cambios.

## Verificación

- `npm test` → **103/103 pruebas en verde** (94 heredadas de v1.2.2 + 9 nuevas en `tests/campaignEngine.test.js`): `retryFailed()` reintenta solo lo fallido y actualiza el Registro sin duplicar entradas, `retryFailed()` es un no-op sin fallidos, `restartCampaign()` reenvía a todos y reinicia el progreso, `restartCampaign()` es un no-op si ya está corriendo, construcción del job con varios adjuntos (URL sin `?text=` cuando hay adjuntos, con `?text=` cuando no los hay), y tres pruebas de `loadPersistedState()` (reintento con `activeList` válida, reintento sin `activeList` cae a modo main/detenida en vez de arriesgarse, y migración del `attachment` singular heredado a `attachments`).
- Se revisó manualmente el flujo completo de `sidebar.js` reescrito contra la lista de referencias de `campaignEngine.js`/`sidebar.html` para confirmar que ningún identificador quedó desalineado (`attachmentsList`, `btnClearAttachments`, `btnResendAll`, `btnRetryFailed`, `retryFailedCount`, `tabBar`).
- `node --check` sobre `sidebar.js`, `campaignEngine.js` y los archivos de prueba para confirmar sintaxis válida antes de empaquetar.

## Archivos modificados en esta versión

- `src/modules/campaignEngine.js` — `CampaignMode`, `restartCampaign()`, `retryFailed()`, `attachments` (array), `_activeList`, `_recordHistory()` con rama de reintento, `loadPersistedState()` con migración y manejo seguro de `activeList`.
- `src/content/content.js` — `sendWithAttachments()` (antes `sendWithAttachment`), agrupación de varios `File` en un solo `DataTransfer`, selección de flujo "Fotos y videos" vs. "Documento" según el tipo de los archivos.
- `src/sidebar/sidebar.html` — barra de pestañas Campaña/Licencia, sección "Adjuntos" con lista multi-archivo, botones "Reenviar campaña completa" y "Reintentar fallidos".
- `src/sidebar/sidebar.css` — estilos de `.tab-bar`/`.tab-panel`, `.resend-controls`/`.btn-outline`, `.attachments-list`.
- `src/sidebar/sidebar.js` — reescrito: cambio de pestañas, estado de adjuntos como array con lista renderizada, wiring de los nuevos botones de reenvío/reintento, estado de campaña consciente del modo, historial con las nuevas etiquetas de reintento.
- `tests/campaignEngine.test.js` — 9 pruebas nuevas + helper de simulación de envíos reescrito para soportar cambiar la regla de éxito/fallo a mitad de una prueba sin duplicar respuestas.
- `manifest.json`, `package.json` — versión `1.3.0`.
- `docs/CAMBIOS_v1.3.0.md` — este documento.
