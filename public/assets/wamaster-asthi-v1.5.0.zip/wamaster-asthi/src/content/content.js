/**
 * content.js (script clásico, no módulo ES6 — ver whatsappSelectors.js para el porqué)
 * ---------------------------------------------------------------------------
 * Se ejecuta dentro de web.whatsapp.com. Su trabajo: cuando el side panel
 * navega la pestaña a una URL click-to-chat (patrón Outbox, ver
 * ARQUITECTURA.md), este script detecta que hay un "trabajo pendiente"
 * (PENDING_SEND_JOB) que coincide con el número de la URL actual, espera a
 * que cargue el chat, y ejecuta el envío: solo texto, o con adjunto
 * (imagen/PDF) + pie de foto opcional.
 *
 * v1.2.0 — corrección de "mensaje duplicado" con adjuntos (ver
 * docs/CAMBIOS_v1.2.0.md):
 *   1. Los selectores de "caja de pie de foto" y "botón enviar" del modal
 *      ahora se buscan ACOTADOS al contenedor del diálogo de adjuntos
 *      (queryAnyWithin), nunca en todo el documento — antes podían
 *      coincidir con el cuadro de texto principal de la conversación, que
 *      sigue existiendo detrás del modal.
 *   2. Se limpia defensivamente el cuadro de texto principal ANTES de abrir
 *      el flujo de adjuntos, por si quedó texto de un intento anterior.
 *   3. Guardia de "un solo disparo" por trabajo (`processedJobIds`): si por
 *      cualquier motivo `init()` se re-ejecuta mientras un job ya se está
 *      procesando (ej. WhatsApp Web dispara varios eventos de navegación
 *      para la misma URL), el mismo requestId no se procesa dos veces.
 *
 * v1.3.0 — adjuntos múltiples: `job.attachment` (uno solo) se reemplazó por
 * `job.attachments` (array, puede tener 0, 1 o varios archivos). Todos los
 * archivos de un mismo envío se agrupan en UN SOLO DataTransfer y se
 * asignan juntos al input de WhatsApp (igual que si el usuario los
 * seleccionara todos a la vez en el explorador de archivos). WhatsApp Web
 * distingue dos flujos de adjunto —"Fotos y videos" (con vista previa en
 * miniatura) y "Documento" (como archivo adjunto genérico)— y no permite
 * mezclarlos en un mismo envío. Por eso: si TODOS los archivos son
 * imágenes/video, se usa el flujo de "Fotos y videos"; si hay al menos un
 * archivo que no lo es (PDF, Word, etc.), TODOS se envían por el flujo de
 * "Documento" (las imágenes se ven como archivo adjunto en vez de miniatura
 * en ese caso — es una limitación de la propia interfaz de WhatsApp Web, no
 * de esta extensión; documentado en docs/CAMBIOS_v1.3.0.md).
 *
 * v1.5.0 — confiabilidad con más adjuntos + pie de foto independiente:
 *   1. `job.caption` (nuevo) reemplaza a `job.text` como pie de foto cuando
 *      hay adjuntos — campaignEngine.js decide su valor (el "Subtítulo del
 *      adjunto" si el usuario lo llenó, si no el mensaje principal, igual
 *      que antes). `job.text` sigue existiendo pero ahora solo se usa para
 *      el envío sin adjuntos (vía el parámetro `text` de la URL click-to-chat).
 *   2. Tope defensivo de MAX_JOB_ATTACHMENTS: si por cualquier motivo llega
 *      un job con más archivos de los que campaignEngine.js debería permitir,
 *      se recorta aquí también en vez de intentar asignarlos todos a
 *      WhatsApp Web (que puede fallar o comportarse de forma impredecible
 *      con selecciones muy grandes).
 *   3. La pausa después de asignar los archivos ahora escala con la
 *      cantidad de adjuntos (WhatsApp Web tarda más en generar las vistas
 *      previas de 3-4 archivos que de uno solo), y se verifica que el
 *      input de archivo realmente haya recibido todos los archivos
 *      asignados antes de continuar — si no, se aborta con un error claro
 *      en vez de intentar enviar un adjunto incompleto.
 * ---------------------------------------------------------------------------
 */

(function () {
  // Duplicado intencional de storage.js StorageKeys.PENDING_SEND_JOB
  // ("wamasterAsthi:pendingSendJob"): este script clásico no puede hacer
  // `import` de módulos ES6. Si cambias esa clave en storage.js, actualiza
  // también esta constante.
  const PENDING_JOB_STORAGE_KEY = 'wamasterAsthi:pendingSendJob';
  const SEND_RESULT_MESSAGE_TYPE = 'WHATSAPP_SEND_RESULT';

  const CHAT_LOAD_TIMEOUT_MS = 20000;
  const AFTER_ATTACH_CLICK_DELAY_MS = 800;
  // Pausa base tras asignar los archivos, más un incremento por cada
  // adjunto adicional (WhatsApp Web tarda más en generar miniaturas/vistas
  // previas cuantos más archivos hay que procesar).
  const AFTER_FILE_ASSIGN_DELAY_MS_BASE = 1200;
  const AFTER_FILE_ASSIGN_DELAY_MS_PER_EXTRA_FILE = 400;
  const AFTER_SEND_CLICK_DELAY_MS = 1000;
  /** Debe coincidir con MAX_ATTACHMENTS de campaignEngine.js (no se puede importar: script clásico). */
  const MAX_JOB_ATTACHMENTS = 4;

  /** @type {Set<string>} requestIds ya procesados en esta carga de página, para evitar doble envío. */
  const processedJobIds = new Set();

  init().catch((err) => console.error('[WaMaster Asthi] content.js error:', err));

  async function init() {
    const job = await getPendingJob();
    if (!job) return;

    const currentPhone = new URLSearchParams(window.location.search).get('phone');
    if (!job.phone || job.phone !== currentPhone) return;
    if (processedJobIds.has(job.requestId)) return;
    processedJobIds.add(job.requestId);

    await clearPendingJob();

    try {
      await handleInvalidNumberOrContinue();
      await window.WaMasterSelectors.waitFor(
        () => window.WaMasterSelectors.queryAny(window.WaMasterSelectors.CANDIDATES.composeBox),
        CHAT_LOAD_TIMEOUT_MS
      );

      if (job.attachments && job.attachments.length > 0) {
        if (job.attachments.length > MAX_JOB_ATTACHMENTS) {
          throw new Error(`Se recibieron ${job.attachments.length} adjuntos, más del máximo permitido (${MAX_JOB_ATTACHMENTS}).`);
        }
        await sendWithAttachments(job);
      } else {
        await sendTextOnly(job);
      }

      reportResult(job.requestId, { success: true });
    } catch (err) {
      reportResult(job.requestId, { success: false, errorMessage: err?.message || String(err) });
    }
  }

  /** Si WhatsApp muestra el aviso de "número inválido" o el modal de "continuar al chat", lo resuelve. */
  async function handleInvalidNumberOrContinue() {
    const { CANDIDATES, pageContainsText, queryByText } = window.WaMasterSelectors;

    if (pageContainsText(CANDIDATES.invalidNumberText)) {
      throw new Error('WhatsApp reportó que el número de teléfono es inválido.');
    }

    const continueBtn = queryByText(CANDIDATES.continueButtonText);
    if (continueBtn) {
      continueBtn.click();
      // Pausa fija breve: dar tiempo a que el modal se cierre y cargue el
      // chat antes de continuar (ver AUDITORIA.md, hallazgo A10 — se
      // documenta como candidato a reemplazar por espera basada en
      // condición en una futura versión).
      await sleep(1500);
    }
  }

  async function sendTextOnly(job) {
    const { CANDIDATES, queryAny } = window.WaMasterSelectors;
    const composeBox = queryAny(CANDIDATES.composeBox);
    if (!composeBox) throw new Error('No se encontró el cuadro de texto de WhatsApp Web.');

    // El texto ya viene precargado en el cuadro por el parámetro `text` de
    // la URL click-to-chat (ver whatsappUrl.js). Solo hace falta enviar.
    const sendButton = await window.WaMasterSelectors.waitFor(
      () => queryAny(CANDIDATES.sendButton),
      8000
    );
    sendButton.click();
    await sleep(AFTER_SEND_CLICK_DELAY_MS);
  }

  async function sendWithAttachments(job) {
    const { CANDIDATES, queryAny, queryByText, queryAnyWithin, waitFor } = window.WaMasterSelectors;

    // (1) Limpieza defensiva del cuadro de texto principal: si quedó algo
    // escrito ahí de un intento previo, lo vaciamos para que no se cuele
    // como un mensaje de texto separado antes o después del adjunto.
    const composeBox = queryAny(CANDIDATES.composeBox);
    if (composeBox) {
      setContentEditableText(composeBox, '');
    }

    const attachButton = await waitFor(() => queryAny(CANDIDATES.attachButton), 8000);
    attachButton.click();
    await sleep(AFTER_ATTACH_CLICK_DELAY_MS);

    // Todos los archivos son imagen/video -> flujo "Fotos y videos" (con
    // miniatura). Si hay al menos uno que no lo es -> flujo "Documento"
    // para TODOS (WhatsApp Web no permite mezclar ambos flujos en un envío).
    const allImages = job.attachments.every((a) => /^image\//.test(a.mimeType || ''));
    const menuItemTexts = allImages ? CANDIDATES.attachPhotoMenuItemText : CANDIDATES.attachDocumentMenuItemText;
    const menuItem = await waitFor(() => queryByText(menuItemTexts), 8000);
    menuItem.click();
    await sleep(300);

    const fileInputSelectors = allImages ? CANDIDATES.attachImageInput : CANDIDATES.attachDocumentInput;
    const fileInput = await waitFor(() => document.querySelector(fileInputSelectors.join(',')), 8000);
    const files = await Promise.all(
      job.attachments.map((a) => dataUrlToFile(a.dataUrl, a.fileName, a.mimeType))
    );
    assignFilesToInput(fileInput, files);

    // Verificación defensiva: si el navegador/WhatsApp Web no aceptó todos
    // los archivos asignados (ej. un input que se re-renderizó a mitad de
    // la asignación), es mejor abortar con un error claro que intentar
    // enviar un adjunto incompleto y que el contacto reciba menos archivos
    // de los esperados sin que quede registrado como fallo.
    if (fileInput.files.length !== files.length) {
      throw new Error(
        `Solo se asignaron ${fileInput.files.length} de ${files.length} archivos al input de WhatsApp. Intenta de nuevo o con menos adjuntos.`
      );
    }

    // La pausa escala con la cantidad de adjuntos: WhatsApp Web necesita más
    // tiempo para generar las vistas previas de varios archivos que de uno solo.
    const fileAssignDelay = AFTER_FILE_ASSIGN_DELAY_MS_BASE + (files.length - 1) * AFTER_FILE_ASSIGN_DELAY_MS_PER_EXTRA_FILE;
    await sleep(fileAssignDelay);

    // (2) A partir de aquí, TODO se busca acotado al contenedor del modal
    // de vista previa/pie de foto — nunca en `document` completo — para no
    // volver a tocar el cuadro de texto principal que sigue existiendo
    // detrás del modal. Esta es la corrección del bug de mensaje duplicado.
    const dialog = await waitFor(() => queryAny(CANDIDATES.dialogContainer), 8000);

    // job.caption es el pie de foto/documento (independiente del mensaje
    // principal desde v1.5.0 — ver campaignEngine.js). Se mantiene la
    // compatibilidad con job.text por si algún job viejo persistido no trae
    // `caption` todavía.
    const captionValue = job.caption !== undefined ? job.caption : job.text;
    if (captionValue) {
      const captionBox = await waitFor(() => queryAnyWithin(dialog, CANDIDATES.captionBox), 8000);
      setContentEditableText(captionBox, captionValue);
    }

    const modalSendButton = await waitFor(() => queryAnyWithin(dialog, CANDIDATES.sendButton), 8000);
    modalSendButton.click();
    await sleep(AFTER_SEND_CLICK_DELAY_MS);
  }

  /**
   * Asigna uno o varios File a un <input type="file"> mediante DataTransfer
   * (no se puede asignar `.files` directamente). Todos los archivos se
   * agregan al MISMO DataTransfer antes de asignarlo, para que WhatsApp Web
   * los reciba como una sola selección múltiple (igual que si el usuario
   * hubiera elegido varios archivos a la vez en el explorador).
   * @param {HTMLInputElement} inputEl
   * @param {File[]} files
   */
  function assignFilesToInput(inputEl, files) {
    const dataTransfer = new DataTransfer();
    for (const file of files) {
      dataTransfer.items.add(file);
    }
    inputEl.files = dataTransfer.files;
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
  }

  /**
   * Escribe texto en un elemento contenteditable simulando entrada de
   * usuario. Se usa `document.execCommand` (ver AUDITORIA.md, hallazgo A16:
   * está deprecado pero sigue siendo, en la práctica, lo único que hace que
   * React (el framework de WhatsApp Web) detecte el cambio de forma
   * confiable; reemplazarlo requiere simular eventos de InputEvent nativos
   * más complejos, documentado como mejora futura).
   */
  function setContentEditableText(el, text) {
    el.focus();
    document.execCommand('selectAll', false, undefined);
    document.execCommand('delete', false, undefined);
    if (text) {
      document.execCommand('insertText', false, text);
    }
  }

  async function dataUrlToFile(dataUrl, fileName, mimeType) {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([blob], fileName, { type: mimeType || blob.type });
  }

  function reportResult(requestId, result) {
    chrome.runtime.sendMessage({ type: SEND_RESULT_MESSAGE_TYPE, requestId, ...result }).catch(() => {});
  }

  function getPendingJob() {
    return new Promise((resolve) => {
      chrome.storage.local.get(PENDING_JOB_STORAGE_KEY, (res) => {
        resolve(res ? res[PENDING_JOB_STORAGE_KEY] : null);
      });
    });
  }

  function clearPendingJob() {
    return new Promise((resolve) => {
      chrome.storage.local.remove(PENDING_JOB_STORAGE_KEY, () => resolve());
    });
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
})();
