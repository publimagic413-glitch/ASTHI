# Resumen de cambios — v1.2.1 → v1.2.2

## Qué se pidió

> Añade más variables para el mensaje.

Al aclarar el alcance, se confirmó: **más alias para columnas comunes** — que variables como `{email}`/`{correo}`, `{ciudad}`, `{producto}` se reconozcan aunque el Excel use otro nombre de columna para el mismo dato.

## Qué había antes

Desde v1.2.0, cualquier columna del Excel ya se podía usar como variable, pero **solo si el nombre escrito en el mensaje coincidía exactamente** (ignorando mayúsculas) con el nombre de la columna. Dos problemas concretos:

1. **Los acentos rompían la coincidencia de verdad.** Una columna "Dirección" en el Excel NO se resolvía si el mensaje tenía `{direccion}` sin tilde — `'Dirección'.toLowerCase()` no es igual a `'direccion'`. Esto afectaba a cualquier columna con acentos: dirección, teléfono (columnas extra distintas a la principal), número, código, etc.
2. **No había alias entre sinónimos.** Si el Excel traía una columna "Correo Electrónico" y el usuario escribía `{email}` en el mensaje (o copiaba una plantilla de otra campaña que usaba `{email}`), no se resolvía — había que memorizar el nombre exacto de cada columna de cada archivo.

## Cambio implementado

Un archivo: `src/modules/messageTemplate.js`. `resolveVariable()` ahora resuelve en tres pasos:

1. **Alias fijos de siempre**: `{nombre}`/`{name}`, `{telefono}`/`{phone}` (sin cambios de comportamiento).
2. **Coincidencia exacta normalizada** (nuevo): se compara sin acentos, sin mayúsculas y sin espacios extremos. `{direccion}` ahora sí encuentra una columna "Dirección", " CIUDAD " o cualquier variante de mayúsculas/acentos del mismo nombre.
3. **Coincidencia por grupo de alias** (nuevo): si el nombre escrito y una columna del Excel pertenecen al mismo grupo de sinónimos, se resuelven igual. Grupos incluidos en esta versión:

   | Variable | Alias reconocidos |
   |---|---|
   | `{email}` | correo, correo electronico, e-mail, mail |
   | `{ciudad}` | city, municipio, localidad |
   | `{producto}` | product, articulo, item |
   | `{empresa}` | company, negocio, compania, razon social |
   | `{direccion}` | address, domicilio, ubicacion |
   | `{monto}` | amount, total, precio, importe |
   | `{fecha}` | date, dia |
   | `{pedido}` | order, orden, folio, numero de pedido |
   | `{vendedor}` | asesor, agente, ejecutivo |
   | `{sucursal}` | tienda, branch, punto de venta |

   Agregar un grupo nuevo es una línea en `ALIAS_GROUPS` — no requiere tocar el resto del motor de plantillas.

La búsqueda siempre prioriza la coincidencia exacta (paso 2) antes que los alias (paso 3), así que si el Excel tiene una columna llamada literalmente "Email", `{email}` la usa directamente sin pasar por el grupo de alias.

## Qué NO cambió

- La detección automática de columnas y los botones insertables — siguen mostrando el nombre exacto de cada columna del Excel, y clickearlos sigue garantizando una coincidencia exacta (nunca dependen de alias).
- `{nombre}`, `{telefono}`, `{saludo}` — mismo comportamiento de siempre, cero regresiones (cubierto por prueba dedicada).
- `contactManager.js`, `campaignEngine.js`, `content.js`, `sidebar.js`, licencias, historial, país/teléfono automático, selector de emojis — sin cambios.
- Ningún dato guardado cambia de formato; no hace falta reimportar Excel ni reconfigurar nada.

## Verificación

- `npm test` → **94/94 pruebas en verde** (86 de v1.2.1 + 8 nuevas en `tests/messageTemplate.test.js`): acentos ignorados en coincidencia exacta, alias en ambas direcciones (`{email}`↔"Correo Electrónico", `{correo}`↔"Email"), alias de producto/empresa, variable sin coincidencia sigue reportándose como faltante (no se "inventan" valores), y `{nombre}`/`{telefono}` sin regresión.

## Archivos modificados en esta versión

- `src/modules/messageTemplate.js` — `normalizeVariableName()`, `ALIAS_GROUPS`, `resolveVariable()` reescrito en 3 pasos.
- `tests/messageTemplate.test.js` — 8 pruebas nuevas de regresión.
- `manifest.json`, `package.json` — versión `1.2.2`.
- `src/sidebar/sidebar.html` — insignia de versión actualizada a `v1.2.2`.
- `docs/CAMBIOS_v1.2.2.md` — este documento.
