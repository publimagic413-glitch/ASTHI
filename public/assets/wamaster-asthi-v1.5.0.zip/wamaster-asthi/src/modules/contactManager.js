/**
 * contactManager.js
 * ---------------------------------------------------------------------------
 * Normaliza filas crudas de xlsxImporter.js en objetos "Contact" listos para
 * usar en la campaña, detectando automáticamente qué columnas del Excel
 * corresponden a nombre y teléfono.
 * ---------------------------------------------------------------------------
 */

/**
 * @typedef {Object} Contact
 * @property {string} telefono - normalizado, solo dígitos, con código de país
 * @property {string} telefonoOriginal - tal cual venía en el Excel (v1.2.0, para mostrar en tabla)
 * @property {boolean} telefonoValido - si `telefono` pasa isValidPhone() (v1.2.0)
 * @property {string} nombre
 * @property {Object<string,string>} extra - resto de columnas del Excel (para variables personalizadas)
 * @property {'pendiente'|'enviado'|'fallido'|'invalido'} estado - estado de envío/validación (v1.2.0: visible en tabla de UI)
 */

const NAME_HEADER_HINTS = ['nombre', 'name', 'cliente', 'contacto'];
const PHONE_HEADER_HINTS = ['telefono', 'teléfono', 'phone', 'celular', 'movil', 'móvil', 'whatsapp'];

// Regex de combinación de diacríticos Unicode (rango U+0300–U+036F), usada
// para quitar acentos al comparar encabezados ("Teléfono" -> "telefono").
const COMBINING_DIACRITICS_REGEX = new RegExp('[̀-ͯ]', 'g');

/** Quita acentos y pasa a minúsculas, para comparar encabezados de forma tolerante. */
function normalizeHeader(header) {
  return header
    .normalize('NFD')
    .replace(COMBINING_DIACRITICS_REGEX, '')
    .trim()
    .toLowerCase();
}

/**
 * Detecta qué clave de `rows[0]` corresponde a un campo, probando una lista
 * de hints en orden de prioridad. Solo inspecciona la primera fila, ya que
 * xlsxImporter.js garantiza claves uniformes en todas las filas del resultado.
 */
function detectColumn(rows, hints) {
  if (rows.length === 0) return null;
  const keys = Object.keys(rows[0]);
  for (const hint of hints) {
    const found = keys.find((k) => normalizeHeader(k) === hint);
    if (found) return found;
  }
  // Coincidencia parcial como respaldo (ej. "Teléfono cliente" contiene "telefono").
  for (const hint of hints) {
    const found = keys.find((k) => normalizeHeader(k).includes(hint));
    if (found) return found;
  }
  return null;
}

/** Deja solo dígitos en un número de teléfono crudo. */
export function normalizePhone(rawPhone) {
  return String(rawPhone ?? '').replace(/\D/g, '');
}

/** Un teléfono normalizado es válido si tiene entre 8 y 15 dígitos (rango E.164). */
export function isValidPhone(phone) {
  return /^\d{8,15}$/.test(phone);
}

/**
 * Longitud típica de un número local (sin código de país) en la mayoría de
 * los planes de numeración. Se usa como heurística para decidir si un
 * número importado del Excel YA trae código internacional o no.
 *
 * Regla (documentada, ver LICENCIAS.md / CAMBIOS_v1.2.0.md):
 *  1. Si el número ya empieza exactamente con el `dialCode` seleccionado,
 *     se deja tal cual (no se duplica).
 *  2. Si el número tiene más de LOCAL_NUMBER_MAX_LENGTH dígitos, se asume
 *     que ya trae ALGÚN código de país (aunque no coincida con el
 *     seleccionado) y tampoco se le antepone nada, para evitar números
 *     inválidos por doble prefijo.
 *  3. En cualquier otro caso, se antepone el `dialCode`.
 */
const LOCAL_NUMBER_MAX_LENGTH = 10;

/**
 * Antepone el código de país predeterminado a un número local si hace
 * falta, evitando duplicarlo si ya lo trae. Ver LOCAL_NUMBER_MAX_LENGTH
 * arriba para la heurística exacta.
 * @param {string} rawPhone - valor crudo tal cual viene del Excel
 * @param {string} [dialCode] - código de país sin "+", ej. "52"
 * @returns {string} teléfono normalizado (solo dígitos)
 */
export function normalizePhoneWithCountry(rawPhone, dialCode) {
  const digits = normalizePhone(rawPhone);
  if (!dialCode) return digits;
  if (digits.startsWith(dialCode)) return digits;
  if (digits.length > LOCAL_NUMBER_MAX_LENGTH) return digits;
  if (digits.length === 0) return digits;
  return `${dialCode}${digits}`;
}

/**
 * Construye la lista de contactos a partir de las filas importadas del Excel.
 * @param {Array<Object<string,string>>} rows
 * @param {string} [defaultDialCode] - código de país predeterminado (v1.2.0),
 *   capturado en la pantalla de activación de licencia. Si se omite, el
 *   comportamiento es igual al de v1.1 (solo se limpian los dígitos).
 * @returns {Contact[]}
 */
export function buildContactsFromRows(rows, defaultDialCode) {
  const nameKey = detectColumn(rows, NAME_HEADER_HINTS);
  const phoneKey = detectColumn(rows, PHONE_HEADER_HINTS);

  return rows.map((row) => {
    const nombre = nameKey ? String(row[nameKey] ?? '').trim() : '';
    const rawPhone = phoneKey ? row[phoneKey] : '';
    const telefonoOriginal = String(rawPhone ?? '').trim();
    const telefono = defaultDialCode
      ? normalizePhoneWithCountry(rawPhone, defaultDialCode)
      : normalizePhone(rawPhone);
    const telefonoValido = isValidPhone(telefono);

    const extra = {};
    for (const [key, value] of Object.entries(row)) {
      if (key === nameKey || key === phoneKey) continue;
      extra[key] = value;
    }

    return {
      nombre,
      telefono,
      telefonoOriginal,
      telefonoValido,
      extra,
      estado: telefonoValido ? 'pendiente' : 'invalido',
    };
  });
}

/**
 * Elimina un contacto de la lista por teléfono (usado por el botón "X" de la
 * tabla de contactos en v1.2.0). Devuelve un nuevo array, no muta el original.
 * @param {Contact[]} contacts
 * @param {string} telefono
 * @returns {Contact[]}
 */
export function removeContactByPhone(contacts, telefono) {
  return contacts.filter((c) => c.telefono !== telefono);
}

/**
 * Filtra contactos por un texto de búsqueda libre, comparando contra nombre
 * y teléfono (usado por el buscador de la tabla de contactos en v1.2.0).
 * @param {Contact[]} contacts
 * @param {string} query
 * @returns {Contact[]}
 */
export function filterContacts(contacts, query) {
  const q = normalizeHeader(query || '');
  if (!q) return contacts;
  return contacts.filter((c) => {
    const nombre = normalizeHeader(c.nombre || '');
    const telefono = (c.telefono || '').toLowerCase();
    return nombre.includes(q) || telefono.includes(q);
  });
}
