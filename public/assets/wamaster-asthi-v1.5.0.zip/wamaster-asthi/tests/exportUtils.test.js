import { test } from 'node:test';
import assert from 'node:assert/strict';
import { toCsv } from '../src/modules/exportUtils.js';

test('toCsv - genera encabezados desde las claves del primer objeto', () => {
  const csv = toCsv([{ Nombre: 'Ana', Telefono: '123' }, { Nombre: 'Beto', Telefono: '456' }]);
  const lines = csv.replace(/^﻿/, '').split('\r\n');
  assert.equal(lines[0], 'Nombre,Telefono');
  assert.equal(lines[1], 'Ana,123');
  assert.equal(lines[2], 'Beto,456');
});

test('toCsv - escapa comillas y comas', () => {
  const csv = toCsv([{ Nota: 'Dice "hola", adiós' }]);
  const lines = csv.replace(/^﻿/, '').split('\r\n');
  assert.equal(lines[1], '"Dice ""hola"", adiós"');
});

test('toCsv - array vacío devuelve cadena vacía', () => {
  assert.equal(toCsv([]), '');
});

test('toCsv - respeta columnas explícitas', () => {
  const csv = toCsv([{ a: 1, b: 2, c: 3 }], ['c', 'a']);
  const lines = csv.replace(/^﻿/, '').split('\r\n');
  assert.equal(lines[0], 'c,a');
  assert.equal(lines[1], '3,1');
});
