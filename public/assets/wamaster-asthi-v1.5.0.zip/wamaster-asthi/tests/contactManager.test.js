import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizePhone,
  isValidPhone,
  normalizePhoneWithCountry,
  buildContactsFromRows,
  removeContactByPhone,
  filterContacts,
} from '../src/modules/contactManager.js';

test('normalizePhone - deja solo dígitos', () => {
  assert.equal(normalizePhone('+52 (55) 1234-5678'), '525512345678');
});

test('isValidPhone - rango 8-15 dígitos', () => {
  assert.equal(isValidPhone('5512345678'), true);
  assert.equal(isValidPhone('1234567'), false);
  assert.equal(isValidPhone('1234567890123456'), false);
});

test('normalizePhoneWithCountry - antepone el código si falta', () => {
  assert.equal(normalizePhoneWithCountry('5512345678', '52'), '525512345678');
});

test('normalizePhoneWithCountry - no duplica si ya trae el código', () => {
  assert.equal(normalizePhoneWithCountry('525512345678', '52'), '525512345678');
});

test('normalizePhoneWithCountry - no antepone si el número ya es largo (probable código distinto)', () => {
  // 12 dígitos > LOCAL_NUMBER_MAX_LENGTH (10): se asume que ya trae algún código.
  assert.equal(normalizePhoneWithCountry('573001234567', '52'), '573001234567');
});

test('normalizePhoneWithCountry - sin dialCode se comporta como normalizePhone', () => {
  assert.equal(normalizePhoneWithCountry('55 1234 5678', undefined), '5512345678');
});

test('buildContactsFromRows - detecta columnas Nombre/Teléfono con acento y aplica código de país', () => {
  const rows = [
    { Nombre: 'Ana', Teléfono: '5512345678', Empresa: 'Acme' },
    { Nombre: 'Beto', Teléfono: '5598765432', Empresa: 'Acme' },
  ];
  const contacts = buildContactsFromRows(rows, '52');
  assert.equal(contacts.length, 2);
  assert.equal(contacts[0].nombre, 'Ana');
  assert.equal(contacts[0].telefono, '525512345678');
  assert.equal(contacts[0].telefonoOriginal, '5512345678');
  assert.equal(contacts[0].telefonoValido, true);
  assert.equal(contacts[0].estado, 'pendiente');
  assert.equal(contacts[0].extra.Empresa, 'Acme');
});

test('buildContactsFromRows - detecta columnas en mayúsculas sin acento', () => {
  const rows = [{ NOMBRE: 'Cara', TELEFONO: '5511112222' }];
  const contacts = buildContactsFromRows(rows, '52');
  assert.equal(contacts[0].nombre, 'Cara');
  assert.equal(contacts[0].telefono, '525511112222');
});

test('buildContactsFromRows - marca inválido si el teléfono normalizado no cumple isValidPhone', () => {
  const rows = [{ Nombre: 'Mal', Teléfono: '123' }];
  const contacts = buildContactsFromRows(rows, '52');
  assert.equal(contacts[0].telefonoValido, false);
  assert.equal(contacts[0].estado, 'invalido');
});

test('removeContactByPhone - elimina por teléfono normalizado', () => {
  const contacts = [{ telefono: '111' }, { telefono: '222' }];
  const result = removeContactByPhone(contacts, '111');
  assert.equal(result.length, 1);
  assert.equal(result[0].telefono, '222');
});

test('filterContacts - busca por nombre o teléfono, insensible a acentos/mayúsculas', () => {
  const contacts = [
    { nombre: 'José Pérez', telefono: '525512345678' },
    { nombre: 'María López', telefono: '525598765432' },
  ];
  assert.equal(filterContacts(contacts, 'jose').length, 1);
  assert.equal(filterContacts(contacts, '5598765432').length, 1);
  assert.equal(filterContacts(contacts, '').length, 2);
});
