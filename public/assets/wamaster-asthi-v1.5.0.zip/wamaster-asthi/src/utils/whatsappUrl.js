/**
 * whatsappUrl.js
 * ---------------------------------------------------------------------------
 * Construye la URL "click-to-chat" de WhatsApp Web, el mecanismo oficial
 * para abrir una conversación con un número arbitrario (esté o no guardado
 * como contacto) desde fuera de la app: https://faq.whatsapp.com/general/click-to-chat
 * ---------------------------------------------------------------------------
 */

/**
 * @param {string} phone - solo dígitos, con código de país (ej. "5215512345678")
 * @param {string} [text] - texto a precargar en el cuadro de mensaje (opcional)
 */
export function buildChatUrl(phone, text) {
  const base = `https://web.whatsapp.com/send?phone=${encodeURIComponent(phone)}`;
  return text ? `${base}&text=${encodeURIComponent(text)}` : base;
}

/** Extrae el parámetro `phone` de una URL de WhatsApp Web, o null si no aplica. */
export function parsePhoneFromUrl(url) {
  try {
    return new URL(url).searchParams.get('phone');
  } catch {
    return null;
  }
}
