import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';

let getGreetings, setGreetings, isGreetingsEnabled, setGreetingsEnabled, pickRandomGreeting, DEFAULT_GREETINGS;

beforeEach(async () => {
  const mock = createChromeMock();
  globalThis.chrome = mock.chrome;
  const mod = await import(`../src/modules/greetings.js?t=${Date.now()}_${Math.random()}`);
  ({ getGreetings, setGreetings, isGreetingsEnabled, setGreetingsEnabled, pickRandomGreeting, DEFAULT_GREETINGS } = mod);
});

test('getGreetings - devuelve la lista por defecto si nunca se guardó nada', async () => {
  assert.deepEqual(await getGreetings(), DEFAULT_GREETINGS);
});

test('setGreetings - limpia líneas vacías y espacios', async () => {
  const saved = await setGreetings(['Hola', '  ', 'Buenos días  ', '']);
  assert.deepEqual(saved, ['Hola', 'Buenos días']);
  assert.deepEqual(await getGreetings(), ['Hola', 'Buenos días']);
});

test('isGreetingsEnabled / setGreetingsEnabled', async () => {
  assert.equal(await isGreetingsEnabled(), false);
  await setGreetingsEnabled(true);
  assert.equal(await isGreetingsEnabled(), true);
});

test('pickRandomGreeting - siempre devuelve un elemento de la lista', () => {
  const list = ['A', 'B', 'C'];
  for (let i = 0; i < 20; i++) {
    assert.ok(list.includes(pickRandomGreeting(list)));
  }
});

test('pickRandomGreeting - lista vacía devuelve cadena vacía', () => {
  assert.equal(pickRandomGreeting([]), '');
});
