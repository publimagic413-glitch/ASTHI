import { test } from 'node:test';
import assert from 'node:assert/strict';
import { COUNTRY_CODES, getDialCode, getCountry } from '../src/modules/countryCodes.js';

test('COUNTRY_CODES - no tiene iso2 duplicados', () => {
  const seen = new Set();
  for (const c of COUNTRY_CODES) {
    assert.equal(seen.has(c.iso2), false, `iso2 duplicado: ${c.iso2}`);
    seen.add(c.iso2);
  }
});

test('getDialCode - devuelve el código para un país conocido', () => {
  assert.equal(getDialCode('MX'), '52');
  assert.equal(getDialCode('CO'), '57');
});

test('getDialCode - null para país desconocido', () => {
  assert.equal(getDialCode('ZZ'), null);
  assert.equal(getDialCode(null), null);
});

test('getCountry - devuelve el objeto completo', () => {
  const country = getCountry('ES');
  assert.equal(country.name, 'España');
  assert.equal(country.dialCode, '34');
});
