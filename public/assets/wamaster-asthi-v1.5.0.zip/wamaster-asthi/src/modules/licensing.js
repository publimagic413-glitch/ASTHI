/**
 * licensing.js
 * ---------------------------------------------------------------------------
 * Sistema de licencias de WaMaster Asthi (v1.4.1) — autenticación por correo
 * y contraseña contra un backend REST propio. La extensión NUNCA accede a la
 * base de datos del proveedor directamente ni guarda la contraseña del
 * usuario: toda validación pasa por el backend.
 *
 *   1. activateLicense(email, password) hace POST /v1/auth/login con el
 *      correo, la contraseña y un installationId (ver deviceId.js). El
 *      backend responde con un token de sesión de corta vida — la extensión
 *      cachea ESE token, nunca la contraseña.
 *   2. revalidateLicense() hace POST /v1/licenses/session con
 *      Authorization: Bearer <token> periódicamente, sin volver a pedir la
 *      contraseña. Distingue tres desenlaces (ver el comentario de la
 *      función más abajo).
 *   3. deactivateLicense() hace POST /v1/auth/logout con el token y limpia
 *      la sesión local aunque el backend no responda.
 *
 * Ver docs/LICENCIAS.md y docs/LICENSE_BACKEND.md para el contrato de API
 * completo. La API legada por clave de licencia (activate/validate/deactivate
 * sin correo/contraseña) ya no la usa esta versión de la extensión, pero el
 * backend de referencia la sigue exponiendo por compatibilidad hacia atrás.
 *
 * MODO DE DESARROLLO (LICENSE_DEV_BYPASS): interruptor explícito y visible en
 * la UI para operar sin backend mientras se despliega uno. No es una clave
 * quemada, es un flag de storage que un build de producción puede omitir.
 * ---------------------------------------------------------------------------
 */

import { getItem, setItem, removeItem, StorageKeys } from '../utils/storage.js';
import { getInstallationId } from './deviceId.js';

export const LicenseStatus = Object.freeze({
  INACTIVE: 'inactive', // nunca se inició sesión en este navegador
  ACTIVE: 'active', // válida y confirmada por el backend recientemente
  GRACE: 'grace', // no se pudo revalidar contra el backend, pero sigue dentro del período de tolerancia
  EXPIRED: 'expired', // el backend confirmó que la licencia no es utilizable, o se acabó el período de gracia
  INVALID: 'invalid', // la sesión murió (token inválido/expirado) o el registro es heredado sin token
});

export const PlanId = Object.freeze({
  TRIAL: 'trial',
  BASIC: 'basic',
  PRO: 'pro',
  AGENCY: 'agency',
});

/** Duración máxima que se acepta una sesión "en gracia" sin poder contactar al backend. */
const GRACE_PERIOD_MS = 7 * 24 * 60 * 60 * 1000; // 7 días
/** Cada cuánto se intenta revalidar en segundo plano si la UI queda abierta. */
const REVALIDATE_INTERVAL_MS = 12 * 60 * 60 * 1000; // 12 horas
/** Backend de desarrollo local por defecto, para que la extensión funcione "de fábrica" sin configurar nada a mano. Sobrescribible en Opciones avanzadas. */
const DEFAULT_API_BASE = 'http://localhost:4000';

/**
 * @typedef {Object} LicenseRecord
 * @property {string} email
 * @property {string} status - uno de LicenseStatus
 * @property {string} planId - uno de PlanId
 * @property {string} planLabel - nombre visible del plan (lo decide el backend)
 * @property {string|null} key - clave de licencia de referencia (ya no la escribe el usuario)
 * @property {number|null} expiresAt - epoch ms, o null si no expira
 * @property {number} lastValidatedAt - epoch ms de la última confirmación exitosa del backend
 * @property {string} installationId
 * @property {string|null} token - token de sesión de corta vida; NUNCA la contraseña
 * @property {boolean} devBypass - true si se está usando el modo de prueba local (sin backend)
 */

/** @returns {Promise<LicenseRecord|null>} */
export async function getLicense() {
  return getItem(StorageKeys.LICENSE, null);
}

/** @returns {Promise<string>} la URL base configurada del backend de licencias. */
export async function getApiBase() {
  return getItem(StorageKeys.LICENSE_API_BASE, DEFAULT_API_BASE);
}

/** @param {string} url */
export async function setApiBase(url) {
  await setItem(StorageKeys.LICENSE_API_BASE, String(url || '').trim());
}

/**
 * Inicia sesión con correo y contraseña. Si LICENSE_DEV_BYPASS está activo
 * (modo de prueba local, activado explícitamente por el usuario en la UI),
 * simula una sesión exitosa con el plan PRO sin red, dejando claro en
 * `devBypass: true` que no es una validación real.
 * @param {string} email
 * @param {string} password
 * @returns {Promise<LicenseRecord>}
 */
export async function activateLicense(email, password) {
  const trimmedEmail = String(email || '').trim();
  if (!trimmedEmail) {
    throw new Error('Ingresa tu correo.');
  }

  const devBypass = await getItem(StorageKeys.LICENSE_DEV_BYPASS, false);
  const installationId = await getInstallationId();

  if (devBypass) {
    const record = buildLocalDevRecord(trimmedEmail, installationId);
    await setItem(StorageKeys.LICENSE, record);
    return record;
  }

  const trimmedPassword = String(password || '');
  if (!trimmedPassword) {
    throw new Error('Ingresa tu contraseña.');
  }

  const apiBase = await getApiBase();
  if (!apiBase) {
    throw new Error(
      'No hay backend de licencias configurado. Configúralo en Opciones avanzadas, o activa el "Modo de prueba local" para operar sin backend mientras lo despliegas. Ver docs/LICENSE_BACKEND.md.'
    );
  }

  const { data } = await fetchJson(`${apiBase}/v1/auth/login`, {
    method: 'POST',
    body: { email: trimmedEmail, password: trimmedPassword, installationId, deviceName: getDeviceName() },
  });

  if (!data.valid) {
    throw new Error(data.message || 'Correo o contraseña incorrectos.');
  }

  const record = {
    email: trimmedEmail,
    status: LicenseStatus.ACTIVE,
    planId: data.license?.planId ?? PlanId.BASIC,
    planLabel: data.license?.planLabel ?? 'Plan',
    key: data.license?.key ?? null,
    expiresAt: data.license?.expiresAt ?? null,
    lastValidatedAt: Date.now(),
    installationId,
    token: data.token,
    devBypass: false,
  };

  await setItem(StorageKeys.LICENSE, record);
  return record;
}

/**
 * Revalida la sesión contra el backend sin volver a pedir contraseña.
 * Distingue tres desenlaces:
 *  - HTTP 401 (sesión muerta) -> INVALID, se limpia el token (fuerza reingresar credenciales).
 *  - HTTP 200 con valid:false (sesión viva pero licencia no utilizable, ej. suspendida/vencida)
 *    -> EXPIRED, se CONSERVA el token: si el admin reactiva la licencia, la siguiente
 *    revalidación se recupera sola sin pedir login de nuevo.
 *  - Fallo de red -> lógica de gracia (GRACE si aún dentro de GRACE_PERIOD_MS, si no EXPIRED).
 * @returns {Promise<LicenseRecord|null>} null si nunca se inició sesión
 */
export async function revalidateLicense() {
  const current = await getLicense();
  if (!current) return null;

  if (current.devBypass) {
    // El modo de prueba local no revalida contra ningún backend por definición.
    return current;
  }

  if (!current.token) {
    // Registro heredado (activado por clave antes de v1.4.0): no hay token que revalidar.
    const updated = { ...current, status: LicenseStatus.INVALID };
    await setItem(StorageKeys.LICENSE, updated);
    return updated;
  }

  const apiBase = await getApiBase();
  if (!apiBase) return current;

  try {
    const { status: httpStatus, data } = await fetchJson(`${apiBase}/v1/licenses/session`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${current.token}` },
      body: { installationId: current.installationId },
    });

    if (httpStatus === 401) {
      const updated = { ...current, status: LicenseStatus.INVALID, token: null };
      await setItem(StorageKeys.LICENSE, updated);
      return updated;
    }

    if (!data.valid) {
      const updated = { ...current, status: LicenseStatus.EXPIRED }; // token se conserva a propósito
      await setItem(StorageKeys.LICENSE, updated);
      return updated;
    }

    const updated = {
      ...current,
      status: LicenseStatus.ACTIVE,
      planId: data.license?.planId ?? current.planId,
      planLabel: data.license?.planLabel ?? current.planLabel,
      key: data.license?.key ?? current.key,
      expiresAt: data.license?.expiresAt ?? current.expiresAt,
      lastValidatedAt: Date.now(),
    };
    await setItem(StorageKeys.LICENSE, updated);
    return updated;
  } catch {
    // Fallo de red: aplicamos la lógica de gracia en base al último éxito conocido.
    const elapsed = Date.now() - current.lastValidatedAt;
    const status = elapsed > GRACE_PERIOD_MS ? LicenseStatus.EXPIRED : LicenseStatus.GRACE;
    const updated = { ...current, status };
    await setItem(StorageKeys.LICENSE, updated);
    return updated;
  }
}

/** Cierra sesión: avisa al backend (si hay token) y siempre limpia localmente, aunque falle la llamada. */
export async function deactivateLicense() {
  const current = await getLicense();
  const apiBase = await getApiBase();
  if (current && !current.devBypass && apiBase && current.token) {
    try {
      await fetchJson(`${apiBase}/v1/auth/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${current.token}` },
        body: { installationId: current.installationId },
      });
    } catch {
      // Aunque falle la llamada, igual limpiamos localmente para no dejar al
      // usuario atrapado; el backend puede limpiar sesiones huérfanas por su cuenta.
    }
  }
  await removeItem(StorageKeys.LICENSE);
}

/**
 * Chequeo síncrono-friendly (basado en caché) que campaignEngine.start()
 * usa como guardia antes de lanzar una campaña. Deliberadamente NO hace red.
 * @param {LicenseRecord|null} license
 * @returns {boolean}
 */
export function isLicenseUsable(license) {
  if (!license) return false;
  return license.status === LicenseStatus.ACTIVE || license.status === LicenseStatus.GRACE;
}

/** Programa revalidaciones periódicas mientras el side panel esté abierto. */
export function scheduleRevalidation() {
  revalidateLicense().catch(() => {});
  return setInterval(() => {
    revalidateLicense().catch(() => {});
  }, REVALIDATE_INTERVAL_MS);
}

function buildLocalDevRecord(email, installationId) {
  return {
    email,
    status: LicenseStatus.ACTIVE,
    planId: PlanId.PRO,
    planLabel: 'PRO (modo de prueba local)',
    key: null,
    expiresAt: null,
    lastValidatedAt: Date.now(),
    installationId,
    token: null,
    devBypass: true,
  };
}

function getDeviceName() {
  try {
    return navigator.userAgentData?.platform || navigator.platform || 'Navegador';
  } catch {
    return 'Navegador';
  }
}

/**
 * Wrapper de fetch que SIEMPRE intenta parsear el cuerpo como JSON (los
 * endpoints de auth devuelven cuerpos JSON útiles incluso en 401/429) y
 * nunca lanza por un status no-2xx — quien llama decide qué hacer con
 * {status, ok, data}.
 */
async function fetchJson(url, { method = 'GET', headers = {}, body } = {}) {
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try {
    data = await res.json();
  } catch {
    data = {};
  }
  return { status: res.status, ok: res.ok, data };
}
