# WaMaster Asthi v1.5.0

Extensión de Chrome (Manifest V3) para automatizar campañas de mensajería en WhatsApp Web: importa contactos desde Excel, personaliza mensajes con variables dinámicas de cualquier columna, envía hasta 4 imágenes/PDF por campaña con subtítulo independiente, aplica pausas aleatorias entre envíos y controla la campaña (iniciar/pausar/reanudar/detener/reenviar/reintentar fallidos) con progreso y registro de resultados en tiempo real.

Zero dependencias externas: todo el importador de Excel (ZIP + XML de OOXML) está escrito con APIs nativas del navegador (`DecompressionStream`, `DOMParser`), sin SheetJS ni ninguna librería de terceros.

## Novedades de v1.5.0

- La sección Licencia ahora se inicia sesión con **correo y contraseña** (contra un backend REST propio) en vez de una clave — la extensión nunca guarda la contraseña, solo un token de sesión. Funciona "de fábrica" contra un backend local en `http://localhost:4000`.
- Adjuntos: tope de **4 archivos por campaña**, con contador visible y aviso claro si intentas pasarte.
- Nuevo campo **"Subtítulo del adjunto"**, independiente del mensaje principal, para el pie de foto/documento.
- Envío con adjuntos más confiable: pausas que escalan con la cantidad de archivos y verificación de que todos se asignaron antes de continuar.
- Ver `docs/CAMBIOS_v1.5.0.md` para el detalle completo.

## Novedades de v1.3.0

- Panel dividido en dos pestañas: **Campaña** (todo el flujo operativo) y **Licencia** (activación/estado, ahora separada del día a día).
- Reenvío de campañas: **"Reenviar campaña completa"** repite el envío a toda la lista ya cargada sin reimportar el Excel, y **"Reintentar fallidos"** reenvía solo a los contactos que el Registro marcó como fallidos, sin tocar a los que ya recibieron el mensaje.
- Adjuntos múltiples: la sección "Adjuntos" ahora acepta varios archivos por campaña (imágenes y/o PDF), con lista de archivos elegidos y opción de quitarlos individualmente o todos a la vez.
- Ver `docs/CAMBIOS_v1.3.0.md` para el detalle completo.

## Novedades de v1.2.2

- Las variables ahora se resuelven ignorando acentos/mayúsculas y reconocen alias comunes: `{email}`/`{correo}`, `{ciudad}`, `{producto}`, `{empresa}`, `{direccion}`, `{monto}`, `{pedido}`, `{vendedor}`, `{sucursal}` y más, sin importar el nombre exacto de la columna en el Excel — ver `docs/CAMBIOS_v1.2.2.md`.

## Novedades de v1.2.1

- Las variables de mensaje ahora aceptan **cualquier** columna del Excel, sin importar los caracteres que tenga su nombre (`{monto}`, `{direccion}`, `{Monto ($)}`, `{N° Pedido}`, `{Fecha-Límite}`, etc.) — ver `docs/CAMBIOS_v1.2.1.md`.

## Novedades de v1.2.0

- Interfaz renovada por secciones (Licencia, Contactos, Mensaje, Saludos aleatorios, Adjunto, Ritmo, Campaña, Registro, Historial), estilo navy/dorado.
- Tabla de contactos con buscador, contadores, estado por contacto y botón para eliminar contactos antes de enviar.
- Detección automática de columnas del Excel como botones de variable insertables (`{Columna}`).
- Selector de emojis en el editor de mensajes.
- Saludos aleatorios editables, activables/desactivables, inyectados como `{saludo}`.
- Botón "Nueva campaña" que limpia contactos, mensaje, adjunto y progreso.
- Historial de campañas con descarga de enviados, fallidos y reporte completo.
- Corrección del envío duplicado al adjuntar imagen/PDF (ver `docs/CAMBIOS_v1.2.0.md`).
- Sistema de licencias con pantalla de activación, estado visible, planes y validación contra un backend configurable (sin claves quemadas en el frontend).
- País/código telefónico predeterminado: si el Excel trae números locales (sin código de país), WaMaster Asthi antepone automáticamente el código configurado en la activación de licencia, sin duplicarlo si ya lo trae.

## Instalación (modo desarrollador)

1. Abre `chrome://extensions`.
2. Activa "Modo de desarrollador" (esquina superior derecha).
3. Haz clic en "Cargar descomprimida" y selecciona la carpeta `wamaster-asthi/`.
4. Abre WhatsApp Web y haz clic en el ícono de la extensión para abrir el panel lateral.

Funciona igual en Windows, macOS y Linux: la extensión no usa nada específico del sistema operativo (ni rutas de archivo nativas, ni procesos, ni comandos de shell); todo corre dentro de Chrome usando únicamente APIs web estándar y `chrome.*`. Solo se requiere Chrome/Chromium 116 o superior en cualquiera de los tres sistemas.

## Primer uso

1. **Licencia** (pestaña aparte): inicia sesión con el correo y la contraseña que te dio tu proveedor de WaMaster Asthi, y selecciona tu país (código telefónico predeterminado). Si aún no tienes un backend de licencias desplegado, puedes activar "Modo de prueba local" para usar la extensión completa mientras tanto (ver `docs/LICENCIAS.md`).
2. **Contactos**: importa un archivo `.xlsx` con al menos una columna de nombre y una de teléfono. Los números locales se completan automáticamente con el código de país seleccionado.
3. **Mensaje**: escribe la plantilla usando los botones de variable (o `{nombre}`, `{telefono}`, `{saludo}`, o cualquier columna del Excel).
4. **Saludos aleatorios** (opcional): actívalos y edita la lista.
5. **Adjuntos** (opcional): elige hasta 4 imágenes/PDF, y opcionalmente un subtítulo independiente del mensaje principal para que acompañe al adjunto.
6. **Ritmo**: define la pausa mínima y máxima entre envíos.
7. **Campaña**: pulsa Iniciar. Puedes pausar/reanudar/detener en cualquier momento, y una vez terminada, reenviarla completa o reintentar solo los fallidos. Al terminar, la campaña queda en el Historial.

## Estructura del proyecto

```
wamaster-asthi/
├── manifest.json
├── icons/
├── src/
│   ├── background/background.js       Service worker (MV3)
│   ├── content/                       Scripts inyectados en WhatsApp Web
│   ├── modules/                       Lógica de negocio (sin DOM salvo lo indicado)
│   ├── sidebar/                       UI del side panel
│   └── utils/                         Utilidades transversales (storage, mensajería, URL)
├── tests/                             Pruebas automatizadas (node:test)
└── docs/                              Documentación técnica
```

Ver `docs/ARQUITECTURA.md` para el detalle de cada archivo, diagramas de flujo y patrones de diseño.

## Pruebas automatizadas

```
npm test
```

Corre la suite completa con el test runner nativo de Node (`node:test`), sin dependencias externas. Ver `docs/PLAN_PRUEBAS.md` para las pruebas manuales en Chrome + WhatsApp Web real.

## Cumplimiento y uso responsable

WaMaster Asthi automatiza WhatsApp Web usando el mecanismo oficial de "click-to-chat"; no usa la API oficial de WhatsApp Business ni ingeniería inversa del protocolo. El envío masivo de mensajes, especialmente a contactos que no dieron su consentimiento previo, puede infringir los Términos de Servicio de WhatsApp y, según tu jurisdicción, leyes de protección de datos o anti-spam. El uso de la herramienta es responsabilidad exclusiva de quien la opera.

## Documentación

- `docs/ARQUITECTURA.md` — arquitectura técnica y diagramas.
- `docs/AUDITORIA.md` — auditoría de código de v1.1 (hallazgos A1–A20).
- `docs/CAMBIOS_v1.2.0.md` — auditoría de cambios y lista de archivos modificados en v1.2.0.
- `docs/CAMBIOS_v1.2.1.md` — resumen de cambios de v1.2.1 (variables dinámicas con cualquier carácter).
- `docs/CAMBIOS_v1.2.2.md` — resumen de cambios de v1.2.2 (alias de columnas y coincidencia sin acentos).
- `docs/CAMBIOS_v1.3.0.md` — resumen de cambios de v1.3.0 (reenvío/reintento de campañas, adjuntos múltiples, pestaña de Licencia separada).
- `docs/CAMBIOS_v1.5.0.md` — resumen de cambios hasta v1.5.0 (login por correo/contraseña, tope de 4 adjuntos, subtítulo independiente, envío más confiable).
- `docs/LICENCIAS.md` — arquitectura del sistema de licencias.
- `docs/LICENSE_BACKEND.md` — contrato de API y esqueleto de referencia para el backend de licencias.
- `docs/PLAN_PRUEBAS.md` — plan de pruebas manuales.
