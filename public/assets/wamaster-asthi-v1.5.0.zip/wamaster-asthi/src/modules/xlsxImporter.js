/**
 * xlsxImporter.js
 * ---------------------------------------------------------------------------
 * Importador de archivos .xlsx SIN dependencias externas. Usa zipReader.js
 * para descomprimir el archivo y DOMParser (nativo del navegador) para leer
 * el XML de OOXML (Office Open XML) de la primera hoja.
 *
 * Este módulo solo corre en contextos con DOM disponible (el side panel),
 * no en el service worker.
 *
 * Limitaciones conocidas de la v1 (documentadas a propósito, no son bugs
 * ocultos):
 *   - Solo se lee la PRIMERA hoja del libro (xl/worksheets/sheet1.xml).
 *   - Las fechas de Excel se devuelven como número de serie crudo, no como
 *     fecha formateada (se puede añadir conversión más adelante sin romper
 *     la API pública de este módulo).
 *   - No se procesan celdas combinadas (merged cells) de forma especial.
 * ---------------------------------------------------------------------------
 */

import { openZip, extractEntry } from './zipReader.js';

/**
 * Importa un archivo .xlsx y devuelve las filas como objetos planos usando
 * la primera fila como encabezados.
 * @param {File} file
 * @returns {Promise<{ headers: string[], rows: Array<Object<string,string>> }>}
 */
export async function importXlsxFile(file) {
  const arrayBuffer = await file.arrayBuffer();
  const zip = openZip(arrayBuffer);

  const sheetEntryName = pickFirstWorksheetEntry(zip);
  if (!sheetEntryName) {
    throw new Error('No se encontró ninguna hoja de cálculo dentro del archivo .xlsx.');
  }

  const [sharedStrings, sheetXmlBytes] = await Promise.all([
    loadSharedStrings(zip),
    extractEntry(zip, sheetEntryName),
  ]);

  const sheetXmlText = new TextDecoder('utf-8').decode(sheetXmlBytes);
  const sheetDoc = new DOMParser().parseFromString(sheetXmlText, 'application/xml');
  assertNoParserError(sheetDoc, 'la hoja de cálculo');

  const grid = parseWorksheetGrid(sheetDoc, sharedStrings);
  return gridToObjects(grid);
}

/** Elige la primera hoja disponible (sheet1.xml si existe, si no la de menor número). */
function pickFirstWorksheetEntry(zip) {
  const sheetNames = Object.keys(zip.entries)
    .filter((name) => /^xl\/worksheets\/sheet\d+\.xml$/.test(name))
    .sort((a, b) => {
      const numA = parseInt(a.match(/sheet(\d+)\.xml$/)[1], 10);
      const numB = parseInt(b.match(/sheet(\d+)\.xml$/)[1], 10);
      return numA - numB;
    });
  return sheetNames[0] ?? null;
}

/** Carga y parsea xl/sharedStrings.xml (puede no existir en libros muy simples). */
async function loadSharedStrings(zip) {
  const bytes = await extractEntry(zip, 'xl/sharedStrings.xml');
  if (!bytes) return [];

  const xmlText = new TextDecoder('utf-8').decode(bytes);
  const doc = new DOMParser().parseFromString(xmlText, 'application/xml');
  assertNoParserError(doc, 'la tabla de textos compartidos');

  const items = [...doc.getElementsByTagName('si')];
  return items.map((si) => {
    // Cada <si> puede tener texto simple <t> o texto enriquecido con <r><t>.
    const textNodes = [...si.getElementsByTagName('t')];
    return textNodes.map((t) => t.textContent ?? '').join('');
  });
}

/**
 * Convierte el XML de una hoja en una matriz 2D de valores (filas x columnas),
 * respetando las posiciones reales de fila/columna del archivo original.
 */
function parseWorksheetGrid(sheetDoc, sharedStrings) {
  const rowElements = [...sheetDoc.getElementsByTagName('row')];
  const grid = [];

  for (const rowEl of rowElements) {
    const rowNumber = parseInt(rowEl.getAttribute('r'), 10);
    const rowIndex = (Number.isFinite(rowNumber) ? rowNumber : grid.length + 1) - 1;
    const rowValues = [];

    for (const cellEl of [...rowEl.children]) {
      if (cellEl.tagName !== 'c') continue;
      const ref = cellEl.getAttribute('r'); // ej. "B7"
      const colIndex = ref ? columnLetterToIndex(ref.replace(/\d+/g, '')) : rowValues.length;
      rowValues[colIndex] = readCellValue(cellEl, sharedStrings);
    }

    grid[rowIndex] = rowValues;
  }

  return grid;
}

/** Lee el valor de una celda `<c>` según su atributo de tipo `t`. */
function readCellValue(cellEl, sharedStrings) {
  const type = cellEl.getAttribute('t');

  if (type === 'inlineStr') {
    const isEl = cellEl.getElementsByTagName('is')[0];
    if (!isEl) return '';
    return [...isEl.getElementsByTagName('t')].map((t) => t.textContent ?? '').join('');
  }

  const vEl = cellEl.getElementsByTagName('v')[0];
  const rawValue = vEl ? vEl.textContent : '';

  if (type === 's') {
    const idx = parseInt(rawValue, 10);
    return sharedStrings[idx] ?? '';
  }
  if (type === 'b') {
    return rawValue === '1' ? 'TRUE' : 'FALSE';
  }
  // 'str' (fórmula con resultado texto) o numérico/sin tipo: se devuelve tal cual.
  return rawValue ?? '';
}

/** Convierte "A" -> 0, "B" -> 1, ..., "Z" -> 25, "AA" -> 26, etc. */
function columnLetterToIndex(letters) {
  let index = 0;
  for (const char of letters) {
    index = index * 26 + (char.charCodeAt(0) - 64);
  }
  return index - 1;
}

/** Transforma la matriz cruda en {headers, rows} usando la primera fila no vacía como encabezado. */
function gridToObjects(grid) {
  const headerRowIndex = grid.findIndex((row) => row && row.some((cell) => String(cell ?? '').trim() !== ''));
  if (headerRowIndex === -1) {
    return { headers: [], rows: [] };
  }

  const headerRow = grid[headerRowIndex];
  const headers = headerRow.map((cell, i) => {
    const text = String(cell ?? '').trim();
    return text || `Columna ${i + 1}`;
  });

  const rows = [];
  for (let i = headerRowIndex + 1; i < grid.length; i += 1) {
    const rowValues = grid[i];
    if (!rowValues || rowValues.every((cell) => String(cell ?? '').trim() === '')) continue; // fila vacía

    const rowObject = {};
    headers.forEach((header, colIndex) => {
      rowObject[header] = String(rowValues[colIndex] ?? '').trim();
    });
    rows.push(rowObject);
  }

  return { headers, rows };
}

/** DOMParser no lanza excepciones en errores de sintaxis: hay que revisar el DOM resultante. */
function assertNoParserError(doc, contextLabel) {
  const errorNode = doc.getElementsByTagName('parsererror')[0];
  if (errorNode) {
    throw new Error(`No se pudo leer ${contextLabel} del archivo .xlsx (XML inválido).`);
  }
}
