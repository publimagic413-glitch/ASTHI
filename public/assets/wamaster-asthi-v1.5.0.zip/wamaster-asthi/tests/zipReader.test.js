import { test } from 'node:test';
import assert from 'node:assert/strict';
import { openZip, extractEntry, listEntryNames } from '../src/modules/zipReader.js';
import { buildZip } from './helpers/zipBuilder.js';

test('openZip + extractEntry - lee una entrada comprimida (deflate)', async () => {
  const zipBuffer = buildZip([{ name: 'hello.txt', content: 'Hola mundo, esto es una prueba de ZIP.' }]);
  const zip = openZip(zipBuffer);
  assert.deepEqual(listEntryNames(zip), ['hello.txt']);

  const bytes = await extractEntry(zip, 'hello.txt');
  const text = new TextDecoder('utf-8').decode(bytes);
  assert.equal(text, 'Hola mundo, esto es una prueba de ZIP.');
});

test('openZip + extractEntry - lee una entrada sin comprimir (store)', async () => {
  const zipBuffer = buildZip([{ name: 'plain.txt', content: 'sin comprimir', store: true }]);
  const zip = openZip(zipBuffer);
  const bytes = await extractEntry(zip, 'plain.txt');
  assert.equal(new TextDecoder().decode(bytes), 'sin comprimir');
});

test('extractEntry - entrada inexistente devuelve null', async () => {
  const zipBuffer = buildZip([{ name: 'a.txt', content: 'x' }]);
  const zip = openZip(zipBuffer);
  assert.equal(await extractEntry(zip, 'no-existe.txt'), null);
});

test('openZip - múltiples entradas se listan todas', () => {
  const zipBuffer = buildZip([
    { name: 'xl/worksheets/sheet1.xml', content: '<a/>' },
    { name: 'xl/sharedStrings.xml', content: '<b/>' },
  ]);
  const zip = openZip(zipBuffer);
  assert.deepEqual(listEntryNames(zip).sort(), ['xl/sharedStrings.xml', 'xl/worksheets/sheet1.xml']);
});

test('openZip - buffer inválido lanza error descriptivo', () => {
  const buf = Buffer.from('esto no es un zip');
  const arrayBuffer = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  assert.throws(() => openZip(arrayBuffer), /no parece ser un \.xlsx válido/);
});
