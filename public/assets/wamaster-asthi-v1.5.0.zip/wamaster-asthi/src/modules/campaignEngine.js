/**
 * campaignEngine.js
 * ---------------------------------------------------------------------------
 * Orquesta el envío de una campaña: recorre los contactos, respeta
 * pausas/reanudaciones, aplica pausas aleatorias entre envíos, delega el
 * envío real a la pestaña de WhatsApp Web (a través del patrón Outbox, ver
 * ARQUITECTURA.md) y registra el resultado de cada contacto.
 *
 * v1.2.0 agregó licencia + saludos aleatorios + historial de campañas.
 * v1.2.1/v1.2.2 mejoraron el motor de variables (sin tocar este archivo).
 *
 * v1.3.0 agrega:
 *   1. restartCampaign() — vuelve a enviar la campaña COMPLETA a la misma
 *      lista de contactos ya cargada, sin reimportar el Excel.
 *   2. retryFailed() — reintenta el envío SOLO a los contactos cuyo último
 *      resultado en el registro fue "failed", sin tocar a los que ya
 *      recibieron el mensaje. Actualiza esas mismas entradas del log en vez
 *      de duplicarlas.
 *   3. Adjuntos múltiples: `attachment` (uno solo) se reemplazó por
 *      `attachments` (array). Ver _sendToContact() y content.js para cómo
 *      se agrupan por tipo (fotos vs. documentos) al enviarlos.
 *
 * Para soportar (1) y (2) sin duplicar todo el motor, _runLoop() ahora opera
 * sobre `this._activeList` (la lista de contactos de la corrida ACTUAL, que
 * puede ser todos los contactos válidos o solo el subconjunto de
 * reintento) en vez de recalcular siempre `this.contacts` directamente.
 * `this.mode` ('main' | 'retry') determina cómo se registra el historial al
 * terminar. pause()/resume()/stop() siguen funcionando igual sin importar el
 * modo, porque solo dependen de `this.status`.
 *
 * Nota (ver AUDITORIA.md, hallazgo A1): existe una condición de carrera
 * documentada en pause()/resume() bajo clics muy rápidos y sucesivos; sigue
 * sin corregirse, no forma parte del alcance de esta versión.
 *
 * v1.5.0 agrega:
 *   1. MAX_ATTACHMENTS (4): configure() ahora recorta defensivamente
 *      `attachments` a este máximo (además del recorte que ya hace la UI en
 *      sidebar.js), para que _sendToContact() nunca intente enviar más
 *      archivos de los que WhatsApp Web puede procesar de forma confiable
 *      en un solo adjunto agrupado.
 *   2. `attachmentCaption`: texto independiente del mensaje principal que,
 *      si se define, se usa como pie de foto/documento cuando hay adjuntos
 *      (en vez del mensaje principal). Si se deja vacío, el comportamiento
 *      es idéntico al de v1.3.0/v1.4.x (el mensaje principal hace de pie de
 *      foto). Se persiste y se restaura igual que `template`.
 * ---------------------------------------------------------------------------
 */

import { getItem, setItem, StorageKeys } from '../utils/storage.js';
import { renderTemplate } from './messageTemplate.js';
import { resetLog, upsertEntry, getLog, computeStats } from '../utils/logger.js';
import {
  MessageType,
  sendToBackground,
  navigateTab,
  waitForRuntimeMessage,
} from '../utils/messaging.js';
import { buildChatUrl } from '../utils/whatsappUrl.js';
import { getGreetings, isGreetingsEnabled, pickRandomGreeting } from './greetings.js';
import { getLicense, isLicenseUsable } from './licensing.js';
import { addHistoryEntry } from './campaignHistory.js';

export const CampaignStatus = Object.freeze({
  IDLE: 'idle',
  RUNNING: 'running',
  PAUSED: 'paused',
  STOPPED: 'stopped',
  COMPLETED: 'completed',
});

export const CampaignMode = Object.freeze({
  MAIN: 'main',
  RETRY: 'retry',
});

const MIN_DELAY_MS_DEFAULT = 4000;
const MAX_DELAY_MS_DEFAULT = 9000;
const SEND_CONFIRMATION_TIMEOUT_MS = 45000;
const INTERRUPT_POLL_MS = 250;
/** Máximo de archivos adjuntos por campaña (ver docs/CAMBIOS_v1.5.0.md). */
export const MAX_ATTACHMENTS = 4;

export class CampaignEngine {
  constructor() {
    /** @type {import('./contactManager.js').Contact[]} */
    this.contacts = [];
    this.template = '';
    /** @type {Array<{ dataUrl: string, fileName: string, mimeType: string }>} */
    this.attachments = [];
    /** Pie de foto/documento independiente del mensaje principal (v1.5.0). Si está vacío, se usa `template` como pie de foto. */
    this.attachmentCaption = '';
    this.delayRange = { min: MIN_DELAY_MS_DEFAULT, max: MAX_DELAY_MS_DEFAULT };
    this.status = CampaignStatus.IDLE;
    this.mode = CampaignMode.MAIN;
    this.currentIndex = 0;
    this.lastError = null;
    this._startedAt = null;
    /** @type {import('./contactManager.js').Contact[]} lista real que está recorriendo la corrida activa */
    this._activeList = [];
    this._listeners = new Set();
  }

  /** Suscribe un callback que se llama cada vez que cambia el estado del motor. */
  onChange(callback) {
    this._listeners.add(callback);
    return () => this._listeners.delete(callback);
  }

  _emit() {
    const snapshot = this.getSnapshot();
    for (const cb of this._listeners) cb(snapshot);
  }

  getSnapshot() {
    return {
      status: this.status,
      mode: this.mode,
      currentIndex: this.currentIndex,
      total: this._activeList.length || this.contacts.length,
      lastError: this.lastError,
    };
  }

  /**
   * Configura el motor antes de start(). No dispara ningún envío.
   * @param {{ contacts: any[], template: string, attachments: any[], attachmentCaption: string, delayRange: {min:number,max:number} }} config
   */
  configure({ contacts, template, attachments, attachmentCaption, delayRange }) {
    this.contacts = contacts ?? this.contacts;
    this.template = template ?? this.template;
    // Recorte defensivo: aunque la UI (sidebar.js) ya limita la selección a
    // MAX_ATTACHMENTS, el motor nunca debe confiar solo en eso — si algo
    // más llega a llamar configure() con más archivos, se descartan los
    // sobrantes en vez de intentar enviarlos y arriesgar un fallo de envío.
    this.attachments = attachments !== undefined ? attachments.slice(0, MAX_ATTACHMENTS) : this.attachments;
    this.attachmentCaption = attachmentCaption !== undefined ? attachmentCaption : this.attachmentCaption;
    if (delayRange) this.delayRange = delayRange;
    this._persist();
  }

  _validContacts() {
    return this.contacts.filter((c) => c.telefonoValido !== false);
  }

  async _validateBeforeRun(list) {
    if (!list || list.length === 0) {
      this.lastError = 'No hay contactos válidos para enviar. Revisa los números marcados como inválidos.';
      this._emit();
      return false;
    }
    if (!this.template || !this.template.trim()) {
      this.lastError = 'Escribe un mensaje antes de iniciar la campaña.';
      this._emit();
      return false;
    }
    const license = await getLicense();
    if (!isLicenseUsable(license)) {
      this.lastError =
        'Tu licencia no está activa. Ve a la pestaña Licencia para activarla antes de iniciar una campaña.';
      this._emit();
      return false;
    }
    return true;
  }

  /**
   * Inicia la campaña desde currentIndex (0 si es nueva). Valida contactos,
   * plantilla y licencia antes de arrancar.
   */
  async start() {
    if (this.status === CampaignStatus.RUNNING) return;

    const validContacts = this._validContacts();
    if (!(await this._validateBeforeRun(validContacts))) return;

    this.mode = CampaignMode.MAIN;
    this._activeList = validContacts;

    if (this.currentIndex === 0) {
      await resetLog();
      this._startedAt = Date.now();
    }

    this.status = CampaignStatus.RUNNING;
    this.lastError = null;
    this._persist();
    this._emit();
    this._runSafely();
  }

  /**
   * Vuelve a enviar la campaña COMPLETA a la misma lista de contactos ya
   * cargada (no reimporta el Excel, no borra contactos/mensaje/adjuntos).
   * Reinicia el progreso y el registro desde cero, como si fuera la primera
   * vez, pero conservando todo lo demás. Solo disponible si no hay una
   * campaña corriendo en este momento.
   */
  async restartCampaign() {
    if (this.status === CampaignStatus.RUNNING) return;
    this.currentIndex = 0;
    await this.start();
  }

  /**
   * Reintenta el envío SOLO a los contactos cuyo último resultado en el
   * registro fue "failed". No toca a los contactos que ya recibieron el
   * mensaje correctamente. Cada resultado (éxito o fallo otra vez) se
   * actualiza en la MISMA entrada del registro (logger.upsertEntry ya
   * actualiza por teléfono, no duplica), así que el Registro siempre
   * refleja el estado más reciente de cada contacto.
   */
  async retryFailed() {
    if (this.status === CampaignStatus.RUNNING) return;

    const log = await getLog();
    const failedPhones = new Set(log.filter((e) => e.status === 'failed').map((e) => e.phone));
    const retryList = this.contacts.filter((c) => c.telefonoValido !== false && failedPhones.has(c.telefono));

    if (retryList.length === 0) {
      this.lastError = 'No hay contactos fallidos para reintentar.';
      this._emit();
      return;
    }
    if (!(await this._validateBeforeRun(retryList))) return;

    this.mode = CampaignMode.RETRY;
    this._activeList = retryList;
    this.currentIndex = 0;
    // No se resetea el log completo (retryFailed conserva los envíos ya
    // exitosos); solo se resetea el punto de partida del startedAt para
    // que el historial de este reintento tenga su propia marca de tiempo.
    this._startedAt = Date.now();

    this.status = CampaignStatus.RUNNING;
    this.lastError = null;
    this._persist();
    this._emit();
    this._runSafely();
  }

  pause() {
    if (this.status !== CampaignStatus.RUNNING) return;
    this.status = CampaignStatus.PAUSED;
    this._persist();
    this._emit();
  }

  resume() {
    if (this.status !== CampaignStatus.PAUSED) return;
    this.status = CampaignStatus.RUNNING;
    this._persist();
    this._emit();
    this._runSafely();
  }

  async stop() {
    const wasActive = this.status === CampaignStatus.RUNNING || this.status === CampaignStatus.PAUSED;
    this.status = CampaignStatus.STOPPED;
    this._persist();
    this._emit();
    if (wasActive && this.currentIndex > 0) {
      await this._recordHistory('stopped');
    }
  }

  /** Limpia todo el estado del motor para empezar una campaña nueva desde cero (botón "Nueva campaña"). */
  async reset() {
    this.contacts = [];
    this.template = '';
    this.attachments = [];
    this.attachmentCaption = '';
    this.status = CampaignStatus.IDLE;
    this.mode = CampaignMode.MAIN;
    this.currentIndex = 0;
    this._activeList = [];
    this.lastError = null;
    this._startedAt = null;
    await resetLog();
    this._persist();
    this._emit();
  }

  /** Envoltorio con try/catch para que _runLoop() nunca deje una promesa rechazada sin manejar. */
  _runSafely() {
    this._runLoop().catch((err) => {
      this.lastError = err?.message || String(err);
      this.status = CampaignStatus.STOPPED;
      this._persist();
      this._emit();
    });
  }

  async _runLoop() {
    const tabResponse = await sendToBackground(MessageType.GET_WHATSAPP_TAB);
    if (!tabResponse?.tabId) {
      this.lastError = 'No se pudo abrir o encontrar una pestaña de WhatsApp Web.';
      this.status = CampaignStatus.STOPPED;
      this._persist();
      this._emit();
      return;
    }
    const tabId = tabResponse.tabId;

    const greetingsEnabled = await isGreetingsEnabled();
    const greetingsList = greetingsEnabled ? await getGreetings() : [];

    // En modo 'main' se recalcula la lista de contactos válidos en cada
    // corrida (incluida cada reanudación tras pausa), para reflejar
    // ediciones hechas mientras la campaña estaba pausada (ej. eliminar un
    // contacto). En modo 'retry' se usa el subconjunto ya congelado en
    // retryFailed(), porque ese subconjunto es justamente "a quién le tocaba
    // el reintento" y no debe cambiar a media corrida.
    const list = this.mode === CampaignMode.RETRY ? this._activeList : this._validContacts();
    this._activeList = list;

    while (this.currentIndex < list.length) {
      if (this.status === CampaignStatus.PAUSED) {
        await this._interruptibleDelay(INTERRUPT_POLL_MS);
        continue;
      }
      if (this.status !== CampaignStatus.RUNNING) {
        return; // detenida
      }

      const contact = list[this.currentIndex];
      await this._sendToContact(tabId, contact, greetingsList);

      this.currentIndex += 1;
      this._persist();
      this._emit();

      if (this.currentIndex < list.length && this.status === CampaignStatus.RUNNING) {
        await this._interruptibleDelay(this._randomDelayMs());
      }
    }

    if (this.status === CampaignStatus.RUNNING) {
      this.status = CampaignStatus.COMPLETED;
      this._persist();
      this._emit();
      await this._recordHistory('completed');
    }
  }

  /**
   * Envía el mensaje (con cero, uno o varios adjuntos) a un contacto usando
   * el patrón Outbox: se deja un PENDING_SEND_JOB, se navega la pestaña a
   * la URL click-to-chat del contacto, y se espera la confirmación que el
   * content script publica tras intentar el envío.
   */
  async _sendToContact(tabId, contact, greetingsList) {
    const contactForRender = greetingsList.length
      ? { ...contact, extra: { ...contact.extra, saludo: pickRandomGreeting(greetingsList) } }
      : contact;

    const { text } = renderTemplate(this.template, contactForRender);
    const requestId = `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    // Recorte defensivo también aquí (además de configure()), por si el
    // estado se restauró desde storage persistido de una versión anterior
    // que no tenía el tope.
    const jobAttachments = (this.attachments || []).slice(0, MAX_ATTACHMENTS);
    const hasAttachments = jobAttachments.length > 0;

    // El pie de foto/documento es independiente del mensaje principal desde
    // v1.5.0: si el usuario escribió algo en "Subtítulo del adjunto", eso es
    // lo que se usa como caption; si lo dejó vacío, se sigue usando el
    // mensaje principal como caption (comportamiento idéntico a versiones
    // anteriores, para no romper campañas que ya dependían de eso).
    const captionSource = this.attachmentCaption && this.attachmentCaption.trim()
      ? this.attachmentCaption
      : this.template;
    const { text: captionText } = renderTemplate(captionSource, contactForRender);

    const job = {
      requestId,
      phone: contact.telefono,
      text,
      caption: hasAttachments ? captionText : undefined,
      attachments: hasAttachments ? jobAttachments : [],
    };
    await setItem(StorageKeys.PENDING_SEND_JOB, job);

    const url = buildChatUrl(contact.telefono, hasAttachments ? undefined : text);
    await navigateTab(tabId, url);

    try {
      const result = await waitForRuntimeMessage(
        (msg) => msg?.type === MessageType.WHATSAPP_SEND_RESULT && msg.requestId === requestId,
        SEND_CONFIRMATION_TIMEOUT_MS
      );
      await upsertEntry({
        phone: contact.telefono,
        nombre: contact.nombre,
        status: result.success ? 'sent' : 'failed',
        errorMessage: result.success ? undefined : result.errorMessage,
        timestamp: Date.now(),
      });
    } catch (err) {
      await upsertEntry({
        phone: contact.telefono,
        nombre: contact.nombre,
        status: 'failed',
        errorMessage: err?.message || 'Tiempo de espera agotado.',
        timestamp: Date.now(),
      });
    }
  }

  _randomDelayMs() {
    const { min, max } = this.delayRange;
    const lo = Math.min(min, max);
    const hi = Math.max(min, max);
    return Math.floor(lo + Math.random() * (hi - lo));
  }

  /** Espera `ms` pero revisa el estado cada INTERRUPT_POLL_MS para poder reaccionar a pause()/stop(). */
  async _interruptibleDelay(ms) {
    const deadline = Date.now() + ms;
    while (Date.now() < deadline) {
      if (this.status !== CampaignStatus.RUNNING && this.status !== CampaignStatus.PAUSED) return;
      await new Promise((r) => setTimeout(r, Math.min(INTERRUPT_POLL_MS, deadline - Date.now())));
    }
  }

  /**
   * Registra una entrada de historial. En modo 'main' resume TODA la
   * campaña (todos los contactos, log completo). En modo 'retry' resume
   * SOLO el subconjunto que se reintentó, para que el historial distinga
   * claramente "Campaña completa" de "Reintento de fallidos".
   */
  async _recordHistory(finalStatus) {
    const log = await getLog();

    if (this.mode === CampaignMode.RETRY) {
      const retriedPhones = new Set(this._activeList.map((c) => c.telefono));
      const subsetLog = log.filter((e) => retriedPhones.has(e.phone));
      const stats = computeStats(subsetLog);
      await addHistoryEntry({
        startedAt: this._startedAt ?? Date.now(),
        finishedAt: Date.now(),
        finalStatus: finalStatus === 'completed' ? 'retry-completed' : 'retry-stopped',
        totalContacts: this._activeList.length,
        sent: stats.sent,
        failed: stats.failed,
        log: subsetLog,
      });
      return;
    }

    const stats = computeStats(log);
    await addHistoryEntry({
      startedAt: this._startedAt ?? Date.now(),
      finishedAt: Date.now(),
      finalStatus,
      totalContacts: this.contacts.length,
      sent: stats.sent,
      failed: stats.failed,
      log,
    });
  }

  _persist() {
    setItem(StorageKeys.CAMPAIGN_STATE, {
      status: this.status,
      mode: this.mode,
      currentIndex: this.currentIndex,
      contacts: this.contacts,
      template: this.template,
      attachments: this.attachments,
      attachmentCaption: this.attachmentCaption,
      delayRange: this.delayRange,
      startedAt: this._startedAt,
      // Se persiste explícitamente la lista de la corrida activa (que en
      // modo 'retry' es un subconjunto de `contacts`) para poder reanudar
      // correctamente un reintento si el panel se cierra a la mitad.
      activeList: this._activeList,
    }).catch(() => {});
  }

  /** Reconstruye un motor a partir del estado persistido (recarga del side panel). */
  static async loadPersistedState() {
    const state = await getItem(StorageKeys.CAMPAIGN_STATE, null);
    const engine = new CampaignEngine();
    if (state) {
      engine.contacts = state.contacts ?? [];
      engine.template = state.template ?? '';
      // Compatibilidad con estado persistido de versiones anteriores a
      // v1.3.0, que guardaban un único `attachment` en vez de `attachments`.
      // Se recorta a MAX_ATTACHMENTS por si el estado viene de una versión
      // anterior a v1.5.0 sin ese límite.
      engine.attachments = (state.attachments ?? (state.attachment ? [state.attachment] : [])).slice(0, MAX_ATTACHMENTS);
      // Compatibilidad con estado persistido anterior a v1.5.0 (sin este campo).
      engine.attachmentCaption = state.attachmentCaption ?? '';
      engine.delayRange = state.delayRange ?? engine.delayRange;
      engine.currentIndex = state.currentIndex ?? 0;
      engine.mode = state.mode ?? CampaignMode.MAIN;
      engine._startedAt = state.startedAt ?? null;

      if (engine.mode === CampaignMode.RETRY) {
        if (Array.isArray(state.activeList) && state.activeList.length > 0) {
          engine._activeList = state.activeList;
        } else {
          // Estado persistido antes de que existiera `activeList` (o
          // corrupto): no hay forma segura de saber a quién le tocaba un
          // reintento, así que se detiene en vez de arriesgarse a reenviar
          // al contacto equivocado.
          engine.mode = CampaignMode.MAIN;
          engine._activeList = [];
          engine.currentIndex = 0;
          state.status = CampaignStatus.STOPPED;
        }
      } else {
        // Modo 'main': siempre se recalcula desde `contacts` (no se confía
        // en la lista persistida), para reflejar ediciones hechas antes de
        // cerrar el panel.
        engine._activeList = engine._validContacts();
      }

      // Una campaña que quedó "running" al cerrar el panel se restaura como
      // pausada: nunca se reanuda sola sin que el usuario lo confirme.
      engine.status = state.status === CampaignStatus.RUNNING ? CampaignStatus.PAUSED : (state.status ?? CampaignStatus.IDLE);
    }
    return engine;
  }
}
