/**
 * messageTemplate.js
 * ---------------------------------------------------------------------------
 * Motor de plantillas de mensaje. Sintaxis soportada: variables entre llaves,
 * ej. "Hola {nombre}, tu pedido {pedido} está listo". Las variables se
 * resuelven contra el contacto: primero contra sus campos de primer nivel
 * (nombre, telefono) y luego contra `extra` (el resto de columnas del Excel
 * — CUALQUIER columna adicional, ej. {monto}, {direccion}, {empresa} — y,
 * cuando aplica, {saludo} inyectado por greetings.js — ver ese módulo).
 *
 * v1.2.1: VARIABLE_REGEX se amplió para aceptar CUALQUIER carácter dentro de
 * las llaves (excepto las llaves mismas y saltos de línea), en vez de una
 * lista fija de letras/números/acentos. Antes, un encabezado de Excel como
 * "Monto ($)", "N° Pedido" o "Fecha-Límite" generaba un botón de variable
 * que, al insertarse, NO se reconocía como variable al renderizar (el
 * carácter especial rompía la coincidencia), así que el placeholder quedaba
 * literal en el mensaje enviado. Con la expresión regular ampliada, el
 * nombre de la columna se usa tal cual, sin restricciones de caracteres,
 * manteniendo compatibilidad total con plantillas existentes que usan
 * {nombre}, {telefono}, {saludo} u otras variables ya en uso.
 *
 * v1.2.2: la resolución de variables ahora es insensible a acentos/mayúsculas
 * de verdad (antes "Dirección" en el Excel NO coincidía con {direccion}
 * escrito sin tilde) y soporta ALIAS_GROUPS: grupos de nombres equivalentes
 * para conceptos comunes (correo/email, ciudad/city, producto/artículo,
 * empresa/negocio, dirección/domicilio, monto/total, etc.). Así, si el
 * Excel trae una columna "Correo Electrónico" y el mensaje usa {email}, o
 * viceversa, se resuelve igual — sin tener que renombrar columnas ni
 * memorizar el nombre exacto de cada una. Ver ALIAS_GROUPS más abajo para
 * agregar más grupos sin tocar el resto del motor de plantillas.
 * ---------------------------------------------------------------------------
 */

const VARIABLE_REGEX = /\{([^{}\r\n]+)\}/g;

/**
 * Grupos de nombres equivalentes para columnas/variables comunes. Si el
 * nombre de variable escrito en el mensaje y una columna del Excel caen en
 * el mismo grupo (comparando de forma normalizada, ver normalizeVariableName),
 * se consideran la misma variable. Añade más arrays aquí para cubrir otros
 * conceptos frecuentes sin modificar resolveVariable().
 * @type {string[][]}
 */
const ALIAS_GROUPS = [
  ['email', 'correo', 'correo electronico', 'e-mail', 'mail'],
  ['ciudad', 'city', 'municipio', 'localidad'],
  ['producto', 'product', 'articulo', 'item'],
  ['empresa', 'company', 'negocio', 'compania', 'razon social'],
  ['direccion', 'address', 'domicilio', 'ubicacion'],
  ['monto', 'amount', 'total', 'precio', 'importe'],
  ['fecha', 'date', 'dia'],
  ['pedido', 'order', 'orden', 'folio', 'numero de pedido'],
  ['vendedor', 'asesor', 'agente', 'ejecutivo'],
  ['sucursal', 'tienda', 'branch', 'punto de venta'],
];

/**
 * Normaliza un nombre de variable/columna para compararlo de forma
 * tolerante: quita acentos, pasa a minúsculas y recorta espacios extremos.
 * Ej. "Dirección" y "direccion" y " DIRECCION " se normalizan igual.
 * @param {string} value
 * @returns {string}
 */
function normalizeVariableName(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '') // marcas de combinación (acentos)
    .trim()
    .toLowerCase();
}

/** Busca el grupo de ALIAS_GROUPS que contiene `normalizedName`, o null. */
function findAliasGroup(normalizedName) {
  return ALIAS_GROUPS.find((group) => group.includes(normalizedName)) ?? null;
}

/**
 * Extrae los nombres de variable usados en una plantilla, ej.
 * "Hola {nombre}" -> ['nombre'].
 * @param {string} template
 * @returns {string[]}
 */
export function extractVariables(template) {
  const names = new Set();
  let match;
  VARIABLE_REGEX.lastIndex = 0;
  while ((match = VARIABLE_REGEX.exec(template)) !== null) {
    names.add(match[1].trim());
  }
  return [...names];
}

/**
 * Renderiza la plantilla para un contacto concreto.
 * Si una variable no existe en el contacto, se deja el placeholder tal cual
 * (envuelto en llaves) y se reporta en `missing`, para que la UI pueda
 * advertir antes de enviar.
 *
 * @param {string} template
 * @param {import('./contactManager.js').Contact} contact
 * @returns {{ text: string, missing: string[] }}
 */
export function renderTemplate(template, contact) {
  const missing = [];
  const text = template.replace(VARIABLE_REGEX, (fullMatch, rawName) => {
    const name = rawName.trim();
    const value = resolveVariable(name, contact);
    if (value === undefined || value === null || value === '') {
      missing.push(name);
      return fullMatch;
    }
    return String(value);
  });
  return { text, missing };
}

/**
 * Resuelve el valor de una variable contra un contacto. Soporta:
 *  1. Los alias fijos de siempre: {nombre}/{name}, {telefono}/{phone}.
 *  2. Coincidencia exacta (normalizada: sin acentos, sin mayúsculas) contra
 *     cualquier columna extra del Excel — así {direccion} encuentra una
 *     columna llamada "Dirección" aunque el mensaje no lleve la tilde.
 *  3. Coincidencia por ALIAS_GROUPS: si la variable escrita y una columna
 *     del Excel pertenecen al mismo grupo (ej. "email" y "Correo
 *     Electrónico"), se resuelven igual aunque el texto no coincida.
 */
function resolveVariable(name, contact) {
  const key = normalizeVariableName(name);

  if (key === 'nombre' || key === 'name') return contact.nombre;
  if (key === 'telefono' || key === 'phone') return contact.telefono;

  if (!contact.extra) return undefined;

  // (2) Coincidencia exacta normalizada (incluye {saludo}, inyectado por
  // campaignEngine antes de renderizar).
  const exactKey = Object.keys(contact.extra).find(
    (k) => normalizeVariableName(k) === key
  );
  if (exactKey) return contact.extra[exactKey];

  // (3) Coincidencia por grupo de alias (ver ALIAS_GROUPS arriba).
  const group = findAliasGroup(key);
  if (group) {
    const aliasKey = Object.keys(contact.extra).find((k) => group.includes(normalizeVariableName(k)));
    if (aliasKey) return contact.extra[aliasKey];
  }

  return undefined;
}

/**
 * Valida una plantilla contra una muestra de contactos y devuelve un resumen
 * de qué variables faltan y en cuántos contactos. Útil para mostrar avisos
 * en la UI antes de lanzar la campaña.
 *
 * @param {string} template
 * @param {import('./contactManager.js').Contact[]} contacts
 */
export function validateTemplateAgainstContacts(template, contacts) {
  const usedVariables = extractVariables(template);
  const missingCounts = {};
  for (const contact of contacts) {
    const { missing } = renderTemplate(template, contact);
    for (const name of missing) {
      missingCounts[name] = (missingCounts[name] || 0) + 1;
    }
  }
  return { usedVariables, missingCounts };
}
