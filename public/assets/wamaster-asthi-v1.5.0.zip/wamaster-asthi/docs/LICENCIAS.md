# Sistema de licencias de WaMaster Asthi

**Estado en v1.5.0: implementado en el frontend, con backend de referencia disponible en `wamaster-web/`.** Desde v1.4.0 la extensión se autentica con **correo y contraseña** contra un backend REST propio (no con una clave de licencia pegada a mano) — la extensión nunca accede a la base de datos del proveedor directamente ni guarda la contraseña; solo cachea un token de sesión de corta vida. Ver `docs/LICENSE_BACKEND.md` para el contrato de API exacto.

## 1. Advertencia honesta

Una extensión de Chrome sin empaquetar (o incluso empaquetada como `.crx`) es código que corre en la máquina del usuario y que puede leerse y editarse. **Ninguna validación que dependa solo de código y datos que viven en el frontend es, en última instancia, imposible de saltar** — alguien con suficiente motivación puede editar `licensing.js` para que `isLicenseUsable()` siempre devuelva `true`. Por eso este sistema no promete DRM irrompible: promete que la validación real (¿esta cuenta existe, tiene una suscripción pagada, sigue vigente?) siempre depende de una respuesta del backend, y que el frontend nunca "sabe" el secreto que decide eso — como mucho, puede confiar en una respuesta cacheada por un tiempo limitado (ver período de gracia, sección 4).

## 2. Qué se implementó en el frontend

| Pieza | Archivo | Responsabilidad |
|---|---|---|
| Identidad de instalación | `src/modules/deviceId.js` | Genera y persiste un UUID aleatorio por instalación (`installationId`), no es un ID de hardware ni de usuario. |
| Lógica de licencias | `src/modules/licensing.js` | Login (correo+contraseña), revalidar sesión, cerrar sesión; calcula el estado (`active`/`grace`/`expired`/`invalid`/`inactive`); aplica el período de gracia sin red. |
| Persistencia | `src/utils/storage.js` | `StorageKeys.LICENSE` (registro cacheado, incluye el token de sesión), `LICENSE_API_BASE` (URL del backend), `LICENSE_DEV_BYPASS` (modo de prueba local), `INSTALLATION_ID`. |
| Integración con campañas | `src/modules/campaignEngine.js` | `start()`/`restartCampaign()`/`retryFailed()` rechazan lanzar una campaña si `isLicenseUsable(license)` es `false`. |
| UI | `src/sidebar/sidebar.html` / `.js` | Pantalla de inicio de sesión (correo + contraseña + país obligatorio + modo de prueba local + URL de backend avanzada), chip de estado en el header, tarjeta de estado con cuenta/plan/vencimiento/país, botón de cerrar sesión. |

## 3. Modelo de datos

### Registro cacheado localmente (`StorageKeys.LICENSE`)

```js
{
  email: "cliente@ejemplo.com",
  status: "active" | "grace" | "expired" | "invalid" | "inactive",
  planId: "trial" | "basic" | "pro" | "agency",
  planLabel: "Pro",              // texto libre que decide el backend
  key: "WAM-XXXX-XXXX-XXXX" | null,  // clave de licencia de referencia, ya no la escribe el usuario
  expiresAt: 1735689600000 | null,
  lastValidatedAt: 1722950400000,
  installationId: "5f2e...-uuid",
  token: "a3f9...(token de sesión)" | null,  // NUNCA la contraseña
  devBypass: false,
}
```

La contraseña del usuario **nunca** se guarda en la extensión, ni siquiera temporalmente: `activateLicense(email, password)` la envía una sola vez en el `POST /v1/auth/login` y descarta la variable; lo único que persiste es el `token` que el backend devuelve.

## 4. Flujos

### 4.1 Inicio de sesión

1. El usuario abre la pestaña Licencia, ingresa su correo y contraseña (los que le compartió el proveedor de WaMaster Asthi), **selecciona su país/código telefónico (campo obligatorio, se guarda como predeterminado para normalizar teléfonos importados)**, y opcionalmente activa "Modo de prueba local" si todavía no hay backend.
2. `activateLicense(email, password)`:
   - Si `devBypass` está activo: genera un registro local `ACTIVE` / plan `PRO` sin red (`devBypass: true`, `token: null`, visible en la UI).
   - Si no: `POST {LICENSE_API_BASE}/v1/auth/login` con `{ email, password, installationId, deviceName }`. Si el backend responde `valid: true`, se cachea el resultado (incluido el `token`); si no, se muestra el mensaje de error del backend (ej. "Correo o contraseña incorrectos") y no se guarda nada.

### 4.2 Revalidación periódica y período de gracia

- Mientras el side panel esté abierto, `scheduleRevalidation()` llama a `revalidateLicense()` al abrir y luego cada 12 horas.
- `revalidateLicense()` hace `POST /v1/licenses/session` con `Authorization: Bearer <token>` (nunca vuelve a pedir la contraseña) y distingue tres desenlaces:
  - **401** (sesión muerta/token inválido) → `INVALID`, se limpia el token — el usuario debe volver a iniciar sesión.
  - **200 con `valid:false`** (sesión viva, pero la licencia no es utilizable — suspendida o vencida) → `EXPIRED`, se **conserva** el token: si el admin reactiva la licencia, la siguiente revalidación se recupera sola sin pedir login de nuevo.
  - **Fallo de red** (no un rechazo explícito del backend) → se conserva el último estado conocido, degradado a `GRACE` si no han pasado más de **7 días** desde la última validación exitosa, o a `EXPIRED` si ya se agotó ese margen.
- `isLicenseUsable()` considera `ACTIVE` y `GRACE` como utilizables — así la extensión sigue funcionando sin conexión al backend por un tiempo razonable, pero no indefinidamente.

### 4.3 Cierre de sesión

`deactivateLicense()` intenta avisar al backend (`POST /v1/auth/logout` con `Authorization: Bearer <token>`) para invalidar la sesión y liberar el cupo de activación del dispositivo, y siempre limpia el registro local aunque la llamada falle (para no dejar al usuario con una sesión "atascada" localmente).

### 4.4 Compatibilidad con instalaciones anteriores a v1.4.0

Si una instalación tiene un registro local activado por clave (sin `token`, formato de antes de v1.4.0), `revalidateLicense()` lo marca `INVALID` sin llamar al backend — fuerza al usuario a iniciar sesión de nuevo con correo/contraseña. El backend de referencia sigue exponiendo las rutas legadas por clave (`/v1/licenses/activate|validate|deactivate`) por si necesitas mantener otra integración aparte.

## 5. Planes y suscripciones

`PlanId` (`src/modules/licensing.js`) define `trial`, `basic`, `pro`, `agency` como identificadores estables; el nombre visible (`planLabel`) y cualquier límite asociado a cada plan lo decide el backend y se muestra tal cual lo devuelva. Desde la versión del backend con pagos integrados (ver `wamaster-web/docs/PAGOS.md`), una licencia puede además renovarse automáticamente cuando el cliente paga un nuevo período a través de Mercado Pago — la extensión no necesita ningún cambio para esto, porque solo consume `status`/`expiresAt`, sin importar si la licencia se activó/renovó manualmente desde el panel admin o automáticamente por un pago confirmado.

## 6. Próximos pasos para producción

1. Desplegar el backend de referencia (`wamaster-web/`, ver su propio README y `docs/DESPLIEGUE.md` para Render/Railway).
2. Configurar `LICENSE_API_BASE` en la extensión (se puede fijar en la UI en "Opciones avanzadas", o precargarse en `chrome.storage.local` desde un script de instalación en un build de producción).
3. Quitar o esconder el checkbox de "Modo de prueba local" del build que se distribuya a clientes finales (es una herramienta de desarrollo, no de producción).
4. Si vendes por suscripción con pago automático, configurar las credenciales de Mercado Pago en el backend (ver `wamaster-web/docs/PAGOS.md`).
