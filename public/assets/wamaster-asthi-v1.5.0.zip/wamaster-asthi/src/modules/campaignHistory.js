/**
 * campaignHistory.js
 * ---------------------------------------------------------------------------
 * Historial de campañas (v1.2.0). Cada vez que una campaña termina
 * (completada o detenida manualmente con al menos un envío realizado),
 * campaignEngine.js guarda una "instantánea" (snapshot) con sus estadísticas
 * y el log completo de esa corrida, para poder listarla y descargarla luego
 * aunque el usuario ya haya iniciado una campaña nueva ("Nueva campaña"
 * limpia el estado activo, pero NO borra el historial).
 *
 * Persistencia: StorageKeys.CAMPAIGN_HISTORY (array de HistoryEntry), vía
 * storage.js. Se limita a MAX_HISTORY_ENTRIES para no crecer sin límite.
 * ---------------------------------------------------------------------------
 */

import { getItem, setItem, StorageKeys } from '../utils/storage.js';

const MAX_HISTORY_ENTRIES = 50;

/**
 * @typedef {Object} HistoryEntry
 * @property {string} id
 * @property {number} startedAt
 * @property {number} finishedAt
 * @property {'completed'|'stopped'} finalStatus
 * @property {number} totalContacts
 * @property {number} sent
 * @property {number} failed
 * @property {Array<import('../utils/logger.js').LogEntry>} log
 */

/** @returns {Promise<HistoryEntry[]>} */
export async function getHistory() {
  return getItem(StorageKeys.CAMPAIGN_HISTORY, []);
}

/**
 * Agrega una entrada al historial (al principio, más reciente primero) y
 * recorta al máximo permitido.
 * @param {Omit<HistoryEntry, 'id'>} entry
 * @returns {Promise<HistoryEntry>}
 */
export async function addHistoryEntry(entry) {
  const history = await getHistory();
  const full = { id: `camp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, ...entry };
  const updated = [full, ...history].slice(0, MAX_HISTORY_ENTRIES);
  await setItem(StorageKeys.CAMPAIGN_HISTORY, updated);
  return full;
}

/** Vacía todo el historial. */
export async function clearHistory() {
  await setItem(StorageKeys.CAMPAIGN_HISTORY, []);
}

/** Busca una entrada del historial por id, o null. */
export async function getHistoryEntry(id) {
  const history = await getHistory();
  return history.find((h) => h.id === id) ?? null;
}
