import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';

let getHistory, addHistoryEntry, clearHistory, getHistoryEntry;

beforeEach(async () => {
  const mock = createChromeMock();
  globalThis.chrome = mock.chrome;
  const mod = await import(`../src/modules/campaignHistory.js?t=${Date.now()}_${Math.random()}`);
  ({ getHistory, addHistoryEntry, clearHistory, getHistoryEntry } = mod);
});

test('getHistory - vacío al inicio', async () => {
  assert.deepEqual(await getHistory(), []);
});

test('addHistoryEntry - agrega al principio (más reciente primero) y asigna id', async () => {
  const first = await addHistoryEntry({ startedAt: 1, finishedAt: 2, finalStatus: 'completed', totalContacts: 2, sent: 2, failed: 0, log: [] });
  const second = await addHistoryEntry({ startedAt: 3, finishedAt: 4, finalStatus: 'stopped', totalContacts: 1, sent: 0, failed: 1, log: [] });
  const history = await getHistory();
  assert.equal(history.length, 2);
  assert.equal(history[0].id, second.id);
  assert.equal(history[1].id, first.id);
});

test('getHistoryEntry - busca por id', async () => {
  const entry = await addHistoryEntry({ startedAt: 1, finishedAt: 2, finalStatus: 'completed', totalContacts: 1, sent: 1, failed: 0, log: [] });
  const found = await getHistoryEntry(entry.id);
  assert.equal(found.id, entry.id);
  assert.equal(await getHistoryEntry('no-existe'), null);
});

test('clearHistory - vacía todo', async () => {
  await addHistoryEntry({ startedAt: 1, finishedAt: 2, finalStatus: 'completed', totalContacts: 1, sent: 1, failed: 0, log: [] });
  await clearHistory();
  assert.deepEqual(await getHistory(), []);
});
