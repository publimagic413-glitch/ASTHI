# Plan de pruebas manuales — WaMaster Asthi v1.2.0

Pruebas a ejecutar en Chrome real con una sesión activa de WhatsApp Web, ya que `npm test` solo cubre lógica pura con mocks (ver `tests/`). Se marca con **[NUEVO v1.2.0]** lo que no existía en v1.1.

## B1 — Instalación y detección

- B1.1 Cargar la extensión sin empaquetar en `chrome://extensions` (Windows y macOS) y confirmar que no hay errores en la consola del service worker.
- B1.2 El ícono de la extensión abre el side panel al hacer clic.
- B1.3 **[NUEVO]** El header muestra "WaMaster Asthi" y el badge "v1.2.0".

## B2 — Licencia **[NUEVO v1.2.0]**

- B2.1 Sin licencia activa, la sección Licencia muestra el formulario de activación; el campo País es obligatorio (el formulario no debe dejar activar sin seleccionar uno).
- B2.2 Activar "Modo de prueba local", ingresar cualquier clave, activar: el chip del header pasa a "Licencia: Activa" y la tarjeta de estado muestra plan "PRO (modo de prueba local)".
- B2.3 Con un backend de prueba real (o un servidor mock que siga el contrato de `docs/LICENSE_BACKEND.md`), activar con una clave válida y confirmar el plan/vencimiento mostrado coincide con la respuesta del backend.
- B2.4 Activar con una clave que el backend rechace: se muestra el mensaje de error, no se activa nada.
- B2.5 Sin backend configurado y sin modo de prueba local: intentar activar muestra el error "No hay backend de licencias configurado...".
- B2.6 Desactivar licencia: vuelve a mostrarse el formulario de activación.
- B2.7 Sin licencia activa, intentar "Iniciar" una campaña con contactos y mensaje válidos: debe rechazarse con el mensaje "Tu licencia no está activa...".

## B3 — Importación de Excel y país/teléfono **[país/normalización es NUEVO v1.2.0]**

- B3.1 Importar un `.xlsx` con columnas "Nombre" y "Teléfono" (números completos con código de país): deben quedar exactamente igual en "Teléfono final".
- B3.2 Importar un `.xlsx` con números **locales** (sin código de país, ej. `5512345678` en vez de `525512345678` para México): con país "México (+52)" seleccionado, "Teléfono final" debe anteponer `52` automáticamente. "Teléfono original" debe mostrar el número tal cual venía del Excel.
- B3.3 Importar una mezcla de números ya con código y números locales en el mismo archivo: ninguno debe quedar con el código duplicado.
- B3.4 Importar un archivo con un número claramente inválido (muy corto, con letras, vacío): la fila debe marcarse con el badge "Inválido" y quedar excluida si se inicia la campaña.
- B3.5 Botón "Descargar inválidos": genera un CSV con Nombre, Teléfono original y Teléfono final de solo los contactos inválidos.
- B3.6 El buscador filtra por nombre y por teléfono; los contadores (Total/Válidos/Inválidos/Enviados/Fallidos) se actualizan en vivo.
- B3.7 El botón "✕" de una fila elimina solo ese contacto de la lista y de la campaña configurada.

## B4 — Mensaje, variables y emojis

- B4.1 Los botones de variable reflejan exactamente las columnas del Excel importado (más `{saludo}`), y al hacer clic insertan el texto en la posición del cursor, no siempre al final.
- B4.2 La vista previa refleja el primer contacto en tiempo real al escribir.
- B4.3 **[NUEVO]** El botón de emoji abre una paleta; al elegir un emoji se inserta en la posición del cursor del mensaje, sin perder el resto del texto ya escrito.
- B4.4 **[NUEVO]** Insertar un emoji entre dos variables (ej. `{nombre} 😀 {telefono}`) y confirmar que la vista previa y el envío real conservan el emoji intacto (no se corrompe la codificación UTF-8/surrogate pairs de emojis compuestos).
- B4.5 **Caso de riesgo (corregido en v1.2.0, ver `docs/CAMBIOS_v1.2.0.md` sección 2.3):** enviar un mensaje con imagen adjunta y texto de pie de foto a un número real de prueba. Confirmar que llega **un solo** mensaje (la imagen con su pie de foto), no dos mensajes separados (uno de texto suelto y otro la imagen). Repetir con un PDF.
- B4.6 Enviar un mensaje sin adjunto (solo texto) y confirmar que llega una sola vez.

## B5 — Saludos aleatorios **[NUEVO v1.2.0]**

- B5.1 Con la sección desactivada, `{saludo}` en la plantilla queda como placeholder sin resolver (se advierte en la vista previa).
- B5.2 Activar, guardar una lista de saludos, iniciar una campaña de varios contactos: revisar en el Registro/Historial que distintos contactos recibieron saludos distintos (no siempre el mismo).
- B5.3 Guardar la lista con líneas vacías: deben descartarse (no debe quedar un saludo vacío elegible).

## B6 — Control de campaña (casos heredados de v1.1, siguen vigentes)

- B6.1 Iniciar, ver la barra de progreso avanzar contacto por contacto con pausas visibles entre envíos.
- B6.2 Pausar a mitad de campaña: el envío en curso no se interrumpe abruptamente, pero no arranca el siguiente hasta Reanudar.
- B6.3 Reanudar continúa desde el mismo índice, no repite contactos ya enviados.
- B6.4 Detener: el estado pasa a "detenida" y no se puede reanudar (hay que usar Nueva campaña o Iniciar de nuevo, que reinicia desde 0 si `currentIndex` se reinició).
- B6.5 Cerrar y reabrir el side panel a mitad de una campaña "en ejecución": debe restaurarse como "pausada" (nunca reanuda sola sin confirmación del usuario).
- B6.6 **Caso de riesgo conocido (A1, ver `docs/AUDITORIA.md`, no corregido en v1.2.0):** pulsar Pausar y Reanudar varias veces muy rápido seguidas; verificar si se duplica algún envío o si el contador se desincroniza. Reportar si ocurre.
- B6.7 Con el número de teléfono de destino inválido según WhatsApp (aviso "número inválido" de WhatsApp Web), el contacto debe registrarse como "Fallido" con un mensaje de error, y la campaña debe continuar con el siguiente contacto (no debe detenerse toda la campaña).

## B7 — Nueva campaña **[NUEVO v1.2.0]**

- B7.1 Con una campaña en curso o completada, pulsar "Nueva campaña": debe pedir confirmación.
- B7.2 Al confirmar: se limpian contactos, mensaje, adjunto, búsqueda y progreso; la campaña vuelve a "inactiva".
- B7.3 La licencia y los saludos configurados **no** deben borrarse (son configuración persistente, no parte de "una campaña").

## B8 — Historial de campañas **[NUEVO v1.2.0]**

- B8.1 Al completar una campaña, aparece una entrada nueva en Historial con fecha, estado final y conteo de enviados/fallidos.
- B8.2 Al detener una campaña manualmente después de al menos un envío, también debe registrarse en el historial con estado "Detenida".
- B8.3 Detener una campaña sin haber enviado nada (currentIndex = 0) NO debe generar una entrada de historial vacía.
- B8.4 "Descargar enviados" / "Descargar fallidos" generan CSV correctos solo con las filas correspondientes de esa campaña.
- B8.5 "Reporte completo" descarga un JSON con todos los metadatos y el log completo de esa campaña.
- B8.6 El historial persiste entre reinicios de Chrome (no se pierde al cerrar el side panel).

## B9 — Regresión de interfaz (cambios visuales de v1.2.0 no deben romper flujo)

- B9.1 Todas las secciones son visibles y usables en el ancho mínimo típico de un side panel de Chrome (~320–400px).
- B9.2 Los colores siguen la paleta navy/dorado/blanco en todas las secciones nuevas (Licencia, Saludos, Historial).
- B9.3 Los badges de estado de contacto (Pendiente/Enviado/Fallido/Inválido) son visualmente distinguibles entre sí.

## Notas

- Las pruebas B4.5, B6.x y B8.x requieren una cuenta de WhatsApp de prueba y números de destino que el operador controle (nunca probar envíos masivos reales contra contactos que no dieron consentimiento).
- Cualquier hallazgo de estas pruebas manuales que implique un bug de lógica pura (no de interacción con el DOM real de WhatsApp Web) debería convertirse en un caso automatizado dentro de `tests/`.
