import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';

let getInstallationId;

beforeEach(async () => {
  const mock = createChromeMock();
  globalThis.chrome = mock.chrome;
  const mod = await import(`../src/modules/deviceId.js?t=${Date.now()}_${Math.random()}`);
  ({ getInstallationId } = mod);
});

test('getInstallationId - genera un id la primera vez', async () => {
  const id = await getInstallationId();
  assert.match(id, /^[0-9a-f-]{36}$/i);
});

test('getInstallationId - devuelve el mismo id en llamadas subsecuentes', async () => {
  const first = await getInstallationId();
  const second = await getInstallationId();
  assert.equal(first, second);
});
