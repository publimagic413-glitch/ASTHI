# Auditoría de código — WaMaster Asthi

Hallazgos vigentes a partir de v1.2.0. Los marcados **(v1.2.0)** son nuevos en esta versión; el resto vienen de versiones anteriores y siguen sin corregir salvo que se indique lo contrario.

| ID | Severidad | Resumen |
|---|---|---|
| A1 | Alta | Condición de carrera en `pause()`/`resume()` con clics muy rápidos |
| A2 | Media | Selectores de WhatsApp Web frágiles ante cambios de interfaz |
| A5 | Media | `logger.upsertEntry()` es O(n) por llamada (O(n²) acumulado en campañas grandes) |
| A10 | Baja | `sleep(1500)` fijo tras "Continuar al chat" en vez de espera por condición |
| A16 | Baja | Uso de `document.execCommand` (deprecado) para escribir en cuadros contenteditable |
| A21 | Media **(v1.2.0)** | Heurística de país/teléfono puede fallar con números locales largos |
| A22 | Baja **(v1.2.0)** | El "Modo de prueba local" de licencias debe removerse manualmente antes de distribuir a producción |
| A23 | Info **(v1.2.0)** | Corrección de mensaje duplicado con adjuntos no se pudo validar contra WhatsApp Web real |

## A1 — Condición de carrera en pause()/resume() (Alta, no corregida)

`_runLoop()` lee `this.status` en cada iteración del `while`. Si el usuario pulsa Pausar y Reanudar muy rápido seguido, es teóricamente posible que dos invocaciones de `_runSafely()` corran en paralelo (una desde `start()`/`resume()` anterior que aún no había terminado su `await` pendiente, y otra desde el nuevo `resume()`), enviando el mismo contacto dos veces o desincronizando `currentIndex`.

**Solución propuesta (no implementada en v1.2.0, fuera de alcance de esta entrega):** agregar una bandera `_loopActive` que `_runLoop()` verifique al entrar y que impida que dos instancias del bucle corran simultáneamente:

```js
async _runLoop() {
  if (this._loopActive) return;
  this._loopActive = true;
  try {
    // ... cuerpo actual ...
  } finally {
    this._loopActive = false;
  }
}
```

## A2 — Selectores frágiles (Media)

Mitigado con listas de selectores de respaldo por elemento (`CANDIDATES` en `whatsappSelectors.js`), pero no eliminado: un cambio de interfaz de WhatsApp Web puede romper el envío hasta que se actualicen los selectores. Recomendación: monitoreo/alertas si la tasa de fallos de envío sube de forma anómala.

## A5 — `upsertEntry()` O(n) por llamada (Media)

Cada envío reescribe el array completo del log. Aceptable para los volúmenes objetivo (cientos de contactos); si se escala a miles, considerar una estructura indexada por teléfono en memoria con flush periódico a storage.

## A10 — Espera fija de 1500ms (Baja)

`content.js`, tras hacer clic en "Continuar al chat", espera un tiempo fijo en vez de esperar a una condición (ej. que el compositor esté listo). Funciona en la práctica pero es un punto de fragilidad si WhatsApp Web se vuelve más lento en cargar.

## A16 — `document.execCommand` deprecado (Baja)

Sigue siendo, en la práctica, el mecanismo más confiable para que React (framework de WhatsApp Web) detecte cambios de texto en cuadros `contenteditable`. Reemplazarlo por `InputEvent` nativos simulados es más robusto a largo plazo pero significativamente más complejo; queda como mejora futura.

## A21 — Heurística de país/teléfono (Media, nuevo v1.2.0)

Ver `docs/CAMBIOS_v1.2.0.md` sección 2.1 para el detalle completo de la regla y sus límites. Mitigado mostrando siempre "Teléfono original" junto a "Teléfono final" en la tabla, para que el usuario pueda detectar y corregir manualmente casos raros.

## A22 — Modo de prueba local de licencias (Baja, nuevo v1.2.0)

Es una herramienta de desarrollo necesaria mientras no exista backend desplegado. Riesgo: si se olvida remover el checkbox de la UI en un build de producción, cualquier usuario podría "activarse" sin pagar. Recomendación explícita en `docs/LICENCIAS.md` sección 6.

## A23 — Corrección de adjuntos no validada en vivo (Info, nuevo v1.2.0)

El fix de mensaje duplicado (ver `docs/CAMBIOS_v1.2.0.md` sección 2.3) se implementó y se razonó cuidadosamente, pero no se pudo ejecutar contra una sesión real de WhatsApp Web en este entorno de desarrollo (sin navegador con sesión disponible). Cubierto por la prueba manual B4.5 en `docs/PLAN_PRUEBAS.md` — se recomienda ejecutarla antes de una campaña con adjuntos a gran escala.

## Priorización sugerida para la próxima versión

1. A1 (condición de carrera) — alta, afecta la integridad de campañas activas.
2. A21 (heurística de país) — media, afecta la entregabilidad si se importan números locales atípicos.
3. A2 / A23 — mantenimiento continuo ante cambios de WhatsApp Web.
4. A5, A10, A16 — mejoras técnicas de menor impacto inmediato.
