/**
 * greetings.js
 * ---------------------------------------------------------------------------
 * Saludos aleatorios (v1.2.0). Lista editable de frases de saludo que, si
 * está activada, campaignEngine.js inyecta como variable {saludo} antes de
 * renderizar la plantilla de cada contacto — eligiendo una al azar por
 * envío para que los mensajes no sean idénticos entre sí.
 *
 * Persistencia: StorageKeys.GREETINGS_LIST (array de strings) y
 * StorageKeys.GREETINGS_ENABLED (boolean), vía storage.js.
 * ---------------------------------------------------------------------------
 */

import { getItem, setItem, StorageKeys } from '../utils/storage.js';

export const DEFAULT_GREETINGS = [
  'Hola',
  'Buenos días',
  'Buenas tardes',
  'Qué tal',
  'Hola, ¿cómo estás?',
];

/** @returns {Promise<string[]>} */
export async function getGreetings() {
  const list = await getItem(StorageKeys.GREETINGS_LIST, null);
  return Array.isArray(list) && list.length > 0 ? list : [...DEFAULT_GREETINGS];
}

/** @param {string[]} list */
export async function setGreetings(list) {
  const cleaned = (list || [])
    .map((s) => String(s ?? '').trim())
    .filter((s) => s.length > 0);
  await setItem(StorageKeys.GREETINGS_LIST, cleaned);
  return cleaned;
}

/** @returns {Promise<boolean>} */
export async function isGreetingsEnabled() {
  return getItem(StorageKeys.GREETINGS_ENABLED, false);
}

/** @param {boolean} enabled */
export async function setGreetingsEnabled(enabled) {
  await setItem(StorageKeys.GREETINGS_ENABLED, Boolean(enabled));
}

/**
 * Elige un saludo al azar de la lista. Devuelve cadena vacía si la lista
 * está vacía (para no romper el renderizado de plantillas).
 * @param {string[]} list
 * @returns {string}
 */
export function pickRandomGreeting(list) {
  if (!list || list.length === 0) return '';
  const idx = Math.floor(Math.random() * list.length);
  return list[idx];
}
