# Resumen de cambios — v1.3.0 → v1.5.0

Esta versión se construyó en un solo paso a partir del v1.3.0 que compartiste (adjuntos múltiples, pestañas Campaña/Licencia, reenvío/reintento), integrando la autenticación por correo y contraseña, y agregando el tope de 4 adjuntos y el subtítulo independiente.

## Qué se pidió

> Ajusta el código de la extensión para que permita cargar y enviar archivos adjuntos como imágenes y PDFs, y asegúrate de que funcione correctamente para evitar mensajes fallidos. Además, modifica la funcionalidad para que el usuario pueda seleccionar y adjuntar hasta cuatro archivos en un solo envío. y si permites que debajo del archivo adjuntar se pueda poner subtítulo

Más, de una solicitud previa en la misma sesión: reemplazar la activación por clave de licencia por inicio de sesión con correo y contraseña contra un backend REST propio, sin que la extensión toque nunca la base de datos directamente.

## 1. Autenticación por correo y contraseña (antes v1.4.0/v1.4.1, integrado aquí)

- `src/modules/licensing.js`: reescrito. `activateLicense(email, password)` reemplaza a `activateLicense(key)`. Hace `POST /v1/auth/login`, guarda únicamente el `token` de sesión que devuelve el backend — **nunca la contraseña**. `revalidateLicense()` usa `POST /v1/licenses/session` con `Authorization: Bearer <token>` y distingue tres desenlaces (sesión muerta → `INVALID` + limpia token; licencia no utilizable pero sesión viva → `EXPIRED` + conserva token para autorecuperarse si se reactiva; fallo de red → período de gracia de 7 días). `deactivateLicense()` usa `POST /v1/auth/logout`.
- `getApiBase()` apunta por defecto a `http://localhost:4000` (antes requería configurarlo a mano) para que la extensión funcione "de fábrica" contra el backend de referencia corriendo en local.
- `manifest.json`: `host_permissions` ahora incluye `http://localhost/*` y `http://127.0.0.1/*` (Chrome no permite especificar el puerto en un match pattern, así que sin puerto cubre cualquiera, incluido `:4000`); CSP `connect-src` agrega `http://localhost:*`.
- `src/sidebar/sidebar.html`/`.js`: el formulario de licencia ahora pide correo y contraseña (`licenseEmailInput`/`licensePasswordInput`) en vez de una clave; la tarjeta de estado muestra la cuenta (`licenseEmailLabel`); el botón pasó de "Desactivar licencia" a "Cerrar sesión".
- Registros heredados (activados por clave antes de v1.4.0, sin `token`) se marcan `INVALID` automáticamente en la primera revalidación, sin llamar a la red — fuerza a iniciar sesión de nuevo con correo/contraseña.

## 2. Adjuntos: máximo 4 archivos por campaña

- `src/modules/campaignEngine.js` exporta `MAX_ATTACHMENTS = 4`. `configure()` recorta defensivamente `attachments` a ese máximo (además del recorte que ya hace la UI), y `_sendToContact()` vuelve a recortar por si el estado persistido viene de una versión anterior sin el límite — así el motor nunca intenta enviar más de 4 archivos aunque algo más arriba falle en aplicarlo.
- `src/sidebar/sidebar.js`: `onAttachmentsSelected()` ahora limita la selección acumulada a 4. Si el usuario elige de más, se agregan los que quepan y se muestra un mensaje visible (`attachmentError`) indicando cuántos se descartaron. El selector de archivos se deshabilita automáticamente al llegar al tope, y un contador (`attachmentCountLabel`, "N / 4 archivos seleccionados") siempre está visible.
- `content.js` valida también del lado del envío: si por cualquier motivo llega un job con más de 4 adjuntos, aborta con un error claro antes de tocar WhatsApp Web, en vez de intentar procesar una selección inesperadamente grande.

## 3. Subtítulo del adjunto (independiente del mensaje principal)

- Nuevo campo "Subtítulo del adjunto (opcional)" debajo de la sección Adjuntos, con las mismas variables disponibles que el mensaje principal (`{nombre}`, etc.).
- `campaignEngine.js`: nuevo estado `attachmentCaption`, persistido y restaurado igual que `template`. En `_sendToContact()`, si `attachmentCaption` tiene contenido, se usa como pie de foto/documento (`job.caption`) **en vez de** el mensaje principal; si se deja vacío, el pie de foto sigue siendo el mensaje principal — comportamiento idéntico al de versiones anteriores, para no romper campañas existentes que dependían de eso.
- `content.js`: `sendWithAttachments()` ahora escribe `job.caption` (con fallback a `job.text` por compatibilidad) en la caja de pie de foto de WhatsApp Web, en vez de `job.text` directamente.

## 4. Confiabilidad del envío con adjuntos (evitar mensajes fallidos)

- La pausa después de asignar los archivos al input de WhatsApp Web ahora **escala con la cantidad de adjuntos** (1.2s base + 0.4s por archivo adicional), en vez de una pausa fija de 1.2s para cualquier cantidad — WhatsApp Web tarda más en generar las vistas previas de 3-4 archivos que de uno solo, y la pausa fija se quedaba corta en ese caso.
- Nueva verificación: después de asignar los archivos vía `DataTransfer`, se comprueba que `fileInput.files.length` coincida exactamente con la cantidad de archivos que se intentó asignar. Si no coincide, se aborta con un error descriptivo (`"Solo se asignaron X de Y archivos..."`) en vez de continuar e intentar enviar un adjunto incompleto sin que quede registrado como fallo real.
- El tope de 4 adjuntos en sí mismo es también una medida de confiabilidad: WhatsApp Web se vuelve más lento e impredecible con selecciones más grandes; 4 es un límite conservador que se mantiene dentro de lo que la interfaz maneja de forma consistente.

## Qué NO cambió

- La lógica de agrupar todos los adjuntos en un solo `DataTransfer`, la detección "todas imágenes → flujo Fotos y videos, si no → flujo Documento", y la limpieza defensiva del cuadro de texto principal (corrección del bug de mensaje duplicado de v1.2.0) — todo eso sigue igual.
- `restartCampaign()`/`retryFailed()`, las pestañas Campaña/Licencia, saludos aleatorios, historial de campañas — sin cambios funcionales.

## Verificación

- `npm test` → **116/116 pruebas en verde** (109 heredadas de v1.3.0+v1.4.x + 7 nuevas: tope de `MAX_ATTACHMENTS` en `configure()` y en `loadPersistedState()`, subtítulo independiente del mensaje principal, subtítulo ignorado sin adjuntos, `reset()` limpia el subtítulo).
- `manifest.json` y `package.json` verificados como JSON válido.
- `node --check` en todos los archivos modificados.

## Archivos modificados en esta versión

- `src/modules/licensing.js` — reescrito para correo/contraseña + token.
- `src/modules/campaignEngine.js` — `MAX_ATTACHMENTS`, `attachmentCaption`, recorte defensivo, caption en el job.
- `src/content/content.js` — `job.caption`, verificación de asignación de archivos, pausa escalada, tope defensivo.
- `src/sidebar/sidebar.html` — formulario de login por correo/contraseña, contador de adjuntos, campo de subtítulo.
- `src/sidebar/sidebar.js` — lógica de login por correo/contraseña, tope de adjuntos con aviso, subtítulo.
- `src/sidebar/sidebar.css` — estilos de `input[type=email]`/`input[type=password]` (faltaban en el selector genérico).
- `manifest.json` — versión `1.5.0`, `host_permissions` con localhost, CSP con `http://localhost:*`.
- `package.json` — versión `1.5.0`.
- `tests/licensing.test.js` — reescrito para el flujo de token.
- `tests/campaignEngine.test.js` — 7 pruebas nuevas de adjuntos/subtítulo.
- `docs/LICENCIAS.md`, `docs/LICENSE_BACKEND.md` — reescritos para el modelo de auth por correo/contraseña y mención al backend de pagos.
- `docs/CAMBIOS_v1.5.0.md` — este documento.
