/**
 * storage.js
 * ---------------------------------------------------------------------------
 * Envoltorio (wrapper) sobre chrome.storage.local que expone una API basada
 * en Promesas. Toda persistencia de WaMaster Asthi pasa por este módulo para
 * que el resto de la app nunca hable directamente con la API de Chrome.
 *
 * Ventaja de arquitectura: si en el futuro se migra a chrome.storage.sync,
 * IndexedDB, o un backend remoto, solo este archivo necesita cambiar.
 * ---------------------------------------------------------------------------
 */

const NAMESPACE = 'wamasterAsthi';

/** Construye la clave completa con el namespace de la app. */
function nsKey(key) {
  return `${NAMESPACE}:${key}`;
}

/**
 * Obtiene un valor por clave.
 * @param {string} key
 * @param {*} [defaultValue] - valor a devolver si la clave no existe.
 * @returns {Promise<*>}
 */
export async function getItem(key, defaultValue = null) {
  const fullKey = nsKey(key);
  const result = await chrome.storage.local.get(fullKey);
  return Object.prototype.hasOwnProperty.call(result, fullKey)
    ? result[fullKey]
    : defaultValue;
}

/**
 * Guarda un valor por clave.
 * @param {string} key
 * @param {*} value - debe ser serializable por chrome.storage (JSON-like).
 * @returns {Promise<void>}
 */
export async function setItem(key, value) {
  await chrome.storage.local.set({ [nsKey(key)]: value });
}

/**
 * Elimina una clave.
 * @param {string} key
 * @returns {Promise<void>}
 */
export async function removeItem(key) {
  await chrome.storage.local.remove(nsKey(key));
}

/**
 * Suscribe un callback a cambios de una clave concreta.
 * @param {string} key
 * @param {(newValue: *, oldValue: *) => void} callback
 * @returns {() => void} función para cancelar la suscripción.
 */
export function onItemChanged(key, callback) {
  const fullKey = nsKey(key);
  const listener = (changes, areaName) => {
    if (areaName !== 'local') return;
    if (Object.prototype.hasOwnProperty.call(changes, fullKey)) {
      const { newValue, oldValue } = changes[fullKey];
      callback(newValue, oldValue);
    }
  };
  chrome.storage.onChanged.addListener(listener);
  return () => chrome.storage.onChanged.removeListener(listener);
}

/** Claves conocidas usadas por el resto de la app (evita strings mágicos). */
export const StorageKeys = Object.freeze({
  CONTACTS: 'contacts',
  MESSAGE_TEMPLATE: 'messageTemplate',
  CAMPAIGN_CONFIG: 'campaignConfig',
  CAMPAIGN_STATE: 'campaignState',
  SEND_LOG: 'sendLog',
  ACTIVE_WHATSAPP_TAB: 'activeWhatsAppTabId',
  // "Trabajo pendiente" que el content script recoge tras la navegación a la
  // URL click-to-chat. IMPORTANTE: la clave completa resultante
  // ("wamasterAsthi:pendingSendJob") está duplicada como constante literal
  // en src/content/content.js, porque los content scripts clásicos no
  // pueden hacer `import` de este archivo. Si cambias este valor, actualiza
  // también esa constante.
  PENDING_SEND_JOB: 'pendingSendJob',

  // --- Nuevo en v1.2.0 ---
  GREETINGS_LIST: 'greetingsList',
  GREETINGS_ENABLED: 'greetingsEnabled',
  CAMPAIGN_HISTORY: 'campaignHistory',
  LICENSE: 'license',
  LICENSE_API_BASE: 'licenseApiBase',
  LICENSE_DEV_BYPASS: 'licenseDevBypass',
  INSTALLATION_ID: 'installationId',
  // País/código telefónico predeterminado, capturado en la pantalla de
  // activación de licencia y usado por contactManager.js para anteponer
  // el código internacional a números locales importados desde Excel.
  DEFAULT_COUNTRY: 'defaultCountry',
});
