import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { installDomParserPolyfill } from './helpers/domParserPolyfill.js';
import { buildZip } from './helpers/zipBuilder.js';

before(() => {
  installDomParserPolyfill();
});

function toFakeFile(arrayBuffer) {
  return { arrayBuffer: async () => arrayBuffer };
}

test('importXlsxFile - lee encabezados y filas usando sharedStrings', async () => {
  const { importXlsxFile } = await import('../src/modules/xlsxImporter.js');

  const sheetXml = `<?xml version="1.0"?><worksheet><sheetData>
    <row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row>
    <row r="2"><c r="A2" t="s"><v>2</v></c><c r="B2"><v>5512345678</v></c></row>
  </sheetData></worksheet>`;
  const sharedStringsXml = `<?xml version="1.0"?><sst><si><t>Nombre</t></si><si><t>Teléfono</t></si><si><t>Ana</t></si></sst>`;

  const zipBuffer = buildZip([
    { name: 'xl/worksheets/sheet1.xml', content: sheetXml },
    { name: 'xl/sharedStrings.xml', content: sharedStringsXml },
  ]);

  const { headers, rows } = await importXlsxFile(toFakeFile(zipBuffer));
  assert.deepEqual(headers, ['Nombre', 'Teléfono']);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].Nombre, 'Ana');
  assert.equal(rows[0].Teléfono, '5512345678');
});

test('importXlsxFile - respeta la posición real de columnas (sparse, ej. columna AA)', async () => {
  const { importXlsxFile } = await import('../src/modules/xlsxImporter.js');

  const sheetXml = `<?xml version="1.0"?><worksheet><sheetData>
    <row r="1"><c r="A1" t="s"><v>0</v></c><c r="AA1" t="s"><v>1</v></c></row>
    <row r="2"><c r="A2" t="inlineStr"><is><t>Valor A</t></is></c><c r="AA2" t="inlineStr"><is><t>Valor AA</t></is></c></row>
  </sheetData></worksheet>`;
  const sharedStringsXml = `<?xml version="1.0"?><sst><si><t>Nombre</t></si><si><t>Extra</t></si></sst>`;

  const zipBuffer = buildZip([
    { name: 'xl/worksheets/sheet1.xml', content: sheetXml },
    { name: 'xl/sharedStrings.xml', content: sharedStringsXml },
  ]);

  const { headers, rows } = await importXlsxFile(toFakeFile(zipBuffer));
  assert.equal(headers.length, 27);
  assert.equal(headers[0], 'Nombre');
  assert.equal(headers[26], 'Extra');
  assert.equal(rows[0].Nombre, 'Valor A');
  assert.equal(rows[0].Extra, 'Valor AA');
});

test('importXlsxFile - libro sin sharedStrings.xml (solo inlineStr) funciona', async () => {
  const { importXlsxFile } = await import('../src/modules/xlsxImporter.js');

  const sheetXml = `<?xml version="1.0"?><worksheet><sheetData>
    <row r="1"><c r="A1" t="inlineStr"><is><t>Col</t></is></c></row>
    <row r="2"><c r="A2" t="inlineStr"><is><t>Dato</t></is></c></row>
  </sheetData></worksheet>`;

  const zipBuffer = buildZip([{ name: 'xl/worksheets/sheet1.xml', content: sheetXml }]);
  const { headers, rows } = await importXlsxFile(toFakeFile(zipBuffer));
  assert.deepEqual(headers, ['Col']);
  assert.equal(rows[0].Col, 'Dato');
});

test('importXlsxFile - sin hoja de cálculo lanza error', async () => {
  const { importXlsxFile } = await import('../src/modules/xlsxImporter.js');
  const zipBuffer = buildZip([{ name: 'otra/cosa.xml', content: '<a/>' }]);
  await assert.rejects(() => importXlsxFile(toFakeFile(zipBuffer)), /No se encontró ninguna hoja/);
});
