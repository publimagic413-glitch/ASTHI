/**
 * background.js (service worker)
 * ---------------------------------------------------------------------------
 * Responsabilidades:
 *  1. Abrir el side panel al hacer clic en el ícono de la extensión.
 *  2. Localizar (o abrir) la pestaña de WhatsApp Web cuando el side panel la
 *     solicita, y avisar al panel si esa pestaña cambia de URL o se cierra.
 * ---------------------------------------------------------------------------
 */

import { MessageType, findWhatsAppTab } from '../utils/messaging.js';

const WHATSAPP_URL = 'https://web.whatsapp.com/';

chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((err) => console.error('[WaMaster Asthi] No se pudo configurar el side panel:', err));

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === MessageType.GET_WHATSAPP_TAB) {
    handleGetWhatsAppTab().then(sendResponse);
    return true; // respuesta asíncrona
  }
  return false;
});

async function handleGetWhatsAppTab() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  const existing = findWhatsAppTab(tabs);
  if (existing) {
    return { tabId: existing.id, created: false };
  }
  const created = await chrome.tabs.create({ url: WHATSAPP_URL, active: false });
  return { tabId: created.id, created: true };
}

// Notifica al side panel si la pestaña de WhatsApp Web cambia de URL
// (ej. el usuario navega manualmente) para que la UI pueda reflejarlo.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!changeInfo.url) return;
  broadcastTabUpdate(tabId, changeInfo.url);
});

// Nota (ver AUDITORIA.md, hallazgo A11): este listener reacciona al cierre
// de CUALQUIER pestaña, no solo la de WhatsApp Web activa; el side panel
// filtra por tabId al recibir el mensaje, así que es inofensivo pero genera
// mensajes de más. Documentado como candidato a optimización, no como bug.
chrome.tabs.onRemoved.addListener((tabId) => {
  broadcastTabUpdate(tabId, null);
});

function broadcastTabUpdate(tabId, url) {
  chrome.runtime.sendMessage({ type: MessageType.WHATSAPP_TAB_UPDATED, tabId, url }).catch(() => {
    // No hay side panel escuchando; es normal si el panel está cerrado.
  });
}
