/**
 * sidebar.js
 * ---------------------------------------------------------------------------
 * Controlador de la UI del side panel de WaMaster Asthi. Conecta el DOM con
 * los módulos de negocio (contactManager, messageTemplate, campaignEngine,
 * greetings, campaignHistory, licensing, countryCodes, exportUtils) y con
 * los utilitarios (storage, logger).
 *
 * No contiene lógica de negocio propia más allá de leer/escribir el DOM:
 * toda regla (normalización de teléfono, validación, plantillas, envío,
 * licencias) vive en src/modules/*, para que esta capa se pueda reescribir
 * o adaptar a otro framework de UI en el futuro sin tocar esa lógica.
 *
 * v1.3.0:
 *   - La UI ahora tiene dos pestañas: "Campaña" y "Licencia" (antes todo
 *     vivía en una sola columna con scroll). Ver wireTabs().
 *   - "Adjunto" (uno) pasó a "Adjuntos" (varios): attachmentInput ahora
 *     tiene `multiple`, y el estado en memoria es un array `attachments`.
 *   - Nuevos botones "Reenviar campaña completa" y "Reintentar fallidos",
 *     que llaman a engine.restartCampaign()/engine.retryFailed().
 *
 * v1.4.0: la pestaña Licencia inicia sesión con correo + contraseña (contra
 * el backend REST propio) en vez de pegar una clave de licencia.
 *
 * v1.5.0:
 *   - Adjuntos limitados a un máximo de MAX_ATTACHMENTS (4): onAttachmentsSelected
 *     ahora recorta la selección y avisa con un mensaje de error visible si el
 *     usuario intenta pasarse del límite, en vez de aceptar cualquier cantidad.
 *   - Nuevo campo "Subtítulo del adjunto": texto opcional, independiente del
 *     mensaje principal, que se usa como pie de foto/documento cuando hay
 *     adjuntos. Si se deja vacío, se sigue usando el mensaje principal como
 *     pie de foto (comportamiento idéntico al de versiones anteriores).
 * ---------------------------------------------------------------------------
 */

import { getItem, setItem, StorageKeys } from '../utils/storage.js';
import { importXlsxFile } from '../modules/xlsxImporter.js';
import {
  buildContactsFromRows,
  filterContacts,
  isValidPhone,
} from '../modules/contactManager.js';
import { extractVariables, renderTemplate } from '../modules/messageTemplate.js';
import { CampaignEngine, CampaignStatus, CampaignMode, MAX_ATTACHMENTS } from '../modules/campaignEngine.js';
import { subscribe as subscribeLog, getLog, computeStats } from '../utils/logger.js';
import {
  getGreetings,
  setGreetings,
  isGreetingsEnabled,
  setGreetingsEnabled,
} from '../modules/greetings.js';
import { getHistory } from '../modules/campaignHistory.js';
import { downloadCsv, downloadJson } from '../modules/exportUtils.js';
import { COUNTRY_CODES, getDialCode, getCountry } from '../modules/countryCodes.js';
import {
  getLicense,
  activateLicense,
  deactivateLicense,
  isLicenseUsable,
  scheduleRevalidation,
  setApiBase,
  getApiBase,
  LicenseStatus,
} from '../modules/licensing.js';
import { MessageType } from '../utils/messaging.js';

const EMOJI_LIST = [
  '😀', '😁', '😂', '🤣', '😊', '😉', '😍', '😘', '😎', '🤩',
  '🥳', '😇', '🙂', '🙌', '👍', '👏', '🙏', '💪', '✅', '❌',
  '⭐', '🔥', '💯', '🎉', '🎁', '📦', '📅', '⏰', '📍', '📞',
  '💬', '📩', '✉️', '💰', '💳', '🛒', '🚀', '❤️', '💛', '💙',
  '😢', '😅', '🤔', '👋', '🤝', '🏆', '📈', '🔔', '📌', '🧾',
];

// ---------------------------------------------------------------------------
// Estado en memoria
// ---------------------------------------------------------------------------
let contacts = [];
/** @type {Array<{ dataUrl: string, fileName: string, mimeType: string }>} */
let attachments = [];
let defaultCountryIso2 = null;
let engine = null;
let latestLog = [];

// ---------------------------------------------------------------------------
// Referencias al DOM
// ---------------------------------------------------------------------------
const el = (id) => document.getElementById(id);

const tabBar = el('tabBar');
const tabPanelCampaign = el('tabPanelCampaign');
const tabPanelLicense = el('tabPanelLicense');

const licenseChip = el('licenseChip');
const licenseStatusView = el('licenseStatusView');
const licenseActivationForm = el('licenseActivationForm');
const licenseEmailInput = el('licenseEmailInput');
const licensePasswordInput = el('licensePasswordInput');
const countrySelect = el('countrySelect');
const devBypassCheckbox = el('devBypassCheckbox');
const apiBaseInput = el('apiBaseInput');
const licenseError = el('licenseError');
const licenseEmailLabel = el('licenseEmailLabel');
const licensePlanLabel = el('licensePlanLabel');
const licenseStatusLabel = el('licenseStatusLabel');
const licenseExpiresLabel = el('licenseExpiresLabel');
const licenseCountryLabel = el('licenseCountryLabel');
const btnChangeCountry = el('btnChangeCountry');
const btnDeactivateLicense = el('btnDeactivateLicense');

const excelInput = el('excelInput');
const contactSearch = el('contactSearch');
const activeCountryLabel = el('activeCountryLabel');
const contactsTableBody = el('contactsTableBody');
const btnDownloadInvalid = el('btnDownloadInvalid');

const variableButtons = el('variableButtons');
const templateInput = el('templateInput');
const previewText = el('previewText');
const btnEmojiToggle = el('btnEmojiToggle');
const emojiPicker = el('emojiPicker');

const greetingsEnabledCheckbox = el('greetingsEnabledCheckbox');
const greetingsInput = el('greetingsInput');
const btnSaveGreetings = el('btnSaveGreetings');

const attachmentInput = el('attachmentInput');
const attachmentsList = el('attachmentsList');
const attachmentEmptyLabel = el('attachmentEmptyLabel');
const attachmentCountLabel = el('attachmentCountLabel');
const attachmentError = el('attachmentError');
const attachmentCaptionInput = el('attachmentCaptionInput');
const btnClearAttachments = el('btnClearAttachments');

const minDelayInput = el('minDelayInput');
const maxDelayInput = el('maxDelayInput');

const btnStart = el('btnStart');
const btnPause = el('btnPause');
const btnResume = el('btnResume');
const btnStop = el('btnStop');
const btnResendAll = el('btnResendAll');
const btnRetryFailed = el('btnRetryFailed');
const retryFailedCount = el('retryFailedCount');
const btnNewCampaign = el('btnNewCampaign');
const progressFill = el('progressFill');
const progressLabel = el('progressLabel');
const campaignError = el('campaignError');
const campaignStatusLabel = el('campaignStatusLabel');

const logTableBody = el('logTableBody');
const historyList = el('historyList');

// ---------------------------------------------------------------------------
// Utilidades de escape / inserción de texto
// ---------------------------------------------------------------------------
function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function insertAtCursor(textarea, text) {
  const start = textarea.selectionStart ?? textarea.value.length;
  const end = textarea.selectionEnd ?? textarea.value.length;
  const value = textarea.value;
  textarea.value = value.slice(0, start) + text + value.slice(end);
  const pos = start + text.length;
  textarea.focus();
  textarea.setSelectionRange(pos, pos);
  onTemplateChanged();
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('No se pudo leer el archivo.'));
    reader.readAsDataURL(file);
  });
}

// ---------------------------------------------------------------------------
// Pestañas
// ---------------------------------------------------------------------------
function wireTabs() {
  const panels = { campaign: tabPanelCampaign, license: tabPanelLicense };
  tabBar.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      tabBar.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('is-active', b === btn));
      Object.entries(panels).forEach(([key, panel]) => panel.classList.toggle('is-active', key === btn.dataset.tab));
    });
  });
}

/** Cambia a la pestaña de Licencia (ej. cuando start() rechaza por licencia inactiva). */
function goToLicenseTab() {
  tabBar.querySelector('[data-tab="license"]')?.click();
}

// ---------------------------------------------------------------------------
// Inicialización
// ---------------------------------------------------------------------------
init();

async function init() {
  populateCountrySelect();
  wireTabs();

  defaultCountryIso2 = await getItem(StorageKeys.DEFAULT_COUNTRY, null);

  engine = await CampaignEngine.loadPersistedState();
  contacts = engine.contacts || [];
  templateInput.value = engine.template || '';
  attachments = engine.attachments || [];
  attachmentCaptionInput.value = engine.attachmentCaption || '';
  minDelayInput.value = Math.round((engine.delayRange?.min ?? 4000) / 1000);
  maxDelayInput.value = Math.round((engine.delayRange?.max ?? 9000) / 1000);

  renderAttachmentsList();
  renderActiveCountry();
  renderContactsTable();
  renderVariableButtons();
  renderPreview();

  const greetingsEnabled = await isGreetingsEnabled();
  greetingsEnabledCheckbox.checked = greetingsEnabled;
  greetingsInput.value = (await getGreetings()).join('\n');

  await refreshLicenseView();
  scheduleRevalidation();

  latestLog = await getLog();
  renderLog(latestLog);
  renderCounters(latestLog);
  renderCampaignState(engine.getSnapshot());

  const history = await getHistory();
  renderHistory(history);

  buildEmojiPicker();
  wireEvents();

  engine.onChange((snapshot) => {
    renderCampaignState(snapshot);
    renderContactsTable();
  });
  subscribeLog((log) => {
    latestLog = log;
    renderLog(log);
    renderCounters(log);
    renderCampaignState(engine.getSnapshot());
    getHistory().then(renderHistory);
  });
}

// ---------------------------------------------------------------------------
// Licencia
// ---------------------------------------------------------------------------
function populateCountrySelect() {
  countrySelect.innerHTML = '<option value="">Selecciona un país...</option>' +
    COUNTRY_CODES.map((c) => `<option value="${c.iso2}">${escapeHtml(c.name)} (+${c.dialCode})</option>`).join('');
}

async function refreshLicenseView() {
  const license = await getLicense();
  updateLicenseChip(license);

  if (license && isLicenseUsable(license)) {
    licenseStatusView.classList.remove('hidden');
    licenseActivationForm.classList.add('hidden');
    licenseEmailLabel.textContent = license.email || '—';
    licensePlanLabel.textContent = license.planLabel || license.planId;
    licenseStatusLabel.textContent = statusLabelText(license.status);
    licenseExpiresLabel.textContent = license.expiresAt
      ? new Date(license.expiresAt).toLocaleDateString('es-MX')
      : 'Sin vencimiento';
    const country = getCountry(defaultCountryIso2);
    licenseCountryLabel.textContent = country ? `${country.name} (+${country.dialCode})` : 'No configurado';
  } else {
    licenseStatusView.classList.add('hidden');
    licenseActivationForm.classList.remove('hidden');
    if (defaultCountryIso2) countrySelect.value = defaultCountryIso2;
    apiBaseInput.value = await getApiBase();
  }
}

function statusLabelText(status) {
  return {
    [LicenseStatus.ACTIVE]: 'Activa',
    [LicenseStatus.GRACE]: 'Activa (período de gracia, sin conexión reciente al servidor)',
    [LicenseStatus.EXPIRED]: 'Vencida',
    [LicenseStatus.INVALID]: 'Inválida',
    [LicenseStatus.INACTIVE]: 'Inactiva',
  }[status] || status;
}

function updateLicenseChip(license) {
  const usable = license && isLicenseUsable(license);
  licenseChip.textContent = usable ? `Licencia: ${statusLabelText(license.status)}` : 'Licencia: inactiva';
  licenseChip.className = 'license-chip ' + (
    !license ? 'license-chip--inactive' :
    license.status === LicenseStatus.ACTIVE ? 'license-chip--active' :
    license.status === LicenseStatus.GRACE ? 'license-chip--grace' :
    'license-chip--invalid'
  );
}

async function onActivateLicense(evt) {
  evt.preventDefault();
  licenseError.classList.add('hidden');

  const iso2 = countrySelect.value;
  if (!iso2) {
    licenseError.textContent = 'Selecciona un país / código telefónico.';
    licenseError.classList.remove('hidden');
    return;
  }

  await setItem(StorageKeys.DEFAULT_COUNTRY, iso2);
  defaultCountryIso2 = iso2;
  await setItem(StorageKeys.LICENSE_DEV_BYPASS, devBypassCheckbox.checked);
  if (apiBaseInput.value.trim()) {
    await setApiBase(apiBaseInput.value.trim());
  }

  try {
    await activateLicense(licenseEmailInput.value, licensePasswordInput.value);
    licensePasswordInput.value = '';
    await refreshLicenseView();
    renderActiveCountry();
  } catch (err) {
    licenseError.textContent = err.message;
    licenseError.classList.remove('hidden');
  }
}

async function onDeactivateLicense() {
  await deactivateLicense();
  await refreshLicenseView();
}

// ---------------------------------------------------------------------------
// Contactos
// ---------------------------------------------------------------------------
function renderActiveCountry() {
  const country = getCountry(defaultCountryIso2);
  const label = country ? `${country.name} (+${country.dialCode})` : 'No configurado (activa tu licencia primero)';
  activeCountryLabel.textContent = label;
}

async function onImportExcel(evt) {
  const file = evt.target.files[0];
  if (!file) return;

  try {
    const { headers, rows } = await importXlsxFile(file);
    const dialCode = getDialCode(defaultCountryIso2);
    contacts = buildContactsFromRows(rows, dialCode);
    engine.configure({ contacts });
    renderContactsTable();
    renderVariableButtons(headers);
    renderPreview();
  } catch (err) {
    alert(`No se pudo importar el archivo: ${err.message}`);
  } finally {
    excelInput.value = '';
  }
}

function renderContactsTable() {
  const query = contactSearch.value;
  const filtered = filterContacts(contacts, query);

  contactsTableBody.innerHTML = filtered.map((c) => {
    const realIndex = contacts.indexOf(c);
    return `
      <tr>
        <td>${escapeHtml(c.telefonoOriginal || c.telefono)}</td>
        <td>${escapeHtml(c.telefono)}</td>
        <td>${escapeHtml(c.nombre)}</td>
        <td><span class="badge badge--${c.estado}">${estadoLabel(c.estado)}</span></td>
        <td><button type="button" class="row-delete-btn" data-index="${realIndex}" title="Eliminar contacto">✕</button></td>
      </tr>`;
  }).join('') || '<tr><td colspan="5" class="muted">Sin contactos importados.</td></tr>';

  contactsTableBody.querySelectorAll('.row-delete-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.index);
      contacts.splice(idx, 1);
      engine.configure({ contacts });
      renderContactsTable();
      renderPreview();
    });
  });

  renderCounters(latestLog);
}

function estadoLabel(estado) {
  return { pendiente: 'Pendiente', enviado: 'Enviado', fallido: 'Fallido', invalido: 'Inválido' }[estado] || estado;
}

function renderCounters(log) {
  const total = contacts.length;
  const valid = contacts.filter((c) => c.telefonoValido !== false).length;
  const invalid = total - valid;
  const stats = computeStats(log || []);

  el('countTotal').textContent = total;
  el('countValid').textContent = valid;
  el('countInvalid').textContent = invalid;
  el('countSent').textContent = stats.sent;
  el('countFailed').textContent = stats.failed;
}

function onDownloadInvalid() {
  const invalid = contacts.filter((c) => c.telefonoValido === false);
  if (invalid.length === 0) {
    alert('No hay contactos con número inválido.');
    return;
  }
  downloadCsv('wamaster_contactos_invalidos.csv', invalid.map((c) => ({
    Nombre: c.nombre,
    'Teléfono original': c.telefonoOriginal,
    'Teléfono final': c.telefono,
  })));
}

// ---------------------------------------------------------------------------
// Mensaje / variables / emojis
// ---------------------------------------------------------------------------
function renderVariableButtons(headers) {
  const cols = headers || (contacts[0] ? ['nombre', 'telefono', ...Object.keys(contacts[0].extra || {})] : []);
  const unique = [...new Set(cols)];
  variableButtons.innerHTML = unique
    .map((h) => `<button type="button" class="variable-btn" data-token="${escapeHtml(h)}">{${escapeHtml(h)}}</button>`)
    .join('') + '<button type="button" class="variable-btn" data-token="saludo">{saludo}</button>';

  variableButtons.querySelectorAll('.variable-btn').forEach((btn) => {
    btn.addEventListener('click', () => insertAtCursor(templateInput, `{${btn.dataset.token}}`));
  });
}

function buildEmojiPicker() {
  emojiPicker.innerHTML = EMOJI_LIST.map((e) => `<button type="button">${e}</button>`).join('');
  emojiPicker.querySelectorAll('button').forEach((btn, i) => {
    btn.addEventListener('click', () => {
      insertAtCursor(templateInput, EMOJI_LIST[i]);
      emojiPicker.classList.add('hidden');
    });
  });
}

function onTemplateChanged() {
  engine.configure({ template: templateInput.value });
  renderPreview();
}

function renderPreview() {
  if (!contacts.length) {
    previewText.textContent = '—';
    return;
  }
  const { text, missing } = renderTemplate(templateInput.value, contacts[0]);
  previewText.textContent = text || '—';
  if (missing.length) {
    previewText.textContent += `\n\n(Variables sin resolver en este contacto: ${missing.join(', ')})`;
  }
}

// ---------------------------------------------------------------------------
// Saludos
// ---------------------------------------------------------------------------
async function onSaveGreetings() {
  const lines = greetingsInput.value.split('\n');
  const saved = await setGreetings(lines);
  greetingsInput.value = saved.join('\n');
  await setGreetingsEnabled(greetingsEnabledCheckbox.checked);
}

// ---------------------------------------------------------------------------
// Adjuntos (v1.3.0: varios archivos por campaña; v1.5.0: tope de
// MAX_ATTACHMENTS y subtítulo independiente del mensaje principal)
// ---------------------------------------------------------------------------
async function onAttachmentsSelected(evt) {
  const files = [...(evt.target.files || [])];
  if (files.length === 0) return;

  attachmentError.classList.add('hidden');

  // Se ACUMULAN sobre los ya elegidos (no se reemplazan), para poder abrir
  // el selector varias veces e ir agregando archivos — pero nunca más allá
  // de MAX_ATTACHMENTS en total. Si el usuario selecciona de más, se toman
  // solo los que quepan y se avisa cuántos se descartaron.
  const availableSlots = MAX_ATTACHMENTS - attachments.length;
  const accepted = files.slice(0, Math.max(0, availableSlots));
  const rejectedCount = files.length - accepted.length;

  if (accepted.length === 0) {
    attachmentError.textContent = `Ya tienes el máximo de ${MAX_ATTACHMENTS} archivos adjuntos. Quita alguno antes de agregar otro.`;
    attachmentError.classList.remove('hidden');
    attachmentInput.value = '';
    return;
  }

  try {
    const newAttachments = await Promise.all(
      accepted.map(async (file) => ({
        dataUrl: await readFileAsDataUrl(file),
        fileName: file.name,
        mimeType: file.type,
      }))
    );
    attachments = [...attachments, ...newAttachments];
    engine.configure({ attachments });
    renderAttachmentsList();

    if (rejectedCount > 0) {
      attachmentError.textContent = `Solo se agregaron ${accepted.length} archivo(s): el máximo por campaña es ${MAX_ATTACHMENTS}. Se descartaron ${rejectedCount} archivo(s) de más.`;
      attachmentError.classList.remove('hidden');
    }
  } catch (err) {
    alert(`No se pudo leer alguno de los archivos: ${err.message}`);
  } finally {
    attachmentInput.value = '';
  }
}

function onRemoveAttachment(index) {
  attachments.splice(index, 1);
  engine.configure({ attachments });
  attachmentError.classList.add('hidden');
  renderAttachmentsList();
}

function onClearAttachments() {
  attachments = [];
  engine.configure({ attachments });
  attachmentInput.value = '';
  attachmentError.classList.add('hidden');
  renderAttachmentsList();
}

function onAttachmentCaptionChanged() {
  engine.configure({ attachmentCaption: attachmentCaptionInput.value });
}

function renderAttachmentsList() {
  attachmentCountLabel.textContent = `${attachments.length} / ${MAX_ATTACHMENTS} archivos seleccionados.`;
  // Deshabilita el selector una vez alcanzado el tope, en vez de dejar que
  // el usuario elija más y descubrir el recorte después.
  attachmentInput.disabled = attachments.length >= MAX_ATTACHMENTS;

  if (attachments.length === 0) {
    attachmentsList.innerHTML = '';
    attachmentEmptyLabel.classList.remove('hidden');
    btnClearAttachments.classList.add('hidden');
    return;
  }

  attachmentEmptyLabel.classList.add('hidden');
  btnClearAttachments.classList.remove('hidden');
  attachmentsList.innerHTML = attachments.map((a, i) => `
    <li>
      <span class="attachment-name" title="${escapeHtml(a.fileName)}">${escapeHtml(a.fileName)}</span>
      <button type="button" class="attachment-remove-btn" data-index="${i}" title="Quitar">✕</button>
    </li>`).join('');

  attachmentsList.querySelectorAll('.attachment-remove-btn').forEach((btn) => {
    btn.addEventListener('click', () => onRemoveAttachment(Number(btn.dataset.index)));
  });
}

// ---------------------------------------------------------------------------
// Campaña
// ---------------------------------------------------------------------------
function currentDelayRange() {
  const min = Math.max(1, Number(minDelayInput.value) || 4) * 1000;
  const max = Math.max(min, (Number(maxDelayInput.value) || 9) * 1000);
  return { min, max };
}

function applyCurrentConfig() {
  engine.configure({
    contacts,
    template: templateInput.value,
    attachments,
    attachmentCaption: attachmentCaptionInput.value,
    delayRange: currentDelayRange(),
  });
}

async function onStart() {
  applyCurrentConfig();
  await engine.start();
  if (engine.lastError && /licencia/i.test(engine.lastError)) goToLicenseTab();
}

/** Vuelve a enviar la campaña completa a la misma lista de contactos, sin reimportar el Excel. */
async function onResendAll() {
  if (!confirm('Esto reiniciará el progreso y el registro, y volverá a enviar el mensaje a TODOS los contactos actuales. ¿Continuar?')) return;
  applyCurrentConfig();
  await engine.restartCampaign();
  if (engine.lastError && /licencia/i.test(engine.lastError)) goToLicenseTab();
}

/** Reintenta el envío solo a los contactos marcados como "Fallido" en el Registro. */
async function onRetryFailed() {
  applyCurrentConfig();
  await engine.retryFailed();
  if (engine.lastError && /licencia/i.test(engine.lastError)) goToLicenseTab();
}

async function onNewCampaign() {
  if (!confirm('Esto limpiará los contactos, el mensaje, los adjuntos y el progreso actual. ¿Continuar?')) return;
  await engine.reset();
  contacts = [];
  attachments = [];
  templateInput.value = '';
  attachmentCaptionInput.value = '';
  contactSearch.value = '';
  attachmentError.classList.add('hidden');
  renderContactsTable();
  renderVariableButtons();
  renderPreview();
  renderAttachmentsList();
}

function countFailedInLog() {
  return latestLog.filter((e) => e.status === 'failed').length;
}

function renderCampaignState(snapshot) {
  const { status, mode, currentIndex, total, lastError } = snapshot;
  const isRunning = status === CampaignStatus.RUNNING;
  const isFinishedState = status === CampaignStatus.IDLE || status === CampaignStatus.COMPLETED || status === CampaignStatus.STOPPED;

  btnStart.disabled = isRunning;
  btnPause.disabled = !isRunning;
  btnResume.disabled = status !== CampaignStatus.PAUSED;
  btnStop.disabled = isFinishedState;

  const failedCount = countFailedInLog();
  btnResendAll.disabled = isRunning || contacts.length === 0;
  btnRetryFailed.disabled = isRunning || failedCount === 0;
  retryFailedCount.textContent = String(failedCount);

  const pct = total > 0 ? Math.round((currentIndex / total) * 100) : 0;
  progressFill.style.width = `${pct}%`;
  progressLabel.textContent = `${currentIndex} / ${total}`;

  campaignStatusLabel.textContent = `Estado: ${campaignStatusText(status, mode)}`;

  if (lastError) {
    campaignError.textContent = lastError;
    campaignError.classList.remove('hidden');
  } else {
    campaignError.classList.add('hidden');
  }
}

function campaignStatusText(status, mode) {
  const isRetry = mode === CampaignMode.RETRY;
  return {
    [CampaignStatus.IDLE]: 'inactiva',
    [CampaignStatus.RUNNING]: isRetry ? 'reintentando fallidos...' : 'enviando...',
    [CampaignStatus.PAUSED]: 'pausada',
    [CampaignStatus.STOPPED]: 'detenida',
    [CampaignStatus.COMPLETED]: isRetry ? 'reintento completado' : 'completada',
  }[status] || status;
}

// ---------------------------------------------------------------------------
// Registro / historial
// ---------------------------------------------------------------------------
function renderLog(log) {
  logTableBody.innerHTML = log.map((e) => `
    <tr>
      <td>${escapeHtml(e.phone)}</td>
      <td>${escapeHtml(e.nombre)}</td>
      <td><span class="badge badge--${e.status === 'sent' ? 'enviado' : 'fallido'}">${e.status === 'sent' ? 'Enviado' : 'Fallido'}</span></td>
      <td>${escapeHtml(e.errorMessage || '')}</td>
    </tr>`).join('') || '<tr><td colspan="4" class="muted">Sin envíos todavía.</td></tr>';
}

function historyStatusLabel(finalStatus) {
  return {
    completed: 'Completada',
    stopped: 'Detenida',
    'retry-completed': 'Reintento completado',
    'retry-stopped': 'Reintento detenido',
  }[finalStatus] || finalStatus;
}

function renderHistory(history) {
  if (!history.length) {
    historyList.innerHTML = '<p class="muted">Aún no hay campañas completadas.</p>';
    return;
  }
  historyList.innerHTML = history.map((h) => `
    <div class="history-entry" data-id="${h.id}">
      <div class="history-meta">
        <span>${new Date(h.finishedAt).toLocaleString('es-MX')}</span>
        <span>${historyStatusLabel(h.finalStatus)} — ${h.sent} enviados / ${h.failed} fallidos de ${h.totalContacts}</span>
      </div>
      <div class="history-actions">
        <button type="button" class="btn btn-secondary" data-action="sent">Descargar enviados</button>
        <button type="button" class="btn btn-secondary" data-action="failed">Descargar fallidos</button>
        <button type="button" class="btn btn-secondary" data-action="full">Reporte completo</button>
      </div>
    </div>`).join('');

  historyList.querySelectorAll('.history-entry').forEach((entryEl) => {
    const id = entryEl.dataset.id;
    const entry = history.find((h) => h.id === id);
    entryEl.querySelectorAll('button').forEach((btn) => {
      btn.addEventListener('click', () => handleHistoryDownload(entry, btn.dataset.action));
    });
  });
}

function handleHistoryDownload(entry, action) {
  if (action === 'sent') {
    downloadCsv(`wamaster_enviados_${entry.id}.csv`, entry.log.filter((e) => e.status === 'sent'));
  } else if (action === 'failed') {
    downloadCsv(`wamaster_fallidos_${entry.id}.csv`, entry.log.filter((e) => e.status === 'failed'));
  } else {
    downloadJson(`wamaster_reporte_${entry.id}.json`, entry);
  }
}

// ---------------------------------------------------------------------------
// Cableado de eventos
// ---------------------------------------------------------------------------
function wireEvents() {
  licenseActivationForm.addEventListener('submit', onActivateLicense);
  btnDeactivateLicense.addEventListener('click', onDeactivateLicense);
  btnChangeCountry.addEventListener('click', () => {
    licenseStatusView.classList.add('hidden');
    licenseActivationForm.classList.remove('hidden');
  });

  excelInput.addEventListener('change', onImportExcel);
  contactSearch.addEventListener('input', renderContactsTable);
  btnDownloadInvalid.addEventListener('click', onDownloadInvalid);

  templateInput.addEventListener('input', onTemplateChanged);
  btnEmojiToggle.addEventListener('click', () => emojiPicker.classList.toggle('hidden'));
  document.addEventListener('click', (evt) => {
    if (!emojiPicker.contains(evt.target) && evt.target !== btnEmojiToggle) {
      emojiPicker.classList.add('hidden');
    }
  });

  greetingsEnabledCheckbox.addEventListener('change', onSaveGreetings);
  btnSaveGreetings.addEventListener('click', onSaveGreetings);

  attachmentInput.addEventListener('change', onAttachmentsSelected);
  btnClearAttachments.addEventListener('click', onClearAttachments);
  attachmentCaptionInput.addEventListener('input', onAttachmentCaptionChanged);

  minDelayInput.addEventListener('change', () => engine.configure({ delayRange: currentDelayRange() }));
  maxDelayInput.addEventListener('change', () => engine.configure({ delayRange: currentDelayRange() }));

  btnStart.addEventListener('click', onStart);
  btnPause.addEventListener('click', () => engine.pause());
  btnResume.addEventListener('click', () => engine.resume());
  btnStop.addEventListener('click', () => engine.stop());
  btnResendAll.addEventListener('click', onResendAll);
  btnRetryFailed.addEventListener('click', onRetryFailed);
  btnNewCampaign.addEventListener('click', onNewCampaign);

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === MessageType.WHATSAPP_TAB_UPDATED) {
      // Reservado para reflejar en la UI si la pestaña de WhatsApp se cerró; sin cambios en esta versión.
    }
  });
}
