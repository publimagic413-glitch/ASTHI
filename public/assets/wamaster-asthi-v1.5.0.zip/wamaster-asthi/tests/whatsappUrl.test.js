import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildChatUrl, parsePhoneFromUrl } from '../src/utils/whatsappUrl.js';

test('buildChatUrl - sin texto', () => {
  assert.equal(buildChatUrl('5215512345678'), 'https://web.whatsapp.com/send?phone=5215512345678');
});

test('buildChatUrl - con texto (codifica caracteres especiales)', () => {
  const url = buildChatUrl('5215512345678', 'Hola & bienvenido!');
  assert.match(url, /^https:\/\/web\.whatsapp\.com\/send\?phone=5215512345678&text=/);
  assert.equal(new URL(url).searchParams.get('text'), 'Hola & bienvenido!');
});

test('parsePhoneFromUrl - extrae el teléfono', () => {
  assert.equal(parsePhoneFromUrl('https://web.whatsapp.com/send?phone=5215512345678&text=hola'), '5215512345678');
});

test('parsePhoneFromUrl - url inválida devuelve null', () => {
  assert.equal(parsePhoneFromUrl('no-es-una-url'), null);
});
