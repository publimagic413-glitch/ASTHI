import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';

let getItem, setItem, removeItem, onItemChanged, StorageKeys;

beforeEach(async () => {
  const mock = createChromeMock();
  globalThis.chrome = mock.chrome;
  const mod = await import(`../src/utils/storage.js?t=${Date.now()}_${Math.random()}`);
  ({ getItem, setItem, removeItem, onItemChanged, StorageKeys } = mod);
});

test('getItem - devuelve el valor por defecto si la clave no existe', async () => {
  assert.equal(await getItem('algo-que-no-existe', 'default'), 'default');
});

test('setItem + getItem - guarda y recupera con namespace', async () => {
  await setItem(StorageKeys.CONTACTS, [{ nombre: 'Ana' }]);
  const value = await getItem(StorageKeys.CONTACTS, []);
  assert.deepEqual(value, [{ nombre: 'Ana' }]);
});

test('removeItem - elimina la clave', async () => {
  await setItem(StorageKeys.MESSAGE_TEMPLATE, 'Hola');
  await removeItem(StorageKeys.MESSAGE_TEMPLATE);
  assert.equal(await getItem(StorageKeys.MESSAGE_TEMPLATE, null), null);
});

test('onItemChanged - notifica cambios de una clave concreta', async () => {
  let received = null;
  const unsubscribe = onItemChanged(StorageKeys.CAMPAIGN_STATE, (newValue) => {
    received = newValue;
  });
  await setItem(StorageKeys.CAMPAIGN_STATE, { status: 'running' });
  assert.deepEqual(received, { status: 'running' });
  unsubscribe();
});

test('StorageKeys - incluye las claves nuevas de v1.2.0', () => {
  assert.equal(StorageKeys.GREETINGS_LIST, 'greetingsList');
  assert.equal(StorageKeys.CAMPAIGN_HISTORY, 'campaignHistory');
  assert.equal(StorageKeys.LICENSE, 'license');
  assert.equal(StorageKeys.DEFAULT_COUNTRY, 'defaultCountry');
});
