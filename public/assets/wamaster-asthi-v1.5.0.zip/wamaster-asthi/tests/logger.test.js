import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';

let subscribe, getLog, resetLog, upsertEntry, computeStats;

beforeEach(async () => {
  const mock = createChromeMock();
  globalThis.chrome = mock.chrome;
  const mod = await import(`../src/utils/logger.js?t=${Date.now()}_${Math.random()}`);
  ({ subscribe, getLog, resetLog, upsertEntry, computeStats } = mod);
});

test('getLog - vacío por defecto', async () => {
  assert.deepEqual(await getLog(), []);
});

test('upsertEntry - inserta una entrada nueva', async () => {
  await upsertEntry({ phone: '1', nombre: 'Ana', status: 'sent', timestamp: 1 });
  const log = await getLog();
  assert.equal(log.length, 1);
  assert.equal(log[0].phone, '1');
});

test('upsertEntry - actualiza una entrada existente por phone en vez de duplicarla', async () => {
  await upsertEntry({ phone: '1', nombre: 'Ana', status: 'failed', timestamp: 1 });
  await upsertEntry({ phone: '1', nombre: 'Ana', status: 'sent', timestamp: 2 });
  const log = await getLog();
  assert.equal(log.length, 1);
  assert.equal(log[0].status, 'sent');
});

test('resetLog - vacía el log y notifica a los suscriptores', async () => {
  await upsertEntry({ phone: '1', nombre: 'Ana', status: 'sent', timestamp: 1 });
  let notified = null;
  subscribe((log) => { notified = log; });
  await resetLog();
  assert.deepEqual(await getLog(), []);
  assert.deepEqual(notified, []);
});

test('computeStats - cuenta enviados y fallidos', () => {
  const log = [
    { status: 'sent' }, { status: 'sent' }, { status: 'failed' },
  ];
  assert.deepEqual(computeStats(log), { sent: 2, failed: 1, total: 3 });
});
