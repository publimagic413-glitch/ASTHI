/**
 * messaging.js
 * ---------------------------------------------------------------------------
 * Contrato de mensajería entre los distintos contextos de la extensión
 * (side panel <-> service worker <-> content script). Centraliza los tipos
 * de mensaje y helpers de envío/espera para evitar strings mágicos
 * dispersos por el código.
 * ---------------------------------------------------------------------------
 */

/** Catálogo de tipos de mensaje soportados por chrome.runtime.sendMessage. */
export const MessageType = Object.freeze({
  /** side panel -> background: pide el tabId de la pestaña de WhatsApp Web activa (la abre si no existe). */
  GET_WHATSAPP_TAB: 'GET_WHATSAPP_TAB',
  /** background -> side panel: notifica que la pestaña de WhatsApp Web cambió (navegación/cierre). */
  WHATSAPP_TAB_UPDATED: 'WHATSAPP_TAB_UPDATED',
  /** side panel -> content script: sonda de disponibilidad (reservado, no usado en v1). */
  PING_CONTENT_SCRIPT: 'PING_CONTENT_SCRIPT',
  /** content script -> side panel (via runtime broadcast): resultado de un envío individual. */
  WHATSAPP_SEND_RESULT: 'WHATSAPP_SEND_RESULT',
});

/**
 * Envía un mensaje al service worker (background) y espera su respuesta.
 * @param {string} type - uno de MessageType
 * @param {Object} [payload]
 * @returns {Promise<*>}
 */
export function sendToBackground(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

/**
 * Envía un mensaje directo a un content script de una pestaña concreta.
 * Reservado para uso futuro (ej. sondas de salud); no usado en el flujo v1,
 * que se apoya en el patrón Outbox (PENDING_SEND_JOB) en su lugar.
 * @param {number} tabId
 * @param {string} type
 * @param {Object} [payload]
 */
export function sendToTab(tabId, type, payload = {}) {
  return chrome.tabs.sendMessage(tabId, { type, ...payload });
}

/**
 * Busca, entre las pestañas abiertas, la primera que sea WhatsApp Web.
 * @param {chrome.tabs.Tab[]} tabs
 * @returns {chrome.tabs.Tab|undefined}
 */
export function findWhatsAppTab(tabs) {
  return tabs.find((tab) => tab.url && tab.url.startsWith('https://web.whatsapp.com'));
}

/** Navega una pestaña existente a una nueva URL. */
export function navigateTab(tabId, url) {
  return chrome.tabs.update(tabId, { url });
}

/**
 * Espera a que llegue un mensaje de chrome.runtime que cumpla `matcher`,
 * con timeout. Se usa para esperar la confirmación WHATSAPP_SEND_RESULT
 * tras dejar un PENDING_SEND_JOB.
 * @param {(message: Object) => boolean} matcher
 * @param {number} timeoutMs
 * @returns {Promise<Object>}
 */
export function waitForRuntimeMessage(matcher, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.runtime.onMessage.removeListener(listener);
      reject(new Error('Tiempo de espera agotado esperando confirmación de envío.'));
    }, timeoutMs);

    function listener(message) {
      if (matcher(message)) {
        clearTimeout(timer);
        chrome.runtime.onMessage.removeListener(listener);
        resolve(message);
      }
    }
    chrome.runtime.onMessage.addListener(listener);
  });
}
