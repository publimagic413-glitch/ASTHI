import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';
import { MessageType, findWhatsAppTab, waitForRuntimeMessage } from '../src/utils/messaging.js';

let mock;

beforeEach(() => {
  mock = createChromeMock();
  globalThis.chrome = mock.chrome;
});

test('findWhatsAppTab - encuentra la pestaña de WhatsApp Web entre varias', () => {
  const tabs = [
    { id: 1, url: 'https://example.com' },
    { id: 2, url: 'https://web.whatsapp.com/' },
  ];
  assert.equal(findWhatsAppTab(tabs).id, 2);
});

test('findWhatsAppTab - undefined si no hay ninguna', () => {
  assert.equal(findWhatsAppTab([{ id: 1, url: 'https://example.com' }]), undefined);
});

test('waitForRuntimeMessage - resuelve cuando llega un mensaje que matchea', async () => {
  const promise = waitForRuntimeMessage(
    (msg) => msg.type === MessageType.WHATSAPP_SEND_RESULT && msg.requestId === 'abc',
    2000
  );
  mock._emitMessage({ type: MessageType.WHATSAPP_SEND_RESULT, requestId: 'otro' });
  mock._emitMessage({ type: MessageType.WHATSAPP_SEND_RESULT, requestId: 'abc', success: true });
  const result = await promise;
  assert.equal(result.success, true);
});

test('waitForRuntimeMessage - rechaza por timeout si nunca llega', async () => {
  await assert.rejects(
    () => waitForRuntimeMessage(() => false, 50),
    /Tiempo de espera agotado/
  );
});
