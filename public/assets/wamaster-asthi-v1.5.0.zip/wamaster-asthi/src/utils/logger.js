/**
 * logger.js
 * ---------------------------------------------------------------------------
 * Registro (log) de resultados de envío de la campaña activa. Vive en
 * memoria + chrome.storage.local (a través de storage.js) y expone un patrón
 * Observer simple (subscribe/notify) para que la UI se actualice en vivo sin
 * hacer polling.
 * ---------------------------------------------------------------------------
 */

import { getItem, setItem, StorageKeys } from './storage.js';

const listeners = new Set();

/**
 * @typedef {Object} LogEntry
 * @property {string} phone
 * @property {string} nombre
 * @property {'sent'|'failed'} status
 * @property {string} [errorMessage]
 * @property {number} timestamp
 */

/** Suscribe un callback que se llama cada vez que el log cambia. */
export function subscribe(callback) {
  listeners.add(callback);
  return () => listeners.delete(callback);
}

function notify(log) {
  for (const cb of listeners) cb(log);
}

/** @returns {Promise<LogEntry[]>} */
export async function getLog() {
  return getItem(StorageKeys.SEND_LOG, []);
}

/** Vacía el log (se usa al iniciar una campaña nueva). */
export async function resetLog() {
  await setItem(StorageKeys.SEND_LOG, []);
  notify([]);
}

/**
 * Inserta o actualiza una entrada del log identificada por `phone`.
 * Nota de rendimiento (ver AUDITORIA.md, hallazgo A5): esta operación es
 * O(n) por llamada (lee todo el array, lo modifica, lo vuelve a guardar
 * completo), lo cual es O(n²) acumulado para una campaña de n contactos.
 * Aceptable para los volúmenes objetivo de la v1 (cientos de contactos);
 * documentado como candidato a optimizar si se escala a miles.
 * @param {LogEntry} entry
 */
export async function upsertEntry(entry) {
  const log = await getLog();
  const idx = log.findIndex((e) => e.phone === entry.phone);
  if (idx === -1) {
    log.push(entry);
  } else {
    log[idx] = entry;
  }
  await setItem(StorageKeys.SEND_LOG, log);
  notify(log);
  return log;
}

/** Calcula estadísticas agregadas del log (enviados, fallidos, total). */
export function computeStats(log) {
  const sent = log.filter((e) => e.status === 'sent').length;
  const failed = log.filter((e) => e.status === 'failed').length;
  return { sent, failed, total: log.length };
}
