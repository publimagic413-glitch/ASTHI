/**
 * countryCodes.js
 * ---------------------------------------------------------------------------
 * Catálogo de países con su código telefónico internacional (dial code).
 * Se usa en la pantalla de activación de licencia para que el usuario elija
 * un país/código predeterminado, el cual contactManager.js usa después para
 * anteponer el código internacional a números locales importados del Excel.
 *
 * Lista priorizada para Hispanoamérica + España + mercados frecuentes, pero
 * cubre el resto del mundo lo suficiente para no bloquear a nadie. Se puede
 * ampliar sin tocar ningún otro módulo (solo se consume por iso2/dialCode).
 * ---------------------------------------------------------------------------
 */

/**
 * @typedef {Object} CountryOption
 * @property {string} iso2
 * @property {string} name
 * @property {string} dialCode - sin "+", solo dígitos (ej. "52")
 */

/** @type {CountryOption[]} */
export const COUNTRY_CODES = [
  { iso2: 'MX', name: 'México', dialCode: '52' },
  { iso2: 'CO', name: 'Colombia', dialCode: '57' },
  { iso2: 'AR', name: 'Argentina', dialCode: '54' },
  { iso2: 'CL', name: 'Chile', dialCode: '56' },
  { iso2: 'PE', name: 'Perú', dialCode: '51' },
  { iso2: 'EC', name: 'Ecuador', dialCode: '593' },
  { iso2: 'VE', name: 'Venezuela', dialCode: '58' },
  { iso2: 'BO', name: 'Bolivia', dialCode: '591' },
  { iso2: 'PY', name: 'Paraguay', dialCode: '595' },
  { iso2: 'UY', name: 'Uruguay', dialCode: '598' },
  { iso2: 'CR', name: 'Costa Rica', dialCode: '506' },
  { iso2: 'PA', name: 'Panamá', dialCode: '507' },
  { iso2: 'GT', name: 'Guatemala', dialCode: '502' },
  { iso2: 'HN', name: 'Honduras', dialCode: '504' },
  { iso2: 'SV', name: 'El Salvador', dialCode: '503' },
  { iso2: 'NI', name: 'Nicaragua', dialCode: '505' },
  { iso2: 'DO', name: 'República Dominicana', dialCode: '1809' },
  { iso2: 'PR', name: 'Puerto Rico', dialCode: '1787' },
  { iso2: 'CU', name: 'Cuba', dialCode: '53' },
  { iso2: 'ES', name: 'España', dialCode: '34' },
  { iso2: 'US', name: 'Estados Unidos', dialCode: '1' },
  { iso2: 'CA', name: 'Canadá', dialCode: '1' },
  { iso2: 'BR', name: 'Brasil', dialCode: '55' },
  { iso2: 'PT', name: 'Portugal', dialCode: '351' },
  { iso2: 'FR', name: 'Francia', dialCode: '33' },
  { iso2: 'DE', name: 'Alemania', dialCode: '49' },
  { iso2: 'IT', name: 'Italia', dialCode: '39' },
  { iso2: 'GB', name: 'Reino Unido', dialCode: '44' },
];

/** Devuelve el dialCode para un iso2, o null si no está en el catálogo. */
export function getDialCode(iso2) {
  const found = COUNTRY_CODES.find((c) => c.iso2 === iso2);
  return found ? found.dialCode : null;
}

/** Devuelve el país completo para un iso2, o null. */
export function getCountry(iso2) {
  return COUNTRY_CODES.find((c) => c.iso2 === iso2) ?? null;
}
