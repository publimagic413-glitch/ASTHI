# Arquitectura técnica — WaMaster Asthi v1.2.0

## 1. Visión general

WaMaster Asthi es una extensión de Chrome (Manifest V3) con tres contextos de ejecución independientes que se comunican por mensajería y `chrome.storage.local`:

```mermaid
graph TB
    subgraph "Side Panel (sidebar.html/js)"
        UI[sidebar.js] --> Modules[src/modules/*]
        Modules --> Utils[src/utils/*]
    end
    subgraph "Service Worker"
        BG[background.js]
    end
    subgraph "WhatsApp Web (contenido inyectado)"
        CS[content.js + whatsappSelectors.js]
    end
    Storage[(chrome.storage.local)]

    UI <-- chrome.runtime.sendMessage --> BG
    BG <-- chrome.tabs.update/create --> CS
    CS -- WHATSAPP_SEND_RESULT --> UI
    UI <--> Storage
    CS <--> Storage
```

## 2. Referencia de carpetas y archivos

| Ruta | Rol |
|---|---|
| `manifest.json` | Declaración MV3: permisos, side panel, content scripts, service worker. |
| `src/background/background.js` | Abre/localiza la pestaña de WhatsApp Web, notifica cambios de pestaña. |
| `src/content/whatsappSelectors.js` | Catálogo de selectores CSS/texto de la UI de WhatsApp Web + helpers de búsqueda (incluye `queryAnyWithin` para acotar búsquedas al modal de adjuntos). |
| `src/content/content.js` | Ejecuta el envío real (texto/adjunto) dentro de WhatsApp Web, siguiendo el patrón Outbox. |
| `src/utils/storage.js` | Wrapper de `chrome.storage.local` + catálogo `StorageKeys`. |
| `src/utils/messaging.js` | Tipos de mensaje y helpers de envío/espera entre contextos. |
| `src/utils/whatsappUrl.js` | Construcción de la URL click-to-chat. |
| `src/utils/logger.js` | Registro de resultados de envío (Observer pattern). |
| `src/modules/contactManager.js` | Normalización/validación de contactos, detección de columnas, país/código de teléfono. |
| `src/modules/countryCodes.js` | Catálogo de países + código telefónico. |
| `src/modules/xlsxImporter.js` + `zipReader.js` | Importador de `.xlsx` sin dependencias (ZIP + XML nativos). |
| `src/modules/messageTemplate.js` | Motor de variables `{nombre}`, `{telefono}`, `{saludo}`, columnas del Excel. |
| `src/modules/greetings.js` | Lista de saludos aleatorios + flag de activación. |
| `src/modules/campaignEngine.js` | Máquina de estados de la campaña; orquesta el envío completo. |
| `src/modules/campaignHistory.js` | Persistencia del historial de campañas completadas/detenidas. |
| `src/modules/exportUtils.js` | Exportación a CSV/JSON descargable. |
| `src/modules/licensing.js` + `deviceId.js` | Activación/validación/desactivación de licencias. |
| `src/sidebar/*` | UI del side panel (HTML/CSS/JS), sin lógica de negocio propia. |

## 3. Flujo completo: de "Iniciar" a mensaje enviado

```mermaid
sequenceDiagram
    participant U as Usuario
    participant SB as sidebar.js
    participant CE as campaignEngine.js
    participant BG as background.js
    participant Tab as Pestaña WhatsApp Web
    participant CS as content.js

    U->>SB: Clic en "Iniciar"
    SB->>CE: start()
    CE->>CE: valida contactos, plantilla, licencia
    CE->>BG: GET_WHATSAPP_TAB
    BG-->>CE: { tabId }
    loop por cada contacto válido
        CE->>CE: arma texto (plantilla + saludo si aplica)
        CE->>Storage: PENDING_SEND_JOB { requestId, phone, text, attachment }
        CE->>Tab: navigateTab(url click-to-chat)
        Tab->>CS: content.js se ejecuta (run_at document_idle)
        CS->>Storage: lee PENDING_SEND_JOB, compara phone con la URL actual
        CS->>Tab: escribe/envía mensaje (texto o adjunto acotado al modal)
        CS-->>CE: WHATSAPP_SEND_RESULT { requestId, success }
        CE->>Storage: upsertEntry() en el log
        CE->>SB: onChange() (progreso actualizado)
        CE->>CE: espera pausa aleatoria (interrumpible)
    end
    CE->>Storage: addHistoryEntry() (COMPLETED o STOPPED con envíos)
```

Este es el **patrón Outbox**: como navegar la pestaña destruye cualquier canal de mensajería directo hacia el content script anterior, el "trabajo pendiente" se persiste en `chrome.storage.local` *antes* de navegar, y el nuevo content script (que se ejecuta tras la navegación) lo recoge al cargar.

## 4. Máquina de estados de la campaña

```mermaid
stateDiagram-v2
    [*] --> idle
    idle --> running: start()
    running --> paused: pause()
    paused --> running: resume()
    running --> completed: todos los contactos procesados
    running --> stopped: stop()
    paused --> stopped: stop()
    completed --> idle: reset()
    stopped --> idle: reset()
    idle --> idle: reset()
```

## 5. Patrones de diseño utilizados

- **Observer/Pub-Sub**: `logger.subscribe()`, `campaignEngine.onChange()`.
- **Outbox**: `PENDING_SEND_JOB` (ver sección 3).
- **Máquina de estados finita**: `CampaignStatus`.
- **Repository/Wrapper**: `storage.js` aísla toda la app de la API cruda de `chrome.storage`.
- **Estrategia de validación externa**: `licensing.js` nunca decide localmente con un secreto propio; delega en el backend configurado.

## 6. Puntos de fallo conocidos

Ver `docs/AUDITORIA.md` para el detalle completo con severidad y solución propuesta. Resumen de los más relevantes:

- Selectores de UI de WhatsApp Web frágiles ante cambios de su interfaz (mitigado con múltiples selectores de respaldo, pero no eliminado).
- Condición de carrera en `pause()`/`resume()` bajo clics muy rápidos (A1, no corregida).
- La heurística de normalización de teléfono con país (ver `docs/CAMBIOS_v1.2.0.md`, sección 2.1) puede fallar en números locales inusualmente largos.

## 7. Recomendaciones futuras

- Corregir A1 (guardia `_loopActive` en `campaignEngine.js`).
- Reemplazar `document.execCommand` (deprecado) por simulación de `InputEvent` nativos en `content.js`.
- Backend de licencias real (ver `docs/LICENSE_BACKEND.md`) para reemplazar el modo de prueba local en producción.
- Selección de hoja de Excel por nombre, no solo la primera (`xlsxImporter.js`).
