import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';
import { CampaignEngine, CampaignStatus, CampaignMode, MAX_ATTACHMENTS } from '../src/modules/campaignEngine.js';
import { MessageType } from '../src/utils/messaging.js';
import { StorageKeys, getItem, setItem } from '../src/utils/storage.js';

let mock;

beforeEach(() => {
  mock = createChromeMock();
  globalThis.chrome = mock.chrome;
});

function waitForStatus(engine, status, timeoutMs = 3000) {
  return new Promise((resolve, reject) => {
    if (engine.status === status) return resolve(engine.getSnapshot());
    const timer = setTimeout(() => {
      unsubscribe();
      reject(new Error(`Tiempo de espera agotado esperando estado "${status}" (actual: "${engine.status}")`));
    }, timeoutMs);
    const unsubscribe = engine.onChange((snapshot) => {
      if (snapshot.status === status) {
        clearTimeout(timer);
        unsubscribe();
        resolve(snapshot);
      }
    });
  });
}

function registerWhatsAppTabHandler(tabId = 1) {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === MessageType.GET_WHATSAPP_TAB) {
      sendResponse({ tabId, created: false });
      return true;
    }
    return false;
  });
}

/**
 * Instala UN SOLO wrapper sobre chrome.tabs.update() por prueba, que simula al
 * content script respondiendo a cada PENDING_SEND_JOB. La lógica de
 * éxito/fallo y el registro de navegaciones se leen de un objeto `rule`
 * mutable, para poder cambiar el comportamiento a mitad de una prueba (ej.
 * "el primer intento falla, el reintento tiene éxito") sin volver a envolver
 * chrome.tabs.update() cada vez — envolverlo más de una vez encadenaba
 * respuestas duplicadas (una del wrapper viejo, otra del nuevo) para el
 * mismo requestId, causando falsos negativos en las pruebas de reintento.
 */
function installSendResponder() {
  const rule = { resultForPhone: () => true };
  const captured = [];
  const originalUpdate = chrome.tabs.update.bind(chrome.tabs);
  chrome.tabs.update = async (tabId, updateInfo) => {
    const job = await getItem(StorageKeys.PENDING_SEND_JOB, null);
    captured.push({ url: updateInfo.url, job });
    const result = await originalUpdate(tabId, updateInfo);
    setTimeout(async () => {
      const currentJob = await getItem(StorageKeys.PENDING_SEND_JOB, null);
      if (currentJob) {
        const success = rule.resultForPhone(currentJob.phone);
        mock._emitMessage({
          type: MessageType.WHATSAPP_SEND_RESULT,
          requestId: currentJob.requestId,
          success,
          errorMessage: success ? undefined : 'Fallo simulado',
        });
      }
    }, 10);
    return result;
  };
  return {
    /** Cambia la regla de éxito/fallo usada por las próximas navegaciones. */
    setRule(fn) {
      rule.resultForPhone = fn;
    },
    captured,
  };
}

test('start() - rechaza si no hay contactos válidos', async () => {
  const engine = new CampaignEngine();
  engine.configure({ contacts: [], template: 'Hola {nombre}' });
  await engine.start();
  assert.equal(engine.status, CampaignStatus.IDLE);
  assert.match(engine.lastError, /No hay contactos válidos/);
});

test('start() - rechaza si falta la plantilla de mensaje', async () => {
  const engine = new CampaignEngine();
  engine.configure({ contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }], template: '' });
  await engine.start();
  assert.match(engine.lastError, /Escribe un mensaje/);
});

test('start() - rechaza si la licencia no está activa', async () => {
  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }],
    template: 'Hola {nombre}',
  });
  await engine.start();
  assert.match(engine.lastError, /licencia no está activa/);
});

test('flujo completo - envía a un contacto y llega a COMPLETED, registrando el historial', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }],
    template: 'Hola {nombre}',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  const snapshot = await waitForStatus(engine, CampaignStatus.COMPLETED);
  assert.equal(snapshot.currentIndex, 1);

  const { getHistory } = await import('../src/modules/campaignHistory.js');
  const history = await getHistory();
  assert.equal(history.length, 1);
  assert.equal(history[0].sent, 1);
  assert.equal(history[0].failed, 0);
});

test('flujo con contacto inválido - se omite del envío y no cuenta contra los válidos', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [
      { telefono: '1', telefonoValido: false, nombre: 'Malo', extra: {} },
      { telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} },
    ],
    template: 'Hola {nombre}',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  const snapshot = await waitForStatus(engine, CampaignStatus.COMPLETED);
  assert.equal(snapshot.currentIndex, 1); // solo el contacto válido cuenta
});

test('pause()/resume() - detiene y reanuda el bucle sin perder el índice', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [
      { telefono: '525512340001', telefonoValido: true, nombre: 'A', extra: {} },
      { telefono: '525512340002', telefonoValido: true, nombre: 'B', extra: {} },
    ],
    template: 'Hola {nombre}',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  // Pausamos casi de inmediato; puede que el primer envío ya haya arrancado.
  engine.pause();
  assert.equal(engine.status, CampaignStatus.PAUSED);
  engine.resume();
  const snapshot = await waitForStatus(engine, CampaignStatus.COMPLETED, 5000);
  assert.equal(snapshot.currentIndex, 2);
});

test('reset() - limpia contactos, plantilla, adjuntos y vuelve a IDLE', async () => {
  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '1', telefonoValido: true, nombre: 'A', extra: {} }],
    template: 'Hola',
    attachments: [{ dataUrl: 'data:image/png;base64,AAAA', fileName: 'a.png', mimeType: 'image/png' }],
  });
  await engine.reset();
  assert.equal(engine.contacts.length, 0);
  assert.equal(engine.template, '');
  assert.equal(engine.attachments.length, 0);
  assert.equal(engine.status, CampaignStatus.IDLE);
  assert.equal(engine.currentIndex, 0);
  assert.equal(engine.mode, CampaignMode.MAIN);
});

// ---------------------------------------------------------------------------
// v1.3.0 — restartCampaign() / retryFailed()
// ---------------------------------------------------------------------------

test('retryFailed() - reenvía solo a los contactos marcados como fallidos y actualiza el registro', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  const responder = installSendResponder();
  responder.setRule((phone) => phone !== '525512340002'); // el contacto B falla la primera vez

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [
      { telefono: '525512340001', telefonoValido: true, nombre: 'A', extra: {} },
      { telefono: '525512340002', telefonoValido: true, nombre: 'B', extra: {} },
    ],
    template: 'Hola {nombre}',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);

  const { getLog } = await import('../src/utils/logger.js');
  let log = await getLog();
  assert.equal(log.find((e) => e.phone === '525512340001').status, 'sent');
  assert.equal(log.find((e) => e.phone === '525512340002').status, 'failed');

  // Ahora el reintento: B ya responde con éxito.
  responder.setRule(() => true);
  await engine.retryFailed();
  assert.equal(engine.mode, CampaignMode.RETRY);
  const snapshot = await waitForStatus(engine, CampaignStatus.COMPLETED, 5000);
  assert.equal(snapshot.total, 1); // solo el fallido entra al reintento
  assert.equal(snapshot.currentIndex, 1);

  log = await getLog();
  assert.equal(log.find((e) => e.phone === '525512340001').status, 'sent'); // A no se tocó de nuevo
  assert.equal(log.find((e) => e.phone === '525512340002').status, 'sent'); // B se actualizó, no se duplicó
  assert.equal(log.length, 2);

  const { getHistory } = await import('../src/modules/campaignHistory.js');
  const history = await getHistory();
  assert.equal(history.length, 2);
  assert.equal(history[0].finalStatus, 'retry-completed');
  assert.equal(history[0].totalContacts, 1);
});

test('retryFailed() - no hace nada si no hay contactos fallidos en el registro', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512340001', telefonoValido: true, nombre: 'A', extra: {} }],
    template: 'Hola {nombre}',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);

  await engine.retryFailed();
  assert.equal(engine.status, CampaignStatus.COMPLETED); // no cambió, no arrancó nada
  assert.match(engine.lastError, /No hay contactos fallidos/);
});

test('restartCampaign() - vuelve a enviar a TODOS los contactos y reinicia el progreso', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [
      { telefono: '525512340001', telefonoValido: true, nombre: 'A', extra: {} },
      { telefono: '525512340002', telefonoValido: true, nombre: 'B', extra: {} },
    ],
    template: 'Hola {nombre}',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);
  assert.equal(engine.currentIndex, 2);

  await engine.restartCampaign();
  assert.equal(engine.mode, CampaignMode.MAIN);
  const snapshot = await waitForStatus(engine, CampaignStatus.COMPLETED, 5000);
  assert.equal(snapshot.currentIndex, 2);
  assert.equal(snapshot.mode, CampaignMode.MAIN);

  const { getHistory } = await import('../src/modules/campaignHistory.js');
  const history = await getHistory();
  assert.equal(history.length, 2);
  assert.equal(history[0].finalStatus, 'completed');
});

test('restartCampaign() - no hace nada si la campaña ya está corriendo', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [
      { telefono: '525512340001', telefonoValido: true, nombre: 'A', extra: {} },
      { telefono: '525512340002', telefonoValido: true, nombre: 'B', extra: {} },
    ],
    template: 'Hola {nombre}',
    delayRange: { min: 200, max: 300 },
  });

  await engine.start();
  assert.equal(engine.status, CampaignStatus.RUNNING);
  await engine.restartCampaign(); // debe ser un no-op mientras corre
  assert.equal(engine.currentIndex < 2 || engine.status === CampaignStatus.RUNNING, true);

  await waitForStatus(engine, CampaignStatus.COMPLETED, 5000);
});

// ---------------------------------------------------------------------------
// v1.3.0 — adjuntos múltiples
// ---------------------------------------------------------------------------

test('_sendToContact() - arma el job con varios adjuntos y navega sin ?text= cuando hay adjuntos', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  const { captured } = installSendResponder();

  const attachments = [
    { dataUrl: 'data:image/png;base64,AAAA', fileName: 'foto1.png', mimeType: 'image/png' },
    { dataUrl: 'data:application/pdf;base64,BBBB', fileName: 'doc.pdf', mimeType: 'application/pdf' },
  ];

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }],
    template: 'Hola {nombre}',
    attachments,
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);

  assert.equal(captured.length, 1);
  assert.ok(!captured[0].url.includes('text='), 'la URL no debe llevar ?text= cuando hay adjuntos (va en el job)');
  assert.equal(captured[0].job.attachments.length, 2);
  assert.equal(captured[0].job.attachments[0].fileName, 'foto1.png');
  assert.equal(captured[0].job.attachments[1].fileName, 'doc.pdf');
  assert.equal(captured[0].job.text, 'Hola Ana');
});

test('_sendToContact() - sin adjuntos, job.attachments queda vacío y la URL sí lleva ?text=', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  const { captured } = installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }],
    template: 'Hola {nombre}',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);

  assert.equal(captured[0].job.attachments.length, 0);
  assert.ok(captured[0].url.includes('text='));
});

// ---------------------------------------------------------------------------
// v1.5.0 — tope de MAX_ATTACHMENTS y subtítulo de adjunto (caption)
// ---------------------------------------------------------------------------

test('configure() - recorta attachments a MAX_ATTACHMENTS aunque se le pasen más', () => {
  const engine = new CampaignEngine();
  const sixFiles = Array.from({ length: 6 }, (_, i) => ({
    dataUrl: 'data:image/png;base64,AAAA', fileName: `foto${i}.png`, mimeType: 'image/png',
  }));
  engine.configure({ attachments: sixFiles });
  assert.equal(engine.attachments.length, MAX_ATTACHMENTS);
  assert.equal(engine.attachments[0].fileName, 'foto0.png');
  assert.equal(engine.attachments[MAX_ATTACHMENTS - 1].fileName, `foto${MAX_ATTACHMENTS - 1}.png`);
});

test('_sendToContact() - sin subtítulo de adjunto, el pie de foto usa el mensaje principal (compatibilidad)', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  const { captured } = installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }],
    template: 'Hola {nombre}, aquí tu foto',
    attachments: [{ dataUrl: 'data:image/png;base64,AAAA', fileName: 'foto1.png', mimeType: 'image/png' }],
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);

  assert.equal(captured[0].job.text, 'Hola Ana, aquí tu foto');
  assert.equal(captured[0].job.caption, 'Hola Ana, aquí tu foto');
});

test('_sendToContact() - con subtítulo de adjunto definido, el pie de foto usa el subtítulo (no el mensaje principal)', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  const { captured } = installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }],
    template: 'Mensaje principal largo para {nombre}',
    attachmentCaption: 'Pie de foto corto para {nombre}',
    attachments: [{ dataUrl: 'data:image/png;base64,AAAA', fileName: 'foto1.png', mimeType: 'image/png' }],
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);

  assert.equal(captured[0].job.text, 'Mensaje principal largo para Ana');
  assert.equal(captured[0].job.caption, 'Pie de foto corto para Ana');
});

test('_sendToContact() - sin adjuntos, job.caption queda undefined (el subtítulo no aplica sin adjunto)', async () => {
  await setItem(StorageKeys.LICENSE, { status: 'active', devBypass: true });
  registerWhatsAppTabHandler();
  const { captured } = installSendResponder();

  const engine = new CampaignEngine();
  engine.configure({
    contacts: [{ telefono: '525512345678', telefonoValido: true, nombre: 'Ana', extra: {} }],
    template: 'Hola {nombre}',
    attachmentCaption: 'Esto no debería usarse',
    delayRange: { min: 10, max: 20 },
  });

  await engine.start();
  await waitForStatus(engine, CampaignStatus.COMPLETED);

  assert.equal(captured[0].job.caption, undefined);
});

test('reset() - también limpia attachmentCaption', async () => {
  const engine = new CampaignEngine();
  engine.configure({ attachmentCaption: 'Un subtítulo cualquiera' });
  await engine.reset();
  assert.equal(engine.attachmentCaption, '');
});

// ---------------------------------------------------------------------------
// v1.3.0 — loadPersistedState() con mode/activeList
// ---------------------------------------------------------------------------

test('loadPersistedState() - reconstruye una campaña en modo retry con su activeList', async () => {
  const activeList = [{ telefono: '525512340002', telefonoValido: true, nombre: 'B', extra: {} }];
  await setItem(StorageKeys.CAMPAIGN_STATE, {
    status: CampaignStatus.RUNNING,
    mode: CampaignMode.RETRY,
    currentIndex: 0,
    contacts: [
      { telefono: '525512340001', telefonoValido: true, nombre: 'A', extra: {} },
      { telefono: '525512340002', telefonoValido: true, nombre: 'B', extra: {} },
    ],
    template: 'Hola {nombre}',
    attachments: [],
    delayRange: { min: 10, max: 20 },
    startedAt: Date.now(),
    activeList,
  });

  const engine = await CampaignEngine.loadPersistedState();
  assert.equal(engine.mode, CampaignMode.RETRY);
  assert.equal(engine._activeList.length, 1);
  assert.equal(engine._activeList[0].telefono, '525512340002');
  // Una campaña "running" al cerrar el panel se restaura pausada, nunca corriendo sola.
  assert.equal(engine.status, CampaignStatus.PAUSED);
});

test('loadPersistedState() - modo retry sin activeList válida cae de vuelta a main/stopped en vez de arriesgarse', async () => {
  await setItem(StorageKeys.CAMPAIGN_STATE, {
    status: CampaignStatus.RUNNING,
    mode: CampaignMode.RETRY,
    currentIndex: 3,
    contacts: [{ telefono: '525512340001', telefonoValido: true, nombre: 'A', extra: {} }],
    template: 'Hola {nombre}',
    attachments: [],
    delayRange: { min: 10, max: 20 },
    startedAt: Date.now(),
    activeList: [],
  });

  const engine = await CampaignEngine.loadPersistedState();
  assert.equal(engine.mode, CampaignMode.MAIN);
  assert.equal(engine.currentIndex, 0);
  assert.equal(engine.status, CampaignStatus.STOPPED);
});

test('loadPersistedState() - compatibilidad hacia atrás: `attachment` singular de v1.2.x se migra a `attachments` array', async () => {
  await setItem(StorageKeys.CAMPAIGN_STATE, {
    status: CampaignStatus.IDLE,
    currentIndex: 0,
    contacts: [],
    template: '',
    attachment: { dataUrl: 'data:image/png;base64,AAAA', fileName: 'legacy.png', mimeType: 'image/png' },
    delayRange: { min: 10, max: 20 },
  });

  const engine = await CampaignEngine.loadPersistedState();
  assert.equal(engine.attachments.length, 1);
  assert.equal(engine.attachments[0].fileName, 'legacy.png');
});

test('loadPersistedState() - restaura attachmentCaption, y recorta a MAX_ATTACHMENTS si el estado persistido (de una versión anterior a v1.5.0) trae más', async () => {
  const sixFiles = Array.from({ length: 6 }, (_, i) => ({
    dataUrl: 'data:image/png;base64,AAAA', fileName: `foto${i}.png`, mimeType: 'image/png',
  }));
  await setItem(StorageKeys.CAMPAIGN_STATE, {
    status: CampaignStatus.IDLE,
    currentIndex: 0,
    contacts: [],
    template: '',
    attachments: sixFiles,
    attachmentCaption: 'Subtítulo persistido',
    delayRange: { min: 10, max: 20 },
  });

  const engine = await CampaignEngine.loadPersistedState();
  assert.equal(engine.attachments.length, MAX_ATTACHMENTS);
  assert.equal(engine.attachmentCaption, 'Subtítulo persistido');
});

test('loadPersistedState() - estado de antes de v1.5.0 sin attachmentCaption cae a cadena vacía', async () => {
  await setItem(StorageKeys.CAMPAIGN_STATE, {
    status: CampaignStatus.IDLE,
    currentIndex: 0,
    contacts: [],
    template: '',
    attachments: [],
    delayRange: { min: 10, max: 20 },
    // sin `attachmentCaption`: así quedaban los estados persistidos antes de v1.5.0
  });

  const engine = await CampaignEngine.loadPersistedState();
  assert.equal(engine.attachmentCaption, '');
});
