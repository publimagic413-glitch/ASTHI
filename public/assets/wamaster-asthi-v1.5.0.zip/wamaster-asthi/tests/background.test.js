import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';
import { MessageType } from '../src/utils/messaging.js';

let mock;

beforeEach(async () => {
  mock = createChromeMock();
  globalThis.chrome = mock.chrome;
  // Reimportar con un query único fuerza a que se re-ejecute el módulo (y
  // por tanto vuelva a registrar sus listeners) contra el chrome mock nuevo.
  await import(`../src/background/background.js?t=${Date.now()}_${Math.random()}`);
});

test('GET_WHATSAPP_TAB - crea una pestaña nueva si no existe ninguna de WhatsApp Web', async () => {
  const response = await chrome.runtime.sendMessage({ type: MessageType.GET_WHATSAPP_TAB });
  assert.equal(response.created, true);
  assert.equal(typeof response.tabId, 'number');
});

test('GET_WHATSAPP_TAB - reutiliza una pestaña de WhatsApp Web existente', async () => {
  await chrome.tabs.create({ url: 'https://web.whatsapp.com/' });
  const response = await chrome.runtime.sendMessage({ type: MessageType.GET_WHATSAPP_TAB });
  assert.equal(response.created, false);
});

test('mensajes de otro tipo no son manejados por background.js', async () => {
  const response = await chrome.runtime.sendMessage({ type: 'ALGO_DESCONOCIDO' });
  assert.equal(response, undefined);
});
