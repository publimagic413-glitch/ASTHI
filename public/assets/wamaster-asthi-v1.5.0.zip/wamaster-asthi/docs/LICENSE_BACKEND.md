# Contrato de API del backend de licencias (referencia)

WaMaster Asthi (frontend) espera un backend HTTPS con estos endpoints. Hay una implementación de referencia completa en `wamaster-web/` (Node.js puro, sin dependencias) — este documento describe el contrato que `src/modules/licensing.js` consume, por si prefieres implementar tu propio backend en otro lenguaje.

Base URL: la que configures en `StorageKeys.LICENSE_API_BASE` (campo "URL base del backend" en Opciones avanzadas de la sección Licencia). Por defecto apunta a `http://localhost:4000` para desarrollo.

## Auth por correo y contraseña (v1.4.0+, flujo principal)

### POST `/v1/auth/login`

**Request**
```json
{ "email": "cliente@ejemplo.com", "password": "claveSegura123", "installationId": "uuid-v4", "deviceName": "Chrome - Windows" }
```

**Response 200 (credenciales correctas)**
```json
{
  "valid": true,
  "token": "a3f9c2...",
  "expiresAt": 1791234567890,
  "license": { "key": "WAM-XXXX-XXXX-XXXX", "status": "active", "planId": "pro", "planLabel": "Pro", "expiresAt": null }
}
```

**Response 401 (credenciales incorrectas)**
```json
{ "valid": false, "message": "Correo o contraseña incorrectos." }
```

**Response 429 (demasiados intentos fallidos)**
```json
{ "valid": false, "message": "Demasiados intentos fallidos. Vuelve a intentar en 15 minutos." }
```

**Response 200 con `valid:false` (credenciales correctas, pero sin licencia utilizable)**
```json
{ "valid": false, "message": "Esta licencia está suspendida." }
```

Reglas de negocio sugeridas: verificar contraseña con `scrypt`/`bcrypt` + salt (nunca texto plano), limitar intentos fallidos por correo (ej. 5 cada 15 min), verificar `maxActivations` por plan y registrar `installationId` como dispositivo activo, emitir un token de sesión de vida corta/media (30 días con renovación deslizante es razonable para una extensión de escritorio).

### POST `/v1/licenses/session`

Revalida la sesión sin pedir contraseña de nuevo. Se llama cada 12 horas mientras el panel esté abierto.

**Request** (header `Authorization: Bearer <token>`)
```json
{ "installationId": "uuid-v4" }
```

**Response 200 (sesión y licencia OK)** — mismo formato que el `license` de login, sin `token` (el token no cambia).
```json
{ "valid": true, "license": { "key": "WAM-...", "status": "active", "planId": "pro", "planLabel": "Pro", "expiresAt": null } }
```

**Response 200 con `valid:false`** (sesión viva, pero licencia suspendida/vencida) — el frontend conserva el token para recuperarse solo si se reactiva.

**Response 401** (token inválido/expirado) — el frontend limpia el token y fuerza reingresar credenciales.

### POST `/v1/auth/logout`

**Request** (header `Authorization: Bearer <token>`)
```json
{ "installationId": "uuid-v4" }
```

**Response 200**
```json
{ "ok": true }
```

Invalida la sesión y libera el cupo de activación de ese `installationId`. Debe ser idempotente (llamarlo sin sesión válida no es un error).

## API legada por clave de licencia (compatibilidad hacia atrás, opcional)

Si mantienes instalaciones de la extensión anteriores a v1.4.0, el backend de referencia también expone (sin cambios respecto a versiones anteriores de este documento):

- `POST /v1/licenses/activate` — `{ key, installationId }` → `{ valid, planId, planLabel, expiresAt }`
- `POST /v1/licenses/validate` — `{ key, installationId }` → igual forma de respuesta
- `POST /v1/licenses/deactivate` — `{ key, installationId }` → `{ ok: true }`

No es necesario implementarlas en instalaciones nuevas.

## Notas de implementación

- Todas las respuestas deben ser JSON, incluidas las de error (401/429) — el frontend siempre intenta parsear el cuerpo, incluso en respuestas no-2xx, para poder mostrar `message`.
- CORS: el backend debe permitir peticiones desde el origen de la extensión (`chrome-extension://<id>`) con el header `Authorization` habilitado en `Access-Control-Allow-Headers` (necesario para `/v1/licenses/session` y `/v1/auth/logout`).
- Nunca devuelvas la contraseña ni su hash en ninguna respuesta.
- Los `expiresAt` se esperan en epoch milliseconds; usa `null` para licencias sin vencimiento (ej. planes vitalicios) o de fecha aún no definida.
- Si además ofreces cobro automático, el token de sesión y estos mismos endpoints no cambian — lo único que cambia es *cómo* una licencia llega a `status: "active"` (a mano desde el panel admin, o automáticamente cuando `wamaster-web` recibe un webhook de pago confirmado). Ver `wamaster-web/docs/PAGOS.md`.
