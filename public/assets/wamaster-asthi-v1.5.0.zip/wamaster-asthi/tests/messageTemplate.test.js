import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  extractVariables,
  renderTemplate,
  validateTemplateAgainstContacts,
} from '../src/modules/messageTemplate.js';

test('extractVariables - encuentra nombres únicos', () => {
  assert.deepEqual(extractVariables('Hola {nombre}, tu pedido {pedido} y {nombre} de nuevo'), ['nombre', 'pedido']);
});

test('renderTemplate - resuelve nombre/telefono/extra', () => {
  const contact = { nombre: 'Ana', telefono: '525512345678', extra: { Empresa: 'Acme' } };
  const { text, missing } = renderTemplate('Hola {nombre} de {Empresa}, tel {telefono}', contact);
  assert.equal(text, 'Hola Ana de Acme, tel 525512345678');
  assert.deepEqual(missing, []);
});

test('renderTemplate - resuelve {saludo} inyectado vía extra', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { saludo: 'Buenos días' } };
  const { text } = renderTemplate('{saludo}, {nombre}', contact);
  assert.equal(text, 'Buenos días, Ana');
});

test('renderTemplate - variable faltante se reporta y se deja el placeholder', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: {} };
  const { text, missing } = renderTemplate('Hola {nombre}, tu código es {codigo}', contact);
  assert.equal(text, 'Hola Ana, tu código es {codigo}');
  assert.deepEqual(missing, ['codigo']);
});

test('validateTemplateAgainstContacts - cuenta cuántos contactos les falta cada variable', () => {
  const contacts = [
    { nombre: 'Ana', telefono: '1', extra: { codigo: 'A1' } },
    { nombre: 'Beto', telefono: '2', extra: {} },
  ];
  const { usedVariables, missingCounts } = validateTemplateAgainstContacts('Hola {nombre}, código {codigo}', contacts);
  assert.deepEqual(usedVariables.sort(), ['codigo', 'nombre']);
  assert.equal(missingCounts.codigo, 1);
});

// --- Columnas dinámicas de Excel con caracteres especiales (v1.2.1) -------

test('renderTemplate - columna con signo de pesos y paréntesis, ej. "Monto ($)"', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { 'Monto ($)': '1,500' } };
  const { text, missing } = renderTemplate('Hola {nombre}, tu monto es {Monto ($)}', contact);
  assert.equal(text, 'Hola Ana, tu monto es 1,500');
  assert.deepEqual(missing, []);
});

test('renderTemplate - columna con símbolo de grados y guion, ej. "N° Pedido" y "Fecha-Límite"', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { 'N° Pedido': '4821', 'Fecha-Límite': '10/08/2026' } };
  const { text } = renderTemplate('Pedido {N° Pedido}, vence el {Fecha-Límite}', contact);
  assert.equal(text, 'Pedido 4821, vence el 10/08/2026');
});

test('renderTemplate - columnas dinámicas típicas: {monto} y {direccion}', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { monto: '$2,300 MXN', direccion: 'Av. Reforma 123' } };
  const { text, missing } = renderTemplate('Hola {nombre}, tu pedido de {monto} llega a {direccion}', contact);
  assert.equal(text, 'Hola Ana, tu pedido de $2,300 MXN llega a Av. Reforma 123');
  assert.deepEqual(missing, []);
});

test('extractVariables - detecta nombres de variable con caracteres especiales', () => {
  const vars = extractVariables('{monto} y {N° Pedido} y {Fecha-Límite} y {Monto ($)}');
  assert.deepEqual(vars, ['monto', 'N° Pedido', 'Fecha-Límite', 'Monto ($)']);
});

// --- Coincidencia insensible a acentos y alias de columnas (v1.2.2) -------

test('renderTemplate - coincidencia exacta ignora acentos: {direccion} encuentra columna "Dirección"', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { Dirección: 'Av. Reforma 123' } };
  const { text, missing } = renderTemplate('Vive en {direccion}', contact);
  assert.equal(text, 'Vive en Av. Reforma 123');
  assert.deepEqual(missing, []);
});

test('renderTemplate - coincidencia exacta ignora mayúsculas y espacios extremos', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { '  CIUDAD  ': 'Guadalajara' } };
  const { text } = renderTemplate('Desde {ciudad}', contact);
  assert.equal(text, 'Desde Guadalajara');
});

test('renderTemplate - alias {email} resuelve columna "Correo Electrónico"', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { 'Correo Electrónico': 'ana@example.com' } };
  const { text, missing } = renderTemplate('Te escribimos a {email}', contact);
  assert.equal(text, 'Te escribimos a ana@example.com');
  assert.deepEqual(missing, []);
});

test('renderTemplate - alias {correo} resuelve columna "Email" (funciona en ambas direcciones)', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { Email: 'ana@example.com' } };
  const { text } = renderTemplate('Correo: {correo}', contact);
  assert.equal(text, 'Correo: ana@example.com');
});

test('renderTemplate - alias {producto} resuelve columna "Artículo"', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { Artículo: 'Tenis running' } };
  const { text } = renderTemplate('Tu {producto} está listo', contact);
  assert.equal(text, 'Tu Tenis running está listo');
});

test('renderTemplate - alias {empresa} resuelve columna "Razón Social"', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { 'Razón Social': 'Comercializadora XYZ' } };
  const { text } = renderTemplate('De parte de {empresa}', contact);
  assert.equal(text, 'De parte de Comercializadora XYZ');
});

test('renderTemplate - sin coincidencia exacta ni alias, la variable se reporta como faltante', () => {
  const contact = { nombre: 'Ana', telefono: '1', extra: { Empresa: 'Acme' } };
  const { text, missing } = renderTemplate('Ciudad: {ciudad}', contact);
  assert.equal(text, 'Ciudad: {ciudad}');
  assert.deepEqual(missing, ['ciudad']);
});

test('renderTemplate - {nombre}/{telefono} siguen funcionando igual que antes (sin regresión)', () => {
  const contact = { nombre: 'Ana', telefono: '525512345678', extra: {} };
  const { text } = renderTemplate('{nombre} - {telefono}', contact);
  assert.equal(text, 'Ana - 525512345678');
});
