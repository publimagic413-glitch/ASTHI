/**
 * exportUtils.js
 * ---------------------------------------------------------------------------
 * Genera archivos CSV descargables en el navegador a partir de arrays de
 * objetos, sin dependencias externas. Usado por el historial de campañas
 * (enviados/fallidos/reporte completo) y por la tabla de contactos
 * (descarga de números inválidos) en v1.2.0.
 * ---------------------------------------------------------------------------
 */

/** Escapa un valor para una celda CSV (comillas dobles + separador ,). */
function escapeCsvCell(value) {
  const text = String(value ?? '');
  if (/[",\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

/**
 * Convierte un array de objetos planos en texto CSV, usando las claves del
 * primer objeto como encabezados (o `columns` si se especifica).
 * @param {Array<Object>} rows
 * @param {string[]} [columns]
 * @returns {string}
 */
export function toCsv(rows, columns) {
  if (!rows || rows.length === 0) return '';
  const headers = columns || Object.keys(rows[0]);
  const lines = [headers.map(escapeCsvCell).join(',')];
  for (const row of rows) {
    lines.push(headers.map((h) => escapeCsvCell(row[h])).join(','));
  }
  // BOM UTF-8 para que Excel abra acentos correctamente.
  return `﻿${lines.join('\r\n')}`;
}

/**
 * Dispara la descarga de un archivo CSV en el navegador.
 * @param {string} filename
 * @param {Array<Object>} rows
 * @param {string[]} [columns]
 */
export function downloadCsv(filename, rows, columns) {
  const csv = toCsv(rows, columns);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Dispara la descarga de un archivo JSON "bonito" (usado para el reporte
 * completo de campaña, que incluye metadatos además de filas tabulares).
 * @param {string} filename
 * @param {Object} data
 */
export function downloadJson(filename, data) {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.json') ? filename : `${filename}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
