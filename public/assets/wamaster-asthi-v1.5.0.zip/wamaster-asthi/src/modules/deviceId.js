/**
 * deviceId.js
 * ---------------------------------------------------------------------------
 * Identificador estable de instalación (installationId), usado por
 * licensing.js para "atar" una licencia a este navegador/perfil al
 * activarla. No es un identificador de hardware ni de usuario: es un UUID
 * aleatorio generado una vez y guardado en chrome.storage.local, por lo que
 * cambia si el usuario reinstala la extensión o borra los datos.
 * ---------------------------------------------------------------------------
 */

import { getItem, setItem, StorageKeys } from '../utils/storage.js';

/** @returns {Promise<string>} el installationId, generándolo si no existe. */
export async function getInstallationId() {
  let id = await getItem(StorageKeys.INSTALLATION_ID, null);
  if (!id) {
    id = generateUuid();
    await setItem(StorageKeys.INSTALLATION_ID, id);
  }
  return id;
}

function generateUuid() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  // Respaldo para entornos sin crypto.randomUUID (poco probable en Chrome 116+).
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
