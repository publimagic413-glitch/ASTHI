/**
 * whatsappSelectors.js (script clásico, no módulo ES6)
 * ---------------------------------------------------------------------------
 * WhatsApp Web no expone una API pública ni atributos `data-testid` estables
 * a largo plazo, así que este archivo centraliza TODOS los selectores CSS y
 * coincidencias de texto usados para interactuar con su interfaz, con
 * varias alternativas de respaldo por elemento (la UI de WhatsApp cambia
 * marcado con cierta frecuencia).
 *
 * Se carga como <script> clásico (antes de content.js) y expone su API en
 * `window.WaMasterSelectors`, porque los content scripts de Manifest V3
 * pueden declarar módulos ES6 pero WhatsApp Web tiene una Content Security
 * Policy propia que en la práctica ha dado problemas con `type: module` en
 * content scripts inyectados; usar scripts clásicos es la opción robusta.
 *
 * v1.2.0: se agrega `dialogContainer` y `queryAnyWithin()` para poder
 * ACOTAR las búsquedas de "caja de texto de pie de foto" y "botón enviar"
 * al modal de adjuntos concreto, en vez de buscar en todo `document`. Esto
 * es la corrección de la duplicación de mensaje al enviar imágenes/PDF (ver
 * docs/CAMBIOS_v1.2.0.md): sin acotar, un selector genérico podía coincidir
 * primero con el cuadro de texto principal de la conversación (que sigue
 * existiendo detrás del modal), escribiendo el texto ahí Y en el pie de
 * foto real, y WhatsApp terminaba enviando ambos.
 * ---------------------------------------------------------------------------
 */

(function () {
  const CANDIDATES = {
    // Cuadro de texto principal de la conversación (para envío de solo texto).
    composeBox: [
      'div[contenteditable="true"][data-tab="10"]',
      'footer div[contenteditable="true"][role="textbox"]',
      'div[aria-label="Escribe un mensaje"][contenteditable="true"]',
      'div[aria-label="Type a message"][contenteditable="true"]',
    ],
    sendButton: [
      'button[aria-label="Enviar"]',
      'button[aria-label="Send"]',
      'span[data-icon="send"]',
      'span[data-testid="send"]',
    ],
    attachButton: [
      'span[data-icon="clip"]',
      'span[data-icon="plus-rounded"]',
      'button[aria-label="Adjuntar"]',
      'button[aria-label="Attach"]',
      'div[title="Adjuntar"]',
      'div[title="Attach"]',
    ],
    // Ítems del menú desplegable que aparece al pulsar el clip de adjuntar.
    attachPhotoMenuItemText: ['Fotos y videos', 'Photos & videos', 'Photos and videos'],
    attachDocumentMenuItemText: ['Documento', 'Document'],
    attachImageInput: ['input[type="file"][accept*="image"]'],
    attachDocumentInput: ['input[type="file"][accept*="*"]', 'input[type="file"]:not([accept*="image"])'],

    // El contenedor del modal/diálogo que aparece tras elegir un archivo,
    // con la vista previa y el pie de foto. TODOS los selectores de
    // "dentro del modal" (captionBox, sendButton del modal) deben buscarse
    // con queryAnyWithin() usando este contenedor como raíz.
    dialogContainer: ['div[role="dialog"]', 'div[data-animate-modal-popup="true"]'],

    captionBox: [
      'div[contenteditable="true"][data-tab="10"]',
      'div[aria-label="Añade un comentario"][contenteditable="true"]',
      'div[aria-label="Add a caption"][contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]',
    ],

    invalidNumberText: [
      'El número de teléfono compartido a través de la URL es inválido',
      'Phone number shared via url is invalid',
    ],
    continueButtonText: ['Continuar al chat', 'Continue to Chat', 'Usar aquí', 'Use here'],
  };

  /** Devuelve el primer elemento visible que matchee alguno de los selectores CSS dados. */
  function queryAny(selectors, root) {
    const scope = root || document;
    for (const sel of selectors) {
      const el = scope.querySelector(sel);
      if (el && isVisible(el)) return el;
    }
    return null;
  }

  /** Igual que queryAny, pero acotado a buscar SOLO dentro de `container` (no en todo el documento). */
  function queryAnyWithin(container, selectors) {
    if (!container) return null;
    return queryAny(selectors, container);
  }

  /** Busca el primer elemento visible cuyo texto contenga alguno de los strings dados. */
  function queryByText(texts, root) {
    const scope = root || document;
    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_ELEMENT);
    let node = walker.currentNode;
    while (node) {
      if (node.children.length === 0) {
        const content = (node.textContent || '').trim();
        if (content && texts.some((t) => content.includes(t)) && isVisible(node)) {
          return node;
        }
      }
      node = walker.nextNode();
    }
    return null;
  }

  /** true si el texto dado aparece visible en algún lugar de la página. */
  function pageContainsText(texts) {
    return Boolean(queryByText(texts));
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== 'hidden' && style.display !== 'none';
  }

  /** Espera (polling) a que una función condición devuelva un valor truthy, o hace timeout. */
  function waitFor(conditionFn, timeoutMs, intervalMs) {
    const timeout = timeoutMs || 10000;
    const interval = intervalMs || 200;
    return new Promise((resolve, reject) => {
      const start = Date.now();
      const tick = () => {
        const result = conditionFn();
        if (result) return resolve(result);
        if (Date.now() - start > timeout) return reject(new Error('Tiempo de espera agotado.'));
        setTimeout(tick, interval);
      };
      tick();
    });
  }

  window.WaMasterSelectors = {
    CANDIDATES,
    queryAny,
    queryAnyWithin,
    queryByText,
    pageContainsText,
    isVisible,
    waitFor,
  };
})();
