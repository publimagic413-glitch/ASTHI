/**
 * domParserPolyfill.js
 * ---------------------------------------------------------------------------
 * Node.js no trae `DOMParser` global (es una API de navegador). xlsxImporter.js
 * la usa para leer el XML de OOXML. Este polyfill mínimo basado en regex
 * implementa justo lo que xlsxImporter.js necesita: getElementsByTagName,
 * getAttribute, children (solo nodos elemento) y textContent. No es un
 * parser XML de propósito general (no maneja namespaces con prefijo,
 * CDATA, ni DTDs), pero es suficiente para el XML que genera Excel/OOXML.
 * ---------------------------------------------------------------------------
 */

function decodeEntities(str) {
  return str
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&amp;/g, '&');
}

function parseXmlTree(xmlText) {
  const text = xmlText.replace(/<\?xml[^>]*\?>/g, '').replace(/<!--[\s\S]*?-->/g, '');
  const tokenRegex = /<([^>]+)>|([^<]+)/g;
  const root = { tagName: '#document', attributes: {}, children: [], textParts: [], parent: null };
  let current = root;
  let match;

  while ((match = tokenRegex.exec(text)) !== null) {
    if (match[1] !== undefined) {
      const tagContent = match[1].trim();
      if (tagContent.startsWith('/')) {
        current = current.parent || root;
        continue;
      }
      const selfClosing = tagContent.endsWith('/');
      const inner = selfClosing ? tagContent.slice(0, -1).trim() : tagContent;
      const spaceIdx = inner.search(/\s/);
      const tagName = spaceIdx === -1 ? inner : inner.slice(0, spaceIdx);
      const attrString = spaceIdx === -1 ? '' : inner.slice(spaceIdx);

      const attributes = {};
      const attrRegex = /([a-zA-Z0-9:_-]+)\s*=\s*"([^"]*)"/g;
      let attrMatch;
      while ((attrMatch = attrRegex.exec(attrString)) !== null) {
        attributes[attrMatch[1]] = decodeEntities(attrMatch[2]);
      }

      const node = { tagName, attributes, children: [], textParts: [], parent: current };
      current.children.push(node);
      if (!selfClosing) current = node;
    } else if (match[2] !== undefined) {
      current.textParts.push(decodeEntities(match[2]));
    }
  }

  decorate(root);
  return root;
}

function collectByTagName(node, tagName, out) {
  for (const child of node.children) {
    if (child.tagName === tagName) out.push(child);
    collectByTagName(child, tagName, out);
  }
  return out;
}

function computeTextContent(node) {
  let result = node.textParts.join('');
  for (const child of node.children) {
    result += computeTextContent(child);
  }
  return result;
}

function decorate(node) {
  node.getAttribute = (name) => (Object.prototype.hasOwnProperty.call(node.attributes, name) ? node.attributes[name] : null);
  node.getElementsByTagName = (name) => collectByTagName(node, name, []);
  Object.defineProperty(node, 'textContent', { get: () => computeTextContent(node) });
  for (const child of node.children) decorate(child);
}

export class DOMParser {
  parseFromString(xmlText) {
    const root = parseXmlTree(xmlText);
    return {
      documentElement: root.children[0] || null,
      getElementsByTagName: (name) => collectByTagName(root, name, []),
    };
  }
}

/** Instala DOMParser en globalThis si no existe ya (no-op en un navegador real). */
export function installDomParserPolyfill() {
  if (typeof globalThis.DOMParser === 'undefined') {
    globalThis.DOMParser = DOMParser;
  }
}
