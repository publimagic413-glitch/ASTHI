/**
 * chromeMock.js
 * ---------------------------------------------------------------------------
 * Mock mínimo de las APIs de chrome.* usadas por WaMaster Asthi, para poder
 * probar los módulos con el test runner nativo de Node (node:test) sin
 * necesidad de un navegador real.
 * ---------------------------------------------------------------------------
 */

export function createChromeMock() {
  const store = {};
  const changeListeners = new Set();
  const messageListeners = new Set();
  const tabs = new Map();
  let nextTabId = 1;

  const chrome = {
    storage: {
      local: {
        get(keys, callback) {
          const result = {};
          const keyList = typeof keys === 'string' ? [keys] : (Array.isArray(keys) ? keys : Object.keys(store));
          for (const key of keyList) {
            if (Object.prototype.hasOwnProperty.call(store, key)) {
              result[key] = store[key];
            }
          }
          if (callback) {
            callback(result);
            return undefined;
          }
          return Promise.resolve(result);
        },
        set(items, callback) {
          const changes = {};
          for (const [key, value] of Object.entries(items)) {
            changes[key] = { oldValue: store[key], newValue: value };
            store[key] = value;
          }
          for (const listener of changeListeners) listener(changes, 'local');
          if (callback) {
            callback();
            return undefined;
          }
          return Promise.resolve();
        },
        remove(keys, callback) {
          const keyList = typeof keys === 'string' ? [keys] : keys;
          for (const key of keyList) delete store[key];
          if (callback) {
            callback();
            return undefined;
          }
          return Promise.resolve();
        },
      },
      onChanged: {
        addListener: (fn) => changeListeners.add(fn),
        removeListener: (fn) => changeListeners.delete(fn),
      },
    },
    runtime: {
      onMessage: {
        addListener: (fn) => messageListeners.add(fn),
        removeListener: (fn) => messageListeners.delete(fn),
      },
      sendMessage(message) {
        // Imita el comportamiento real de chrome.runtime.sendMessage: si un
        // listener responde con `sendResponse` (de forma síncrona o
        // devolviendo `true` para responder asíncronamente) o devuelve una
        // Promesa, esa es la respuesta que recibe el llamador.
        return new Promise((resolve) => {
          const currentListeners = [...messageListeners];
          if (currentListeners.length === 0) {
            resolve(undefined);
            return;
          }
          let handled = false;
          let expectsAsyncResponse = false;
          const sendResponse = (response) => {
            if (!handled) {
              handled = true;
              resolve(response);
            }
          };
          for (const listener of currentListeners) {
            const result = listener(message, {}, sendResponse);
            if (result === true) {
              expectsAsyncResponse = true;
            } else if (result && typeof result.then === 'function') {
              expectsAsyncResponse = true;
              result.then(sendResponse);
            }
          }
          if (!expectsAsyncResponse && !handled) {
            resolve(undefined);
          }
        });
      },
    },
    tabs: {
      create({ url }) {
        const tab = { id: nextTabId++, url };
        tabs.set(tab.id, tab);
        return Promise.resolve(tab);
      },
      update(tabId, { url }) {
        const tab = tabs.get(tabId) || { id: tabId };
        tab.url = url;
        tabs.set(tabId, tab);
        return Promise.resolve(tab);
      },
      query(queryInfo) {
        let result = [...tabs.values()];
        if (queryInfo?.url) {
          // Soporta el patrón simple "https://web.whatsapp.com/*" usado por background.js.
          const prefix = String(queryInfo.url).replace(/\*$/, '');
          result = result.filter((t) => t.url && t.url.startsWith(prefix));
        }
        return Promise.resolve(result);
      },
      onUpdated: {
        addListener: () => {},
        removeListener: () => {},
      },
      onRemoved: {
        addListener: () => {},
        removeListener: () => {},
      },
    },
    sidePanel: {
      setPanelBehavior: () => Promise.resolve(),
    },
  };

  return {
    chrome,
    _store: store,
    _tabs: tabs,
    _emitMessage: (message) => {
      for (const listener of [...messageListeners]) listener(message, {}, () => {});
    },
  };
}
