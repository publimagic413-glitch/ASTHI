# Pruebas automatizadas

Corren con el test runner nativo de Node (`node:test` + `node:assert/strict`), sin ninguna dependencia externa (no hay `node_modules`).

```
npm test
```

## Estructura

- `helpers/chromeMock.js` — mock de `chrome.storage`, `chrome.runtime`, `chrome.tabs`, `chrome.sidePanel` para poder probar módulos que usan APIs de extensión sin un navegador real.
- `helpers/domParserPolyfill.js` — polyfill mínimo de `DOMParser` (Node no lo trae), usado por las pruebas de `xlsxImporter.js`.
- `helpers/zipBuilder.js` — construye archivos ZIP sintéticos en memoria con `node:zlib`, usado por las pruebas de `zipReader.js`/`xlsxImporter.js`.
- `fixtures/contactos_ejemplo.xlsx` — archivo de ejemplo real para pruebas manuales de importación.
- `*.test.js` — un archivo por módulo (`contactManager`, `messageTemplate`, `zipReader`, `xlsxImporter`, `storage`, `logger`, `messaging`, `whatsappUrl`, `greetings`, `campaignHistory`, `exportUtils`, `countryCodes`, `deviceId`, `licensing`, `campaignEngine`, `background`).

## Notas

- Los módulos con estado a nivel de archivo (`logger.js`, `storage.js`) se reimportan con un query string único (`?t=...`) en cada `beforeEach` para evitar que las suscripciones o el caché de un test se filtren al siguiente, dado que Node cachea los módulos ES por URL resuelta.
- `campaignEngine.test.js` y `background.test.js` son pruebas de integración: simulan un flujo de envío completo (incluyendo la respuesta asíncrona del "content script" vía `chrome.runtime.onMessage`) sin necesidad de Chrome ni de WhatsApp Web reales.
- Lo que **no** se puede probar aquí: la interacción real con el DOM de WhatsApp Web (`content.js`, `whatsappSelectors.js`) y la UI del side panel (`sidebar.js`) — para eso está `docs/PLAN_PRUEBAS.md`.
