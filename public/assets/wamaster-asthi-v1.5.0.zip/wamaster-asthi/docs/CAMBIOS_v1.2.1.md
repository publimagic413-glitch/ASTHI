# Resumen de cambios — v1.2.0 → v1.2.1

## Qué se pidió

> Actualiza mi extensión WaMaster Asthi para que use columnas adicionales del Excel como variables dinámicas ({monto}, {direccion}, etc.), detectadas automáticamente, manteniendo compatibilidad total. No elimines funciones existentes.

## Diagnóstico

La detección automática de columnas ya existía desde v1.2.0: al importar un Excel, cada columna que no sea "Nombre" ni "Teléfono" se guarda en `contact.extra` (ver `contactManager.js`) y `sidebar.js` ya genera un botón insertable `{ColumnaX}` por cada una (`renderVariableButtons()`), sin límite de cuántas columnas ni de qué tipo de dato contengan.

El problema estaba un nivel más abajo, en el motor de plantillas (`messageTemplate.js`): la expresión regular que reconoce una variable dentro de `{ }` solo aceptaba letras, números, guion bajo, espacios y un puñado de vocales acentuadas + ñ:

```js
const VARIABLE_REGEX = /\{([a-zA-Z0-9_ áéíóúÁÉÍÓÚñÑ]+)\}/g;
```

Columnas de Excel perfectamente normales en la práctica —`Monto ($)`, `N° Pedido`, `Fecha-Límite`, `CP`, `RFC/Razón Social`— generan botones `{Monto ($)}`, `{N° Pedido}`, etc. Al hacer clic, el botón insertaba ese texto en el mensaje correctamente, **pero al renderizar la plantilla para enviar, esa misma expresión regular no reconocía el contenido como una variable válida** (por el `$`, el `°` o el `-`), así que el placeholder se enviaba tal cual, literal, en vez de sustituirse por el valor del contacto. Con columnas de nombre simple como `monto` o `direccion` (solo letras) esto no ocurría — por eso el caso más simple del pedido ya funcionaba, pero no había compatibilidad total con cualquier columna.

## Cambio implementado

Un solo archivo, un cambio quirúrgico: `src/modules/messageTemplate.js`.

```diff
- const VARIABLE_REGEX = /\{([a-zA-Z0-9_ áéíóúÁÉÍÓÚñÑ]+)\}/g;
+ const VARIABLE_REGEX = /\{([^{}\r\n]+)\}/g;
```

Ahora una variable es "cualquier texto entre `{` y `}`, sin restricción de caracteres" (salvo llaves anidadas o saltos de línea, que nunca aparecen en un nombre de columna real). Esto hace que **cualquier** columna del Excel funcione como variable sin importar qué símbolos tenga: `{monto}`, `{direccion}`, `{Monto ($)}`, `{N° Pedido}`, `{Fecha-Límite}`, `{RFC/Razón Social}`, encabezados solo con números, etc.

No se tocó ninguna otra función: `extractVariables()`, `renderTemplate()`, `resolveVariable()` y `validateTemplateAgainstContacts()` siguen exactamente igual, solo cambia qué texto reconocen como "nombre de variable". `{nombre}`, `{telefono}` y `{saludo}` siguen funcionando idéntico a antes — compatibilidad total con plantillas ya escritas por usuarios actuales.

## Qué NO cambió (para que quede explícito)

- La detección automática de columnas y los botones insertables — ya existían, no se tocaron.
- `contactManager.js`, `campaignEngine.js`, `content.js`, `sidebar.js` — sin cambios.
- El sistema de licencias, país/teléfono automático, saludos aleatorios, historial de campañas, selector de emojis, corrección de adjuntos duplicados — todo igual que en v1.2.0.
- Ningún `StorageKey` ni formato de datos cambió; no hace falta reimportar Excel ni reconfigurar nada para usuarios que ya venían usando la extensión.

## Verificación

- `npm test` → **86/86 pruebas en verde** (82 de v1.2.0 + 4 nuevas específicas para este fix, en `tests/messageTemplate.test.js`): variables con `$`, `°`, `-`, espacios y paréntesis en el nombre de columna, además de los casos típicos `{monto}` y `{direccion}` mencionados en la solicitud.
- Verificación manual de que `{nombre}`, `{telefono}` y `{saludo}` no cambiaron su comportamiento (casos de prueba existentes de v1.2.0 siguen pasando sin modificar sus aserciones).

## Archivos modificados en esta versión

- `src/modules/messageTemplate.js` — expresión regular ampliada + comentario explicando el porqué.
- `tests/messageTemplate.test.js` — 4 pruebas nuevas de regresión.
- `manifest.json`, `package.json` — versión `1.2.1`.
- `src/sidebar/sidebar.html` — insignia de versión actualizada a `v1.2.1`.
- `docs/CAMBIOS_v1.2.1.md` — este documento.
