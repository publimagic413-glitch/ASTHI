import { test, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { createChromeMock } from './helpers/chromeMock.js';

let licensing, StorageKeys, getItem, setItem;
let originalFetch;

beforeEach(async () => {
  const mock = createChromeMock();
  globalThis.chrome = mock.chrome;
  originalFetch = globalThis.fetch;
  const suffix = `?t=${Date.now()}_${Math.random()}`;
  const storageMod = await import(`../src/utils/storage.js${suffix}`);
  ({ getItem, setItem, StorageKeys } = storageMod);
  licensing = await import(`../src/modules/licensing.js${suffix}`);
});

afterEach(() => {
  globalThis.fetch = originalFetch;
});

/** Helper para simular una respuesta fetch() con un cuerpo JSON y status dado. */
function fakeResponse(status, body) {
  return { ok: status >= 200 && status < 300, status, json: async () => body };
}

test('activateLicense - correo vacío lanza error', async () => {
  await assert.rejects(() => licensing.activateLicense('   ', 'algo'), /Ingresa tu correo/);
});

test('activateLicense - sin backend configurado (explícitamente vacío) ni modo de prueba local, lanza error explicativo', async () => {
  // Por defecto getApiBase() ahora apunta a http://localhost:4000 (backend de
  // desarrollo local) para que la extensión funcione "de fábrica" — este caso
  // simula que el usuario lo dejó explícitamente en blanco (ej. desplegado
  // sin backend todavía).
  await licensing.setApiBase('');
  await assert.rejects(
    () => licensing.activateLicense('cliente@ejemplo.com', 'claveSegura123'),
    /No hay backend de licencias configurado/
  );
});

test('getApiBase - por defecto apunta al backend de desarrollo local (http://localhost:4000)', async () => {
  assert.equal(await licensing.getApiBase(), 'http://localhost:4000');
});

test('activateLicense - contraseña vacía (sin modo de prueba local) lanza error', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  await assert.rejects(() => licensing.activateLicense('cliente@ejemplo.com', ''), /Ingresa tu contraseña/);
});

test('activateLicense - modo de prueba local activa sin red (contraseña no requerida)', async () => {
  await setItem(StorageKeys.LICENSE_DEV_BYPASS, true);
  const record = await licensing.activateLicense('cliente@ejemplo.com', '');
  assert.equal(record.status, licensing.LicenseStatus.ACTIVE);
  assert.equal(record.devBypass, true);
  assert.equal(record.email, 'cliente@ejemplo.com');
  assert.equal(record.planId, licensing.PlanId.PRO);
  assert.equal(record.token, null);
  assert.equal(licensing.isLicenseUsable(await licensing.getLicense()), true);
});

test('activateLicense - backend configurado y credenciales válidas guarda el token, nunca la contraseña', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  globalThis.fetch = async (url, opts) => {
    assert.match(url, /\/v1\/auth\/login$/);
    const body = JSON.parse(opts.body);
    assert.equal(body.email, 'cliente@ejemplo.com');
    assert.equal(body.password, 'claveSegura123');
    assert.ok(body.installationId);
    return fakeResponse(200, {
      valid: true,
      token: 'tok_abc123',
      expiresAt: 9999999999999,
      license: { key: 'WAM-OK', status: 'active', planId: 'pro', planLabel: 'Pro', expiresAt: null },
    });
  };
  const record = await licensing.activateLicense('cliente@ejemplo.com', 'claveSegura123');
  assert.equal(record.status, licensing.LicenseStatus.ACTIVE);
  assert.equal(record.planLabel, 'Pro');
  assert.equal(record.token, 'tok_abc123');
  assert.equal(Object.prototype.hasOwnProperty.call(record, 'password'), false);
});

test('activateLicense - backend rechaza las credenciales', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  globalThis.fetch = async () => fakeResponse(401, { valid: false, message: 'Correo o contraseña incorrectos.' });
  await assert.rejects(
    () => licensing.activateLicense('cliente@ejemplo.com', 'incorrecta'),
    /Correo o contraseña incorrectos/
  );
});

test('revalidateLicense - modo de prueba local nunca contacta backend', async () => {
  await setItem(StorageKeys.LICENSE_DEV_BYPASS, true);
  await licensing.activateLicense('cliente@ejemplo.com', '');
  globalThis.fetch = async () => { throw new Error('no debería llamarse'); };
  const revalidated = await licensing.revalidateLicense();
  assert.equal(revalidated.status, licensing.LicenseStatus.ACTIVE);
});

test('revalidateLicense - sin sesión activa devuelve null', async () => {
  assert.equal(await licensing.revalidateLicense(), null);
});

test('revalidateLicense - registro heredado sin token (activado por clave antes de v1.4.0) se marca INVALID sin llamar red', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  await setItem(StorageKeys.LICENSE, {
    key: 'WAM-LEGACY',
    status: licensing.LicenseStatus.ACTIVE,
    planId: 'pro',
    planLabel: 'Pro',
    expiresAt: null,
    lastValidatedAt: Date.now(),
    installationId: 'inst-1',
    devBypass: false,
    // sin `token`: así quedaban los registros de versiones anteriores a v1.4.0
  });
  globalThis.fetch = async () => { throw new Error('no debería llamarse'); };
  const revalidated = await licensing.revalidateLicense();
  assert.equal(revalidated.status, licensing.LicenseStatus.INVALID);
});

test('revalidateLicense - token expirado/inválido (401) marca INVALID y limpia el token', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  globalThis.fetch = async () => fakeResponse(200, {
    valid: true, token: 'tok_1', expiresAt: 9999999999999,
    license: { key: 'WAM-OK', status: 'active', planId: 'pro', planLabel: 'Pro', expiresAt: null },
  });
  await licensing.activateLicense('cliente@ejemplo.com', 'claveSegura123');

  globalThis.fetch = async (url, opts) => {
    assert.match(url, /\/v1\/licenses\/session$/);
    assert.equal(opts.headers.Authorization, 'Bearer tok_1');
    return fakeResponse(401, { valid: false, message: 'Sesión expirada o inválida.' });
  };
  const revalidated = await licensing.revalidateLicense();
  assert.equal(revalidated.status, licensing.LicenseStatus.INVALID);
  assert.equal(revalidated.token, null);
});

test('revalidateLicense - token válido pero licencia no utilizable (suspendida/vencida) marca EXPIRED y conserva el token', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  globalThis.fetch = async () => fakeResponse(200, {
    valid: true, token: 'tok_2', expiresAt: 9999999999999,
    license: { key: 'WAM-OK', status: 'active', planId: 'pro', planLabel: 'Pro', expiresAt: null },
  });
  await licensing.activateLicense('cliente@ejemplo.com', 'claveSegura123');

  globalThis.fetch = async () => fakeResponse(200, { valid: false, message: 'Esta licencia está suspendida.' });
  const revalidated = await licensing.revalidateLicense();
  assert.equal(revalidated.status, licensing.LicenseStatus.EXPIRED);
  assert.equal(revalidated.token, 'tok_2'); // se conserva: si el admin reactiva, la siguiente revalidación se recupera sola
  assert.equal(licensing.isLicenseUsable(revalidated), false);
});

test('revalidateLicense - fallo de red degrada a GRACE dentro del período de tolerancia', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  globalThis.fetch = async () => fakeResponse(200, {
    valid: true, token: 'tok_3', expiresAt: 9999999999999,
    license: { key: 'WAM-OK', status: 'active', planId: 'pro', planLabel: 'Pro', expiresAt: null },
  });
  await licensing.activateLicense('cliente@ejemplo.com', 'claveSegura123');

  globalThis.fetch = async () => { throw new Error('sin conexión'); };
  const revalidated = await licensing.revalidateLicense();
  assert.equal(revalidated.status, licensing.LicenseStatus.GRACE);
  assert.equal(licensing.isLicenseUsable(revalidated), true);
});

test('isLicenseUsable - null o estados inválidos/expirados no son utilizables', () => {
  assert.equal(licensing.isLicenseUsable(null), false);
  assert.equal(licensing.isLicenseUsable({ status: licensing.LicenseStatus.EXPIRED }), false);
  assert.equal(licensing.isLicenseUsable({ status: licensing.LicenseStatus.INVALID }), false);
  assert.equal(licensing.isLicenseUsable({ status: licensing.LicenseStatus.ACTIVE }), true);
  assert.equal(licensing.isLicenseUsable({ status: licensing.LicenseStatus.GRACE }), true);
});

test('deactivateLicense - modo de prueba local limpia la licencia local sin red', async () => {
  await setItem(StorageKeys.LICENSE_DEV_BYPASS, true);
  await licensing.activateLicense('cliente@ejemplo.com', '');
  globalThis.fetch = async () => { throw new Error('no debería llamarse'); };
  await licensing.deactivateLicense();
  assert.equal(await licensing.getLicense(), null);
});

test('deactivateLicense - avisa al backend con el token y limpia la licencia local aunque falle la llamada', async () => {
  await licensing.setApiBase('https://licencias.example.com');
  globalThis.fetch = async () => fakeResponse(200, {
    valid: true, token: 'tok_4', expiresAt: 9999999999999,
    license: { key: 'WAM-OK', status: 'active', planId: 'pro', planLabel: 'Pro', expiresAt: null },
  });
  await licensing.activateLicense('cliente@ejemplo.com', 'claveSegura123');

  let calledWithAuth = null;
  globalThis.fetch = async (url, opts) => {
    calledWithAuth = opts.headers.Authorization;
    throw new Error('backend caído'); // aun así debe limpiar localmente
  };
  await licensing.deactivateLicense();
  assert.equal(calledWithAuth, 'Bearer tok_4');
  assert.equal(await licensing.getLicense(), null);
});
